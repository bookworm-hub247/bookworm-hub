// ==========================================
// BOOKWORM CLUB — MAIN JAVASCRIPT
// ==========================================


// ==========================================
// 1. MOBILE NAVIGATION
// ==========================================

const menuButton = document.getElementById("menuButton");
const navLinks = document.querySelector(".nav-links");

if (menuButton && navLinks) {

    menuButton.addEventListener("click", function () {

        navLinks.classList.toggle("active");

        // Change menu icon
        if (navLinks.classList.contains("active")) {
            menuButton.textContent = "✕";
        } else {
            menuButton.textContent = "☰";
        }

    });

}


// ==========================================
// 2. CLOSE MOBILE MENU AFTER LINK CLICK
// ==========================================

if (navLinks) {

    const links = navLinks.querySelectorAll("a");

    links.forEach(function (link) {

        link.addEventListener("click", function () {

            navLinks.classList.remove("active");

            if (menuButton) {
                menuButton.textContent = "☰";
            }

        });

    });

}


// ==========================================
// 3. BOOKWORM PLATFORM MESSAGE
// ==========================================

console.log("=================================");
console.log("BOOKWORM CLUB");
console.log("Learn. Connect. Grow.");
console.log("Application initialized successfully.");
console.log("=================================");


// ==========================================
// 4. CURRENT YEAR
// ==========================================

const currentYear = new Date().getFullYear();

const footerYear = document.querySelector(".footer-year");

if (footerYear) {
    footerYear.textContent = currentYear;
}


// ==========================================
// 5. BUTTON INTERACTION
// ==========================================

const platformButtons =
    document.querySelectorAll(".primary-button");

platformButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        console.log(
            "Bookworm platform button clicked."
        );

    });

});


// ==========================================
// 6. SMOOTH USER EXPERIENCE
// ==========================================

window.addEventListener("load", function () {

    document.body.classList.add("page-loaded");

});