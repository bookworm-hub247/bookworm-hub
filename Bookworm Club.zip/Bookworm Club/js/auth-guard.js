// ==========================================
// BOOKWORM CLUB — AUTHENTICATION GUARD
// Offline-safe authenticated page protection
// ==========================================

(function () {
    "use strict";

    const LOGIN_PAGE = "login.html";

    // ==========================================
    // PAGE CHECK
    // ==========================================

    function isLoginPage() {
        return window.location.pathname
            .toLowerCase()
            .endsWith("login.html");
    }

    // ==========================================
    // CONNECTION CHECK
    // ==========================================

    function isOffline() {
        return navigator.onLine === false;
    }

    // ==========================================
    // FIND STORED SUPABASE SESSION
    // ==========================================

    function hasStoredSupabaseSession() {

        try {

            for (let i = 0; i < localStorage.length; i++) {

                const key = localStorage.key(i);

                if (!key || !key.endsWith("-auth-token")) {
                    continue;
                }

                const raw = localStorage.getItem(key);

                if (!raw) {
                    continue;
                }

                const stored = JSON.parse(raw);

                if (
                    stored &&
                    stored.access_token &&
                    stored.user
                ) {
                    return stored;
                }

            }

        } catch (error) {

            console.warn(
                "Bookworm: Could not inspect stored session.",
                error
            );

        }

        return null;
    }

    // ==========================================
    // MARK USER AS AUTHENTICATED
    // ==========================================

    function markAuthenticated(user, offline = false) {

        document.documentElement.dataset.authenticated =
            "true";

        if (offline) {

            document.documentElement.dataset.offlineAuth =
                "true";

        } else {

            delete document.documentElement.dataset.offlineAuth;

        }

        document.dispatchEvent(
            new CustomEvent("bookwormAuthReady", {
                detail: {
                    user,
                    offline
                }
            })
        );

    }

    // ==========================================
    // REDIRECT TO LOGIN
    // ==========================================

    function redirectToLogin() {

        if (isLoginPage()) {
            return;
        }

        window.location.replace(LOGIN_PAGE);

    }

    // ==========================================
    // AUTHENTICATION CHECK
    // ==========================================

    async function checkAuthentication() {

        const supabaseClient =
            window.supabaseClient;

        // ======================================
        // SUPABASE CLIENT UNAVAILABLE
        // ======================================

        if (!supabaseClient) {

            if (isOffline()) {

                const stored =
                    hasStoredSupabaseSession();

                if (stored?.user) {

                    console.warn(
                        "Bookworm: Supabase unavailable. Using stored offline session."
                    );

                    markAuthenticated(
                        stored.user,
                        true
                    );

                    return;
                }

            }

            console.error(
                "Bookworm: Supabase client is unavailable."
            );

            redirectToLogin();

            return;
        }

        // ======================================
        // OFFLINE MODE
        // ======================================
        //
        // IMPORTANT:
        // Do NOT call getUser() while offline.
        //
        // getUser() performs a server-side
        // authentication request.
        //
        // If the device has no internet, that
        // request can fail even though the student
        // is still authenticated locally.
        // ======================================

        if (isOffline()) {

            try {

                const {
                    data: sessionData,
                    error: sessionError
                } = await supabaseClient.auth.getSession();

                const localSession =
                    sessionData?.session ||
                    hasStoredSupabaseSession();

                if (localSession?.user) {

                    console.log(
                        "Bookworm: Offline session accepted.",
                        localSession.user.id
                    );

                    markAuthenticated(
                        localSession.user,
                        true
                    );

                    return;
                }

                if (sessionError) {

                    console.warn(
                        "Bookworm: Offline session lookup failed.",
                        sessionError
                    );

                }

            } catch (error) {

                const stored =
                    hasStoredSupabaseSession();

                if (stored?.user) {

                    console.warn(
                        "Bookworm: Using stored session after offline lookup failure."
                    );

                    markAuthenticated(
                        stored.user,
                        true
                    );

                    return;
                }

                console.warn(
                    "Bookworm: No usable offline session.",
                    error
                );

            }

            redirectToLogin();

            return;
        }

        // ======================================
        // ONLINE MODE
        // ======================================
        //
        // When online, we keep the secure
        // Supabase authentication verification.
        // ======================================

        try {

            const {
                data,
                error
            } = await supabaseClient.auth.getUser();

            if (error) {

                console.error(
                    "Bookworm authentication error:",
                    error
                );

                /*
                 * If the connection disappeared while
                 * getUser() was running, don't redirect
                 * the student to Login.
                 */

                const stored =
                    hasStoredSupabaseSession();

                if (stored?.user) {

                    console.warn(
                        "Bookworm: Connection changed during authentication. Using stored session."
                    );

                    markAuthenticated(
                        stored.user,
                        true
                    );

                    return;
                }

                redirectToLogin();

                return;
            }

            const user = data?.user;

            if (!user) {

                console.warn(
                    "No authenticated Bookworm user."
                );

                redirectToLogin();

                return;
            }

            console.log(
                "Bookworm authentication verified:",
                user.id
            );

            markAuthenticated(
                user,
                false
            );

        } catch (error) {

            /*
             * Internet may disappear between
             * navigator.onLine and getUser().
             *
             * Use the stored session instead of
             * creating an authentication redirect loop.
             */

            const stored =
                hasStoredSupabaseSession();

            if (stored?.user) {

                console.warn(
                    "Bookworm: Connection changed during auth check. Using stored session."
                );

                markAuthenticated(
                    stored.user,
                    true
                );

                return;
            }

            console.error(
                "Unexpected authentication guard error:",
                error
            );

            redirectToLogin();

        }

    }

    // ==========================================
    // WAIT FOR SUPABASE
    // ==========================================

    function waitForSupabase() {

        if (!window.supabaseClient) {

            setTimeout(
                waitForSupabase,
                100
            );

            return;
        }

        checkAuthentication();

    }

    // ==========================================
    // INTERNET RESTORED
    // ==========================================

    window.addEventListener(
        "online",
        () => {

            document.documentElement.dataset.offlineAuth =
                "false";

            document.dispatchEvent(
                new CustomEvent(
                    "bookwormConnectionRestored"
                )
            );

            console.log(
                "Bookworm: Internet connection restored."
            );

        }
    );

    // ==========================================
    // INTERNET LOST
    // ==========================================

    window.addEventListener(
        "offline",
        () => {

            document.documentElement.dataset.offlineAuth =
                "true";

            document.dispatchEvent(
                new CustomEvent(
                    "bookwormOffline"
                )
            );

            console.log(
                "Bookworm: Device is now offline."
            );

        }
    );

    // ==========================================
    // START
    // ==========================================

    waitForSupabase();

})();