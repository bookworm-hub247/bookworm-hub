/* =========================================================
   BOOKWORM CLUB
   COURSE NOTE ENGINE
   200 LEVEL • FIRST SEMESTER

   VERSION:
   Premium Academic Course Reader

   FEATURES:
   • Structured course notes
   • Sequential modules
   • Free / Premium access metadata
   • Course progression metadata
   • Exam-focused learning
   • Student-friendly academic presentation
   • Premium entitlement compatibility
========================================================= */


/* =========================================================
   COURSE NOTE LIBRARY
========================================================= */

const noteLibrary = {


    /* =====================================================
       GST 212
       FREE COURSE
    ===================================================== */

    GST212: {

        code: "GST 212",

        title:
            "Philosophy, Logic and Human Existence",

        department:
            "General Studies",

        units: 2,

        access:
            "free",

        productCode:
            null,

        description:
            "A foundational study of philosophy, logical reasoning, major philosophical questions and human existence.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {


            /* =================================================
               MODULE 01
            ================================================= */

            "01": {

                number: "01",

                title:
                    "Introduction to Philosophy",

                access:
                    "free",

                description:
                    "An introduction to philosophy, its meaning, characteristics, branches, methods and relevance to human life.",

                learningObjectives: [

                    "Explain the meaning of philosophy.",

                    "Identify the major characteristics of philosophical thinking.",

                    "Explain the relationship between philosophy and everyday life.",

                    "Identify the major branches of philosophy.",

                    "Explain why philosophical thinking is important.",

                    "Distinguish philosophical questions from ordinary questions."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <p>
        At the end of this module, you should be able to:
    </p>

    <ul>

        <li>
            Explain the meaning of
            <strong>philosophy</strong>.
        </li>

        <li>
            Identify the major characteristics
            of philosophical thinking.
        </li>

        <li>
            Explain the relationship between
            philosophy and everyday life.
        </li>

        <li>
            Identify the major branches of
            philosophy.
        </li>

        <li>
            Explain why philosophical thinking
            is important.
        </li>

        <li>
            Distinguish philosophical questions
            from ordinary questions.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. Meaning of Philosophy</h2>

    <p>

        The word
        <strong>philosophy</strong>
        is derived from two Greek words:
        <em>philein</em>, meaning love, and
        <em>sophia</em>, meaning wisdom.

    </p>

    <p>

        Philosophy can therefore be understood
        literally as the
        <strong>love of wisdom</strong>.

    </p>

    <p>

        In academic usage, philosophy refers to
        the systematic and critical examination
        of fundamental questions concerning
        <strong>reality, knowledge, values,
        reasoning and human existence</strong>.

    </p>

    <div class="callout">

        <strong>KEY IDEA</strong>

        <p>

            Philosophy is not simply the possession
            of information. It involves the careful
            examination of ideas and the reasons
            supporting them.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>3. Philosophy as Critical Thinking</h2>

    <p>

        A philosophical thinker does not accept
        every claim simply because it is popular,
        traditional or made by an authority.

    </p>

    <p>

        Instead, philosophical thinking asks:

    </p>

    <ul>

        <li>
            What exactly is being claimed?
        </li>

        <li>
            What reasons support the claim?
        </li>

        <li>
            Are those reasons logically sound?
        </li>

        <li>
            Are there hidden assumptions?
        </li>

        <li>
            Is there evidence for the conclusion?
        </li>

    </ul>

    <p>

        This makes <strong>critical reasoning</strong>
        one of the central features of philosophical
        inquiry.

    </p>

</section>



<section class="lesson-section">

    <h2>4. Characteristics of Philosophy</h2>

    <h3>Critical</h3>

    <p>

        Philosophy critically examines beliefs,
        assumptions and arguments instead of
        accepting them automatically.

    </p>


    <h3>Rational</h3>

    <p>

        Philosophical arguments are expected to
        be supported by
        <strong>reason and logical justification</strong>.

    </p>


    <h3>Systematic</h3>

    <p>

        Philosophy attempts to organize ideas
        into a coherent and meaningful system.

    </p>


    <h3>Reflective</h3>

    <p>

        Philosophy encourages individuals to
        reflect carefully on fundamental issues
        concerning themselves and their world.

    </p>


    <h3>Universal</h3>

    <p>

        Many philosophical questions concern
        human beings generally, regardless of
        culture, location or historical period.

    </p>

</section>



<section class="lesson-section">

    <h2>5. Major Branches of Philosophy</h2>

    <div class="concept-card">

        <h3>Metaphysics</h3>

        <p>

            The branch of philosophy concerned
            with the nature of
            <strong>reality and existence</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Epistemology</h3>

        <p>

            The philosophical study of
            <strong>knowledge</strong>,
            including its sources, limits and
            justification.

        </p>

    </div>


    <div class="concept-card">

        <h3>Logic</h3>

        <p>

            The study of correct reasoning,
            argument structure and principles
            of valid inference.

        </p>

    </div>


    <div class="concept-card">

        <h3>Ethics</h3>

        <p>

            The branch concerned with
            <strong>morality, right action,
            wrong action and values</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Aesthetics</h3>

        <p>

            The philosophical study of
            beauty, art and aesthetic value.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>6. Philosophy and Everyday Life</h2>

    <p>

        Philosophy is not restricted to the
        classroom. People use philosophical
        reasoning whenever they evaluate beliefs,
        make important decisions or question
        assumptions.

    </p>

    <p>

        For example, a student deciding whether
        a particular claim is reliable may ask
        what evidence supports the claim.

        This is already an application of
        <strong>critical philosophical thinking</strong>.

    </p>

</section>



<section class="lesson-section">

    <h2>7. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Philosophy literally means
                <strong>love of wisdom</strong>.
            </li>

            <li>
                Philosophy involves systematic
                and critical examination.
            </li>

            <li>
                Major branches include
                <strong>Metaphysics, Epistemology,
                Logic, Ethics and Aesthetics</strong>.
            </li>

            <li>
                Philosophical reasoning requires
                reasons and justification.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>8. Examination Practice</h2>

    <ol>

        <li>
            Define philosophy.
        </li>

        <li>
            Explain four characteristics
            of philosophy.
        </li>

        <li>
            Discuss five major branches
            of philosophy.
        </li>

        <li>
            Explain the importance of
            philosophical thinking in
            everyday life.
        </li>

        <li>
            Distinguish philosophical
            questioning from ordinary
            questioning.
        </li>

    </ol>

</section>



<section class="lesson-section">

    <h2>9. Common Examination Mistakes</h2>

    <ul>

        <li>
            Giving only the literal meaning
            of philosophy when asked to define
            it academically.
        </li>

        <li>
            Listing branches of philosophy
            without explaining them.
        </li>

        <li>
            Confusing philosophy with
            personal opinion.
        </li>

        <li>
            Giving conclusions without
            providing reasons.
        </li>

    </ul>

</section>


`
            },


            /* =================================================
               MODULE 02
            ================================================= */

            "02": {

                number: "02",

                title:
                    "Logic and Critical Thinking",

                access:
                    "free",

                description:
                    "An introduction to logical reasoning, arguments, propositions, validity, soundness and common reasoning errors.",

                learningObjectives: [

                    "Define logic and explain its importance.",

                    "Distinguish arguments from non-arguments.",

                    "Identify premises and conclusions.",

                    "Explain validity and soundness.",

                    "Recognize common logical fallacies."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <p>
        At the end of this module, you should be able to:
    </p>

    <ul>

        <li>
            Define <strong>logic</strong>.
        </li>

        <li>
            Identify premises and conclusions.
        </li>

        <li>
            Distinguish arguments from
            non-arguments.
        </li>

        <li>
            Explain validity and soundness.
        </li>

        <li>
            Identify common logical fallacies.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. Meaning of Logic</h2>

    <p>

        <strong>Logic</strong> is the systematic
        study of correct reasoning.

    </p>

    <p>

        Logic helps us determine whether a
        conclusion follows properly from the
        reasons or premises provided.

    </p>

    <div class="callout">

        <strong>EXAM POINT</strong>

        <p>

            Logic is primarily concerned with
            the <strong>structure and correctness
            of reasoning</strong>.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>3. Arguments</h2>

    <p>

        An argument is a set of statements in
        which one or more statements are presented
        as reasons for accepting another statement.

    </p>

    <p>

        The statements providing support are
        called <strong>premises</strong>.

        The statement being supported is the
        <strong>conclusion</strong>.

    </p>

    <blockquote>

        Every student who studies consistently
        improves their understanding.

        Ada studies consistently.

        Therefore, Ada improves her understanding.

    </blockquote>

    <p>

        In this example, the first two statements
        function as premises, while the final
        statement is the conclusion.

    </p>

</section>



<section class="lesson-section">

    <h2>4. Validity and Soundness</h2>

    <h3>Validity</h3>

    <p>

        An argument is <strong>valid</strong>
        when its conclusion follows logically
        from its premises.

    </p>

    <h3>Soundness</h3>

    <p>

        An argument is <strong>sound</strong>
        when it is valid and its premises
        are actually true.

    </p>

    <div class="concept-card">

        <h3>Remember</h3>

        <p>

            <strong>Validity</strong> concerns
            the logical structure of an argument.

            <strong>Soundness</strong> requires
            both valid reasoning and true premises.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>5. Common Logical Fallacies</h2>

    <div class="concept-card">

        <h3>Ad Hominem</h3>

        <p>

            Attacking the person making an argument
            instead of addressing the argument itself.

        </p>

    </div>


    <div class="concept-card">

        <h3>Appeal to Popularity</h3>

        <p>

            Assuming that something is true simply
            because many people believe it.

        </p>

    </div>


    <div class="concept-card">

        <h3>False Dilemma</h3>

        <p>

            Presenting only two choices when
            additional possibilities exist.

        </p>

    </div>


    <div class="concept-card">

        <h3>Hasty Generalization</h3>

        <p>

            Drawing a broad conclusion from
            insufficient evidence.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>6. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Logic studies correct reasoning.
            </li>

            <li>
                An argument contains
                <strong>premises and a conclusion</strong>.
            </li>

            <li>
                Validity concerns logical structure.
            </li>

            <li>
                Soundness requires validity
                and true premises.
            </li>

            <li>
                Fallacies are errors in reasoning.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>7. Examination Practice</h2>

    <ol>

        <li>
            Define logic.
        </li>

        <li>
            What is an argument?
        </li>

        <li>
            Distinguish premises from conclusions.
        </li>

        <li>
            Explain the difference between
            validity and soundness.
        </li>

        <li>
            Discuss four common logical fallacies.
        </li>

    </ol>

</section>


`
            },


            /* =================================================
               MODULE 03
            ================================================= */

            "03": {

                number: "03",

                title:
                    "Human Existence",

                access:
                    "free",

                description:
                    "An examination of human existence, freedom, responsibility, meaning and major existential questions.",

                learningObjectives: [

                    "Explain the concept of human existence.",

                    "Identify major questions concerning human existence.",

                    "Explain freedom and responsibility.",

                    "Discuss the search for meaning."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <ul>

        <li>
            Explain human existence.
        </li>

        <li>
            Identify major existential questions.
        </li>

        <li>
            Explain freedom and responsibility.
        </li>

        <li>
            Discuss the human search for meaning.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. Understanding Human Existence</h2>

    <p>

        Human existence refers to the condition
        of being human and the experiences,
        choices, relationships and challenges
        associated with human life.

    </p>

    <p>

        Philosophers have long asked questions
        about the nature and purpose of human
        existence.

    </p>

    <div class="callout">

        <strong>CORE QUESTION</strong>

        <p>

            What does it mean to live a meaningful
            human life?

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>3. Freedom and Responsibility</h2>

    <p>

        Human beings often possess the ability
        to make choices.

        However, freedom is closely connected
        with <strong>responsibility</strong>.

    </p>

    <p>

        When individuals make choices, those
        choices may have consequences for
        themselves and for other people.

    </p>

</section>



<section class="lesson-section">

    <h2>4. The Search for Meaning</h2>

    <p>

        Human beings frequently seek meaning
        in their relationships, work, beliefs,
        education, goals and experiences.

    </p>

    <p>

        Questions about meaning therefore form
        an important part of philosophical
        reflection on existence.

    </p>

</section>



<section class="lesson-section">

    <h2>5. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Human existence concerns the
                condition and experience of
                being human.
            </li>

            <li>
                Freedom involves the ability
                to make choices.
            </li>

            <li>
                Freedom is connected with
                responsibility.
            </li>

            <li>
                Human beings often search
                for meaning and purpose.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>6. Examination Practice</h2>

    <ol>

        <li>
            Explain the meaning of human existence.
        </li>

        <li>
            Discuss the relationship between
            freedom and responsibility.
        </li>

        <li>
            Why is the search for meaning
            important to human beings?
        </li>

    </ol>

</section>


`
            },


            /* =================================================
               MODULE 04
            ================================================= */

            "04": {

                number: "04",

                title:
                    "Major Philosophical Questions",

                access:
                    "free",

                description:
                    "A revision-focused examination of major philosophical questions about reality, knowledge, morality and human existence.",

                learningObjectives: [

                    "Identify major philosophical questions.",

                    "Explain questions concerning reality.",

                    "Explain questions concerning knowledge.",

                    "Explain questions concerning morality."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <ul>

        <li>
            Identify major philosophical questions.
        </li>

        <li>
            Explain questions concerning reality.
        </li>

        <li>
            Explain questions concerning knowledge.
        </li>

        <li>
            Explain questions concerning morality.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. Questions About Reality</h2>

    <p>

        Philosophers ask questions such as:

    </p>

    <ul>

        <li>
            What is reality?
        </li>

        <li>
            Does reality exist independently
            of human perception?
        </li>

        <li>
            What does it mean for something
            to exist?
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>3. Questions About Knowledge</h2>

    <p>

        Epistemological questions include:

    </p>

    <ul>

        <li>
            What is knowledge?
        </li>

        <li>
            How do human beings acquire knowledge?
        </li>

        <li>
            Can human knowledge be certain?
        </li>

        <li>
            What are the limits of knowledge?
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>4. Questions About Morality</h2>

    <p>

        Ethical philosophy examines questions
        concerning right and wrong conduct.

    </p>

    <ul>

        <li>
            What makes an action right?
        </li>

        <li>
            What makes an action wrong?
        </li>

        <li>
            What is a good life?
        </li>

        <li>
            Are moral values universal?
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>5. Final GST 212 Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                <strong>Metaphysics</strong> —
                reality and existence.
            </li>

            <li>
                <strong>Epistemology</strong> —
                knowledge.
            </li>

            <li>
                <strong>Logic</strong> —
                correct reasoning.
            </li>

            <li>
                <strong>Ethics</strong> —
                morality and values.
            </li>

            <li>
                <strong>Aesthetics</strong> —
                beauty and art.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>6. Examination Practice</h2>

    <ol>

        <li>
            Discuss the major branches of philosophy.
        </li>

        <li>
            Explain the importance of logic
            to philosophical reasoning.
        </li>

        <li>
            Discuss three major questions
            concerning human existence.
        </li>

        <li>
            Explain the relationship between
            knowledge and philosophical inquiry.
        </li>

    </ol>

</section>


`
            }

        }

    },


    /* =====================================================
       PREMIUM COURSES BEGIN AFTER THIS SECTION
       
       IMPORTANT:
       All premium courses use:

       access: "premium"

       productCode:
       "200L_FIRST_SEMESTER_PREMIUM"

       The Reader will later use these values to
       determine whether a student may enter the
       next protected module.
    ===================================================== */


    ENG201: {

        code:
            "ENG 201",

        title:
            "Introduction to Morphology and Syntax",

        department:
            "English Language",

        units: 2,

        access:
            "premium",

        productCode:
            "200L_FIRST_SEMESTER_PREMIUM",

        description:
            "A systematic introduction to the study of word structure, morphemes, word formation, syntax and sentence structure.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {


            /* =============================================
               MODULE 01
            ============================================= */

            "01": {

                number: "01",

                title:
                    "Introduction to Morphology",

                access:
                    "premium",

                preview:
                    true,

                description:
                    "Introduction to morphology, morphemes, words and the study of internal word structure.",

                learningObjectives: [

                    "Define morphology.",

                    "Explain the concept of a morpheme.",

                    "Distinguish words from morphemes.",

                    "Identify basic morphological structures."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <ul>

        <li>
            Define <strong>morphology</strong>.
        </li>

        <li>
            Explain the concept of a
            <strong>morpheme</strong>.
        </li>

        <li>
            Distinguish words from morphemes.
        </li>

        <li>
            Identify basic morphological structures.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. What is Morphology?</h2>

    <p>

        <strong>Morphology</strong> is the branch
        of linguistics concerned with the internal
        structure of words and the ways in which
        words are formed.

    </p>

    <p>

        The smallest meaningful units that combine
        to form words are called
        <strong>morphemes</strong>.

    </p>

    <div class="callout">

        <strong>EXAM POINT</strong>

        <p>

            Morphology studies
            <strong>word structure and word formation</strong>.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>3. The Morpheme</h2>

    <p>

        A <strong>morpheme</strong> is the smallest
        linguistic unit that carries meaning or
        performs a grammatical function.

    </p>

    <p>

        For example, the word
        <strong>unhappy</strong> can be divided into:

    </p>

    <blockquote>

        un + happy

    </blockquote>

    <p>

        The element <strong>un-</strong> contributes
        meaning, while <strong>happy</strong>
        carries the lexical meaning of the word.

    </p>

</section>



<section class="lesson-section">

    <h2>4. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Morphology is the study of
                <strong>word structure</strong>.
            </li>

            <li>
                A morpheme is the smallest
                meaningful or grammatical unit.
            </li>

            <li>
                Words may contain one or more
                morphemes.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>5. Examination Practice</h2>

    <ol>

        <li>
            Define morphology.
        </li>

        <li>
            What is a morpheme?
        </li>

        <li>
            Explain the relationship between
            morphology and word formation.
        </li>

    </ol>

</section>


`
            },


            /* =============================================
               MODULE 02
            ============================================= */

            "02": {

                number: "02",

                title:
                    "Morpheme Classification and Word Formation",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "A deeper study of free and bound morphemes, roots, stems, affixes and major word-formation processes.",

                learningObjectives: [

                    "Distinguish free and bound morphemes.",

                    "Identify roots, stems and affixes.",

                    "Explain derivational and inflectional morphology.",

                    "Describe major word-formation processes."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <ul>

        <li>
            Distinguish <strong>free</strong>
            and <strong>bound morphemes</strong>.
        </li>

        <li>
            Identify roots, stems and affixes.
        </li>

        <li>
            Explain derivational and
            inflectional morphology.
        </li>

        <li>
            Describe major word-formation
            processes.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. Free and Bound Morphemes</h2>

    <h3>Free Morphemes</h3>

    <p>

        A free morpheme can occur independently
        as a word.

        Examples include:

    </p>

    <ul>

        <li>book</li>
        <li>school</li>
        <li>run</li>
        <li>happy</li>

    </ul>


    <h3>Bound Morphemes</h3>

    <p>

        A bound morpheme cannot normally occur
        independently and must attach to another
        linguistic element.

    </p>

    <ul>

        <li>un-</li>
        <li>-ness</li>
        <li>-ed</li>
        <li>-s</li>

    </ul>

</section>



<section class="lesson-section">

    <h2>3. Derivational and Inflectional Morphemes</h2>

    <div class="concept-card">

        <h3>Derivational Morphology</h3>

        <p>

            Derivational morphemes can create a
            new word or change the grammatical
            category of a word.

        </p>

        <p>

            Example:
            <strong>happy → happiness</strong>

        </p>

    </div>


    <div class="concept-card">

        <h3>Inflectional Morphology</h3>

        <p>

            Inflectional morphemes express
            grammatical information without
            normally creating a new lexical item.

        </p>

        <p>

            Examples include plural
            <strong>-s</strong> and past tense
            <strong>-ed</strong>.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>4. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Free morphemes can stand alone.
            </li>

            <li>
                Bound morphemes require attachment.
            </li>

            <li>
                Derivational morphology can create
                new words.
            </li>

            <li>
                Inflectional morphology expresses
                grammatical information.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>5. Examination Practice</h2>

    <ol>

        <li>
            Distinguish free and bound morphemes.
        </li>

        <li>
            Explain derivational morphology.
        </li>

        <li>
            Explain inflectional morphology.
        </li>

        <li>
            Distinguish derivational and
            inflectional morphemes with examples.
        </li>

    </ol>

</section>


`
            },


            /* =============================================
               MODULE 03
            ============================================= */

            "03": {

                number: "03",

                title:
                    "Introduction to Syntax",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "Introduction to syntax, grammatical structure, constituents, phrases and syntactic relationships.",

                content: `


<section class="lesson-section">

    <h2>1. What is Syntax?</h2>

    <p>

        <strong>Syntax</strong> is the branch
        of linguistics concerned with the way
        words combine to form phrases,
        clauses and sentences.

    </p>

    <p>

        Syntax explains why some arrangements
        of words are grammatically acceptable
        while others are not.

    </p>

</section>



<section class="lesson-section">

    <h2>2. Constituents</h2>

    <p>

        A <strong>constituent</strong> is a group
        of words that functions together as a
        structural unit within a sentence.

    </p>

    <blockquote>

        The intelligent student
        passed the examination.

    </blockquote>

    <p>

        The phrase
        <strong>the intelligent student</strong>
        functions as a constituent.

    </p>

</section>



<section class="lesson-section">

    <h2>3. Phrases</h2>

    <ul>

        <li>
            Noun Phrase (NP)
        </li>

        <li>
            Verb Phrase (VP)
        </li>

        <li>
            Adjective Phrase (AdjP)
        </li>

        <li>
            Adverb Phrase (AdvP)
        </li>

        <li>
            Prepositional Phrase (PP)
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>4. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Syntax studies sentence structure.
            </li>

            <li>
                Constituents are structural units.
            </li>

            <li>
                Phrases contain one or more words
                functioning together.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>5. Examination Practice</h2>

    <ol>

        <li>
            Define syntax.
        </li>

        <li>
            Explain the concept of a constituent.
        </li>

        <li>
            Identify five major phrase types.
        </li>

    </ol>

</section>


`
            },


            /* =============================================
               MODULE 04
            ============================================= */

            "04": {

                number: "04",

                title:
                    "Sentence Structure and Syntactic Analysis",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "A structured introduction to sentence constituents, phrase structure and basic syntactic analysis.",

                content: `


<section class="lesson-section">

    <h2>1. Sentence Structure</h2>

    <p>

        Sentences are not random sequences of
        words. They contain structural relationships
        between constituents.

    </p>

    <p>

        A common simplified representation
        of English sentence structure is:

    </p>

    <blockquote>

        Sentence → Noun Phrase + Verb Phrase

    </blockquote>

</section>



<section class="lesson-section">

    <h2>2. Basic Syntactic Analysis</h2>

    <p>

        Consider:

    </p>

    <blockquote>

        The student reads books.

    </blockquote>

    <p>

        A simplified analysis is:

    </p>

    <ul>

        <li>
            <strong>The student</strong> —
            Noun Phrase
        </li>

        <li>
            <strong>reads books</strong> —
            Verb Phrase
        </li>

        <li>
            <strong>books</strong> —
            Noun Phrase functioning as object
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>3. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Sentences have internal structure.
            </li>

            <li>
                Constituents combine according
                to grammatical rules.
            </li>

            <li>
                Phrase-structure analysis helps
                reveal sentence organization.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>4. Examination Practice</h2>

    <ol>

        <li>
            Explain sentence structure.
        </li>

        <li>
            Analyse the constituents in:
            "The intelligent student passed
            the examination."
        </li>

        <li>
            Explain the rule:
            Sentence → Noun Phrase + Verb Phrase.
        </li>

    </ol>

</section>


`
            }

        }

    },


    /* =====================================================
       MORE COURSES WILL FOLLOW
       
       NEXT PART:
       ENG 203 — INTRODUCTION TO GENERAL PHONETICS
       AND PHONOLOGY
    ===================================================== */


        /* =====================================================
       ENG 203
       INTRODUCTION TO GENERAL PHONETICS AND PHONOLOGY
       PREMIUM COURSE
    ===================================================== */

    ENG203: {

        code:
            "ENG 203",

        title:
            "Introduction to General Phonetics and Phonology",

        department:
            "English Language",

        units: 2,

        access:
            "premium",

        productCode:
            "200L_FIRST_SEMESTER_PREMIUM",

        description:
            "A systematic introduction to the production, classification and transcription of speech sounds, together with the basic principles of phonological analysis.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {


            /* =================================================
               MODULE 01
            ================================================= */

            "01": {

                number: "01",

                title:
                    "Foundations of Phonetics",

                access:
                    "premium",

                preview:
                    true,

                description:
                    "Introduction to phonetics, the speech mechanism, articulatory processes and the classification of speech sounds.",

                learningObjectives: [

                    "Define phonetics.",

                    "Distinguish articulatory, acoustic and auditory phonetics.",

                    "Explain the mechanism of speech production.",

                    "Identify the major organs of speech.",

                    "Distinguish active and passive articulators."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <p>
        At the end of this module, you should be able to:
    </p>

    <ul>

        <li>
            Define <strong>phonetics</strong>.
        </li>

        <li>
            Distinguish articulatory, acoustic
            and auditory phonetics.
        </li>

        <li>
            Explain the mechanism of
            <strong>speech production</strong>.
        </li>

        <li>
            Identify the major
            <strong>organs of speech</strong>.
        </li>

        <li>
            Distinguish active and passive
            articulators.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. Meaning of Phonetics</h2>

    <p>

        <strong>Phonetics</strong> is the branch
        of linguistics concerned with the physical
        properties of speech sounds.

    </p>

    <p>

        It investigates how speech sounds are
        <strong>produced</strong>,
        <strong>transmitted</strong> and
        <strong>perceived</strong>.

    </p>

    <div class="callout">

        <strong>EXAM POINT</strong>

        <p>

            Phonetics deals with the
            <strong>physical aspects of speech sounds</strong>.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>3. Major Branches of Phonetics</h2>

    <div class="concept-card">

        <h3>Articulatory Phonetics</h3>

        <p>

            The study of how speech sounds are
            produced by the movement and interaction
            of the speech organs.

        </p>

    </div>


    <div class="concept-card">

        <h3>Acoustic Phonetics</h3>

        <p>

            The study of the physical properties
            of speech sounds as sound waves.

        </p>

    </div>


    <div class="concept-card">

        <h3>Auditory Phonetics</h3>

        <p>

            The study of how speech sounds are
            received and interpreted by the
            auditory system.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>4. The Speech Mechanism</h2>

    <p>

        Human speech is produced through a
        coordinated system involving the
        <strong>respiratory system</strong>,
        <strong>larynx</strong> and
        <strong>vocal tract</strong>.

    </p>

    <p>

        Air from the lungs provides the energy
        required for most speech sounds.

        The airstream passes upward through
        the respiratory tract and can be modified
        by the organs involved in articulation.

    </p>

    <div class="concept-card">

        <h3>Basic Process</h3>

        <p>

            Lungs → Trachea → Larynx →
            Pharynx → Oral/Nasal Cavity

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>5. Major Organs of Speech</h2>

    <ul>

        <li>
            <strong>Lungs</strong> —
            provide the airstream.
        </li>

        <li>
            <strong>Vocal folds</strong> —
            play an important role in voicing.
        </li>

        <li>
            <strong>Pharynx</strong> —
            serves as part of the passage
            through which the airstream travels.
        </li>

        <li>
            <strong>Tongue</strong> —
            one of the most important articulators.
        </li>

        <li>
            <strong>Teeth</strong> —
            participate in the articulation
            of several consonants.
        </li>

        <li>
            <strong>Alveolar ridge</strong> —
            important in the production of
            alveolar sounds.
        </li>

        <li>
            <strong>Hard palate</strong> —
            forms part of the roof of the mouth.
        </li>

        <li>
            <strong>Soft palate</strong> —
            also called the velum.
        </li>

        <li>
            <strong>Lips</strong> —
            important in the production of
            bilabial and labiodental sounds.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>6. Active and Passive Articulators</h2>

    <p>

        An <strong>active articulator</strong>
        is an articulatory organ capable of
        moving towards another articulator.

    </p>

    <p>

        A <strong>passive articulator</strong>
        is a relatively stationary surface
        towards which an active articulator
        moves.

    </p>

    <div class="concept-card">

        <h3>Example</h3>

        <p>

            In the production of an alveolar sound,
            the <strong>tongue</strong> acts as the
            active articulator while the
            <strong>alveolar ridge</strong> acts
            as the passive articulator.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>7. Why Phonetics Matters</h2>

    <p>

        Phonetics is essential to the scientific
        study of spoken language.

    </p>

    <p>

        It is particularly important in
        pronunciation teaching, language description,
        speech therapy, language research and
        phonological analysis.

    </p>

</section>



<section class="lesson-section">

    <h2>8. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Phonetics studies the physical
                properties of speech sounds.
            </li>

            <li>
                The three major branches are
                <strong>articulatory, acoustic
                and auditory phonetics</strong>.
            </li>

            <li>
                The lungs provide the main
                airstream for speech.
            </li>

            <li>
                The tongue is a major articulator.
            </li>

            <li>
                Articulators may be active
                or passive.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>9. Examination Practice</h2>

    <ol>

        <li>
            Define phonetics.
        </li>

        <li>
            Discuss the three major branches
            of phonetics.
        </li>

        <li>
            Explain the mechanism of speech
            production.
        </li>

        <li>
            Identify and explain five organs
            of speech.
        </li>

        <li>
            Distinguish active articulators
            from passive articulators.
        </li>

    </ol>

</section>



<section class="lesson-section">

    <h2>10. Common Examination Mistakes</h2>

    <ul>

        <li>
            Confusing phonetics with phonology.
        </li>

        <li>
            Listing organs of speech without
            explaining their functions.
        </li>

        <li>
            Treating all articulators as active.
        </li>

        <li>
            Forgetting that acoustic phonetics
            focuses on the physical properties
            of sound waves.
        </li>

    </ul>

</section>


`
            },


            /* =================================================
               MODULE 02
            ================================================= */

            "02": {

                number: "02",

                title:
                    "Consonants: Place, Manner and Voicing",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "A detailed study of consonants according to place of articulation, manner of articulation and voicing.",

                learningObjectives: [

                    "Define consonants.",

                    "Explain place of articulation.",

                    "Explain manner of articulation.",

                    "Distinguish voiced and voiceless sounds.",

                    "Classify consonants using phonetic descriptions."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <ul>

        <li>
            Define <strong>consonants</strong>.
        </li>

        <li>
            Explain <strong>place of articulation</strong>.
        </li>

        <li>
            Explain <strong>manner of articulation</strong>.
        </li>

        <li>
            Distinguish voiced and voiceless sounds.
        </li>

        <li>
            Classify consonants using
            phonetic descriptions.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. What is a Consonant?</h2>

    <p>

        A <strong>consonant</strong> is a speech
        sound produced with some degree of
        obstruction or narrowing of the airstream
        in the vocal tract.

    </p>

    <p>

        Consonants are commonly described using
        three major features:

    </p>

    <ol>

        <li>
            <strong>Place of articulation</strong>
        </li>

        <li>
            <strong>Manner of articulation</strong>
        </li>

        <li>
            <strong>Voicing</strong>
        </li>

    </ol>

</section>



<section class="lesson-section">

    <h2>3. Place of Articulation</h2>

    <p>

        Place of articulation refers to the
        location in the vocal tract where the
        major constriction for a consonant is made.

    </p>


    <div class="concept-card">

        <h3>Bilabial</h3>

        <p>

            Produced using both lips.

            Examples:
            <strong>/p/, /b/, /m/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Labiodental</h3>

        <p>

            Produced using the lower lip and
            upper teeth.

            Examples:
            <strong>/f/, /v/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Dental</h3>

        <p>

            Produced with the tongue in relation
            to the teeth.

            Common English examples include
            <strong>/θ/ and /ð/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Alveolar</h3>

        <p>

            Produced at or near the alveolar ridge.

            Examples include
            <strong>/t/, /d/, /s/, /z/, /n/, /l/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Postalveolar</h3>

        <p>

            Produced slightly behind the alveolar
            ridge.

            English examples include
            <strong>/ʃ/, /ʒ/, /tʃ/, /dʒ/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Palatal</h3>

        <p>

            Produced with the tongue approaching
            the hard palate.

            A common English example is
            <strong>/j/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Velar</h3>

        <p>

            Produced with the back of the tongue
            against or near the soft palate.

            Examples:
            <strong>/k/, /g/, /ŋ/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Glottal</h3>

        <p>

            Produced at the glottis.

            A common example is
            <strong>/h/</strong>.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>4. Manner of Articulation</h2>

    <p>

        Manner of articulation describes
        <strong>how the airstream is modified</strong>
        during the production of a consonant.

    </p>


    <div class="concept-card">

        <h3>Plosives</h3>

        <p>

            The airstream is completely blocked
            for a short period and then released.

            Examples:
            <strong>/p/, /b/, /t/, /d/, /k/, /g/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Fricatives</h3>

        <p>

            Air passes through a narrow constriction,
            producing audible friction.

            Examples:
            <strong>/f/, /v/, /s/, /z/, /ʃ/, /ʒ/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Affricates</h3>

        <p>

            These begin with a complete closure
            and continue with frication.

            Examples:
            <strong>/tʃ/ and /dʒ/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Nasals</h3>

        <p>

            The oral passage is blocked while air
            escapes through the nose.

            Examples:
            <strong>/m/, /n/, /ŋ/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Lateral</h3>

        <p>

            Air escapes around the sides of the
            tongue.

            English example:
            <strong>/l/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Approximants</h3>

        <p>

            The articulators approach each other
            without producing the degree of
            constriction associated with fricatives.

            Examples include
            <strong>/r/, /j/, /w/</strong>.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>5. Voicing</h2>

    <p>

        <strong>Voicing</strong> refers to the
        vibration of the vocal folds during the
        production of a speech sound.

    </p>

    <div class="concept-card">

        <h3>Voiced Sounds</h3>

        <p>

            The vocal folds vibrate.

            Examples:
            <strong>/b/, /d/, /g/, /v/, /z/</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Voiceless Sounds</h3>

        <p>

            The vocal folds do not vibrate.

            Examples:
            <strong>/p/, /t/, /k/, /f/, /s/</strong>.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>6. How to Describe a Consonant</h2>

    <p>

        A complete phonetic description normally
        identifies:

    </p>

    <blockquote>

        <strong>Voicing + Place + Manner</strong>

    </blockquote>

    <p>

        For example:

    </p>

    <div class="concept-card">

        <h3>/b/</h3>

        <p>

            <strong>Voiced bilabial plosive</strong>.

        </p>

    </div>

    <div class="concept-card">

        <h3>/f/</h3>

        <p>

            <strong>Voiceless labiodental fricative</strong>.

        </p>

    </div>

    <div class="concept-card">

        <h3>/m/</h3>

        <p>

            <strong>Voiced bilabial nasal</strong>.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>7. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Consonants involve some degree
                of obstruction or narrowing.
            </li>

            <li>
                Place tells us
                <strong>where</strong> articulation occurs.
            </li>

            <li>
                Manner tells us
                <strong>how</strong> the airstream
                is modified.
            </li>

            <li>
                Voicing tells us whether the
                vocal folds vibrate.
            </li>

            <li>
                A full consonant description
                combines these features.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>8. Examination Practice</h2>

    <ol>

        <li>
            Define a consonant.
        </li>

        <li>
            Explain place of articulation.
        </li>

        <li>
            Explain manner of articulation.
        </li>

        <li>
            Distinguish voiced and voiceless
            consonants.
        </li>

        <li>
            Describe /b/ using place, manner
            and voicing.
        </li>

        <li>
            Describe /ŋ/ phonetically.
        </li>

    </ol>

</section>



<section class="lesson-section">

    <h2>9. Common Examination Mistakes</h2>

    <ul>

        <li>
            Confusing place with manner.
        </li>

        <li>
            Writing "voiced" when describing
            the place of articulation.
        </li>

        <li>
            Forgetting to mention voicing.
        </li>

        <li>
            Confusing /ʃ/ with /s/.
        </li>

    </ul>

</section>


`
            },


            /* =================================================
               MODULE 03
            ================================================= */

            "03": {

                number: "03",

                title:
                    "Vowels, Diphthongs and Syllable Structure",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "A systematic study of vowel classification, monophthongs, diphthongs and basic syllable structure.",

                learningObjectives: [

                    "Define vowels.",

                    "Explain vowel classification.",

                    "Distinguish monophthongs from diphthongs.",

                    "Explain syllable structure.",

                    "Identify onset, nucleus and coda."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <ul>

        <li>
            Define <strong>vowels</strong>.
        </li>

        <li>
            Explain vowel classification.
        </li>

        <li>
            Distinguish monophthongs
            from diphthongs.
        </li>

        <li>
            Explain syllable structure.
        </li>

        <li>
            Identify onset, nucleus and coda.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. What is a Vowel?</h2>

    <p>

        A <strong>vowel</strong> is a speech sound
        produced with a relatively open vocal tract,
        allowing the airstream to pass without the
        type of obstruction characteristic of
        consonants.

    </p>

    <p>

        Vowels are commonly classified according
        to the position of the tongue, the position
        of the lips and other articulatory properties.

    </p>

</section>



<section class="lesson-section">

    <h2>3. Vowel Classification</h2>

    <p>

        Important dimensions of vowel classification
        include:

    </p>

    <ul>

        <li>
            <strong>Tongue height</strong>
        </li>

        <li>
            <strong>Tongue position</strong>
        </li>

        <li>
            <strong>Lip position</strong>
        </li>

        <li>
            <strong>Vowel length</strong>
        </li>

    </ul>


    <div class="concept-card">

        <h3>Tongue Height</h3>

        <p>

            The tongue may be positioned relatively
            high, mid or low in the mouth.

        </p>

    </div>


    <div class="concept-card">

        <h3>Tongue Position</h3>

        <p>

            Vowels may be classified as
            front, central or back according
            to the position of the tongue.

        </p>

    </div>


    <div class="concept-card">

        <h3>Lip Position</h3>

        <p>

            The lips may be rounded or unrounded
            during vowel production.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>4. Monophthongs</h2>

    <p>

        A <strong>monophthong</strong> is a vowel
        with relatively stable articulatory quality
        throughout its production.

    </p>

    <p>

        It is commonly described as a
        <strong>pure vowel</strong>.

    </p>

</section>



<section class="lesson-section">

    <h2>5. Diphthongs</h2>

    <p>

        A <strong>diphthong</strong> is a vowel
        sound involving a movement from one vowel
        quality towards another within the same
        syllable.

    </p>

    <div class="callout">

        <strong>REMEMBER</strong>

        <p>

            A monophthong has relatively stable
            vowel quality, while a diphthong
            involves noticeable movement.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>6. Syllable Structure</h2>

    <p>

        A syllable may be analysed into
        three major components:

    </p>

    <ul>

        <li>
            <strong>Onset</strong>
        </li>

        <li>
            <strong>Nucleus</strong>
        </li>

        <li>
            <strong>Coda</strong>
        </li>

    </ul>


    <div class="concept-card">

        <h3>Onset</h3>

        <p>

            The consonant or consonant sequence
            occurring before the nucleus.

        </p>

    </div>


    <div class="concept-card">

        <h3>Nucleus</h3>

        <p>

            The central and usually most sonorous
            part of a syllable.

        </p>

    </div>


    <div class="concept-card">

        <h3>Coda</h3>

        <p>

            The consonant or consonant sequence
            occurring after the nucleus.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>7. Worked Example</h2>

    <p>

        Consider the word:

    </p>

    <blockquote>

        cat

    </blockquote>

    <p>

        A simplified syllable analysis is:

    </p>

    <ul>

        <li>
            <strong>/k/</strong> —
            onset
        </li>

        <li>
            <strong>/æ/</strong> —
            nucleus
        </li>

        <li>
            <strong>/t/</strong> —
            coda
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>8. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Vowels are produced with
                relatively unobstructed airflow.
            </li>

            <li>
                Vowels can be classified by
                tongue height and position,
                lip position and other features.
            </li>

            <li>
                A monophthong has relatively
                stable vowel quality.
            </li>

            <li>
                A diphthong involves movement
                between vowel qualities.
            </li>

            <li>
                A syllable may contain onset,
                nucleus and coda.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>9. Examination Practice</h2>

    <ol>

        <li>
            Define a vowel.
        </li>

        <li>
            Explain four criteria used in
            vowel classification.
        </li>

        <li>
            Distinguish monophthongs from
            diphthongs.
        </li>

        <li>
            Explain onset, nucleus and coda.
        </li>

        <li>
            Analyse the syllable structure
            of a suitable English word.
        </li>

    </ol>

</section>


`
            },


            /* =================================================
               MODULE 04
            ================================================= */

            "04": {

                number: "04",

                title:
                    "Phonology, Phonemes and Phonetic Transcription",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "Introduction to phonology, phonemes, allophones, minimal pairs and the use of the International Phonetic Alphabet.",

                learningObjectives: [

                    "Define phonology.",

                    "Distinguish phonetics from phonology.",

                    "Define phoneme and allophone.",

                    "Explain minimal pairs.",

                    "Explain broad and narrow transcription."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <ul>

        <li>
            Define <strong>phonology</strong>.
        </li>

        <li>
            Distinguish phonetics from phonology.
        </li>

        <li>
            Define <strong>phoneme</strong>
            and <strong>allophone</strong>.
        </li>

        <li>
            Explain <strong>minimal pairs</strong>.
        </li>

        <li>
            Explain broad and narrow transcription.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. Meaning of Phonology</h2>

    <p>

        <strong>Phonology</strong> is the branch
        of linguistics concerned with the
        organization and patterning of sounds
        within a particular language.

    </p>

    <p>

        While phonetics focuses on the physical
        properties of speech sounds, phonology
        focuses on how those sounds function
        within a linguistic system.

    </p>

    <div class="callout">

        <strong>IMPORTANT DISTINCTION</strong>

        <p>

            <strong>Phonetics</strong> =
            physical properties of speech sounds.

            <br><br>

            <strong>Phonology</strong> =
            organization and function of sounds
            within a language.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>3. The Phoneme</h2>

    <p>

        A <strong>phoneme</strong> is a
        contrastive sound unit in a particular
        language.

    </p>

    <p>

        Changing one phoneme for another may
        result in a change of meaning.

    </p>

</section>



<section class="lesson-section">

    <h2>4. Minimal Pairs</h2>

    <p>

        A <strong>minimal pair</strong> consists
        of two words that differ in meaning and
        differ in only one phonological element
        in the relevant position.

    </p>

    <div class="concept-card">

        <h3>Example</h3>

        <p>

            <strong>pin</strong> and
            <strong>bin</strong>

        </p>

        <p>

            The contrast between
            <strong>/p/</strong> and
            <strong>/b/</strong>
            demonstrates that these sounds
            can function contrastively in English.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>5. Allophones</h2>

    <p>

        <strong>Allophones</strong> are different
        phonetic realizations of the same phoneme
        that do not normally create a difference
        in meaning.

    </p>

    <p>

        The relationship between phonemes and
        allophones is therefore important in
        phonological analysis.

    </p>

</section>



<section class="lesson-section">

    <h2>6. The International Phonetic Alphabet</h2>

    <p>

        The <strong>International Phonetic Alphabet
        (IPA)</strong> is a system of symbols
        designed to represent speech sounds.

    </p>

    <p>

        IPA allows linguists and language students
        to represent pronunciation more precisely
        than ordinary spelling.

    </p>

</section>



<section class="lesson-section">

    <h2>7. Broad and Narrow Transcription</h2>

    <div class="concept-card">

        <h3>Broad Transcription</h3>

        <p>

            Broad transcription represents the
            significant phonological units of
            a language without recording every
            fine phonetic detail.

        </p>

        <p>

            It is commonly written between
            <strong>/ /</strong>.

        </p>

    </div>


    <div class="concept-card">

        <h3>Narrow Transcription</h3>

        <p>

            Narrow transcription records
            additional phonetic detail.

        </p>

        <p>

            It is commonly written between
            <strong>[ ]</strong>.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>8. Worked Example</h2>

    <p>

        Consider:

    </p>

    <blockquote>

        pin — bin

    </blockquote>

    <p>

        The words differ in one sound:

    </p>

    <blockquote>

        /p/ — /b/

    </blockquote>

    <p>

        Because the substitution changes the
        meaning, the sounds demonstrate a
        phonological contrast in English.

    </p>

</section>



<section class="lesson-section">

    <h2>9. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Phonology studies the organization
                of sounds in a language.
            </li>

            <li>
                A phoneme is a contrastive
                sound unit.
            </li>

            <li>
                Minimal pairs demonstrate
                phonological contrast.
            </li>

            <li>
                Allophones are phonetic
                realizations of a phoneme.
            </li>

            <li>
                IPA provides a standardized
                system for representing speech sounds.
            </li>

            <li>
                Broad transcription is less
                phonetically detailed than
                narrow transcription.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>10. Examination Practice</h2>

    <ol>

        <li>
            Define phonology.
        </li>

        <li>
            Distinguish phonetics from phonology.
        </li>

        <li>
            Explain the concept of a phoneme.
        </li>

        <li>
            What is a minimal pair?
        </li>

        <li>
            Explain the relationship between
            phonemes and allophones.
        </li>

        <li>
            Distinguish broad and narrow
            transcription.
        </li>

    </ol>

</section>



<section class="lesson-section">

    <h2>11. ENG 203 Final Revision Checklist</h2>

    <div class="revision-box">

        <ul>

            <li>
                ☐ Meaning and branches of phonetics
            </li>

            <li>
                ☐ Speech mechanism
            </li>

            <li>
                ☐ Organs of speech
            </li>

            <li>
                ☐ Place of articulation
            </li>

            <li>
                ☐ Manner of articulation
            </li>

            <li>
                ☐ Voicing
            </li>

            <li>
                ☐ Vowel classification
            </li>

            <li>
                ☐ Monophthongs and diphthongs
            </li>

            <li>
                ☐ Syllable structure
            </li>

            <li>
                ☐ Phonology
            </li>

            <li>
                ☐ Phonemes and allophones
            </li>

            <li>
                ☐ Minimal pairs
            </li>

            <li>
                ☐ IPA transcription
            </li>

        </ul>

    </div>

</section>


`
            }

        }

    },


    /* =====================================================
       NEXT PART:
       ENL 210
       EDU 211
       EDU 201
       EDU 212
       ENT 211
       ENG 205
       LAS 244

       Then:
       • course sequencing configuration
       • premium progression rules
       • Reader object
    ===================================================== */

        /* =====================================================
       ENL 210
       PREMIUM COURSE
    ===================================================== */

    ENL210: {

        code:
            "ENL 210",

        title:
            "English Language",

        department:
            "English Language",

        units: 2,

        access:
            "premium",

        productCode:
            "200L_FIRST_SEMESTER_PREMIUM",

        description:
            "A structured study of English language concepts, usage, structure and communication with emphasis on university-level examination preparation.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {


            /* =================================================
               MODULE 01
            ================================================= */

            "01": {

                number: "01",

                title:
                    "Language and Human Communication",

                access:
                    "premium",

                preview:
                    true,

                description:
                    "Introduction to language, its characteristics, functions and role in human communication.",

                learningObjectives: [

                    "Define language.",

                    "Explain the major characteristics of human language.",

                    "Discuss the functions of language.",

                    "Explain the relationship between language and society."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Learning Objectives</h2>

    <ul>

        <li>
            Define <strong>language</strong>.
        </li>

        <li>
            Explain the major characteristics
            of human language.
        </li>

        <li>
            Discuss the functions of language.
        </li>

        <li>
            Explain the relationship between
            language and society.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>2. Meaning of Language</h2>

    <p>

        <strong>Language</strong> is a systematic
        means of human communication involving
        symbols, sounds and structures through
        which people express and interpret meaning.

    </p>

    <p>

        Language enables people to communicate
        ideas, emotions, experiences, instructions,
        beliefs and knowledge.

    </p>

    <div class="callout">

        <strong>EXAM POINT</strong>

        <p>

            Language is not merely a collection
            of words. It is a
            <strong>structured system</strong>
            governed by patterns and conventions.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>3. Characteristics of Human Language</h2>

    <div class="concept-card">

        <h3>Arbitrariness</h3>

        <p>

            There is generally no natural connection
            between a linguistic form and the meaning
            it represents.

        </p>

    </div>


    <div class="concept-card">

        <h3>Productivity</h3>

        <p>

            Human beings can use language to produce
            and understand an enormous number of
            expressions.

        </p>

    </div>


    <div class="concept-card">

        <h3>Displacement</h3>

        <p>

            Language allows people to communicate
            about things that are not immediately
            present.

        </p>

    </div>


    <div class="concept-card">

        <h3>Cultural Transmission</h3>

        <p>

            Language is acquired through interaction
            with members of a linguistic community.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>4. Functions of Language</h2>

    <ul>

        <li>
            <strong>Informative function</strong> —
            giving information.
        </li>

        <li>
            <strong>Expressive function</strong> —
            expressing feelings and attitudes.
        </li>

        <li>
            <strong>Directive function</strong> —
            influencing another person's behaviour.
        </li>

        <li>
            <strong>Social function</strong> —
            establishing and maintaining relationships.
        </li>

        <li>
            <strong>Imaginative function</strong> —
            creating fictional or imaginative worlds.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>5. Language and Society</h2>

    <p>

        Language is closely connected to society.
        Speakers use language differently depending
        on factors such as age, education, occupation,
        location, social relationships and context.

    </p>

    <p>

        This explains why language variation occurs
        across different communities and situations.

    </p>

</section>



<section class="lesson-section">

    <h2>6. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Language is a systematic means
                of human communication.
            </li>

            <li>
                Human language has characteristics
                such as arbitrariness, productivity
                and displacement.
            </li>

            <li>
                Language performs several
                communicative functions.
            </li>

            <li>
                Language and society are closely
                interconnected.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>7. Examination Practice</h2>

    <ol>

        <li>
            Define language.
        </li>

        <li>
            Discuss five characteristics
            of human language.
        </li>

        <li>
            Explain four functions of language.
        </li>

        <li>
            Discuss the relationship between
            language and society.
        </li>

    </ol>

</section>


`
            },


            /* =================================================
               MODULE 02
            ================================================= */

            "02": {

                number: "02",

                title:
                    "Language Variation and Usage",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "Study of language variation, dialect, register, standard language and context-sensitive language use.",

                learningObjectives: [

                    "Define language variation.",

                    "Distinguish dialect from standard language.",

                    "Explain register.",

                    "Explain the importance of context in language use."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Language Variation</h2>

    <p>

        <strong>Language variation</strong> refers
        to differences in the way a language is
        used by different speakers or in different
        situations.

    </p>

    <p>

        Variation may be influenced by geographical,
        social, occupational and situational factors.

    </p>

</section>



<section class="lesson-section">

    <h2>2. Dialect</h2>

    <p>

        A <strong>dialect</strong> is a variety
        of a language associated with a particular
        geographical or social group.

    </p>

    <p>

        Dialects may differ in pronunciation,
        vocabulary and grammar.

    </p>

</section>



<section class="lesson-section">

    <h2>3. Standard Language</h2>

    <p>

        A <strong>standard language</strong> is
        a variety that has received social,
        educational or institutional recognition
        and is commonly used in formal contexts.

    </p>

</section>



<section class="lesson-section">

    <h2>4. Register</h2>

    <p>

        <strong>Register</strong> refers to the
        variety of language selected according
        to the situation, purpose or social context
        of communication.

    </p>

    <div class="concept-card">

        <h3>Example</h3>

        <p>

            The language used in a formal academic
            essay will normally differ from the
            language used in a casual conversation
            with a close friend.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>5. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Language varies across speakers
                and situations.
            </li>

            <li>
                A dialect is a recognized variety
                associated with a social or
                geographical group.
            </li>

            <li>
                Register depends heavily on
                situation and purpose.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>6. Examination Practice</h2>

    <ol>

        <li>
            Explain language variation.
        </li>

        <li>
            Define dialect.
        </li>

        <li>
            What is register?
        </li>

        <li>
            Explain why language changes
            according to context.
        </li>

    </ol>

</section>


`
            },


            /* =================================================
               MODULE 03
            ================================================= */

            "03": {

                number: "03",

                title:
                    "Meaning, Context and Communication",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "Introduction to meaning, context, ambiguity and the interpretation of linguistic expressions.",

                learningObjectives: [

                    "Explain linguistic meaning.",

                    "Distinguish literal and contextual meaning.",

                    "Explain ambiguity.",

                    "Discuss the role of context in interpretation."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Meaning</h2>

    <p>

        <strong>Meaning</strong> concerns the
        information, concept or interpretation
        associated with a linguistic expression.

    </p>

    <p>

        Understanding meaning requires attention
        not only to words but also to the context
        in which they are used.

    </p>

</section>



<section class="lesson-section">

    <h2>2. Context</h2>

    <p>

        <strong>Context</strong> refers to the
        circumstances surrounding an utterance
        or communicative event.

    </p>

    <p>

        Context may include the speakers,
        location, time, shared knowledge,
        purpose and preceding conversation.

    </p>

</section>



<section class="lesson-section">

    <h2>3. Ambiguity</h2>

    <p>

        An expression is <strong>ambiguous</strong>
        when it can reasonably be interpreted
        in more than one way.

    </p>

    <div class="concept-card">

        <h3>Why Ambiguity Matters</h3>

        <p>

            Ambiguity can create misunderstanding,
            but speakers often use contextual
            information to determine the intended
            interpretation.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>4. Contextual Interpretation</h2>

    <p>

        The same expression can receive different
        interpretations depending on the situation
        in which it occurs.

    </p>

    <p>

        Effective communication therefore requires
        both linguistic knowledge and sensitivity
        to context.

    </p>

</section>



<section class="lesson-section">

    <h2>5. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Meaning concerns the interpretation
                of linguistic expressions.
            </li>

            <li>
                Context contributes significantly
                to interpretation.
            </li>

            <li>
                Ambiguity occurs when an expression
                has more than one possible
                interpretation.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>6. Examination Practice</h2>

    <ol>

        <li>
            Explain the concept of meaning.
        </li>

        <li>
            What is context?
        </li>

        <li>
            Explain ambiguity with examples.
        </li>

        <li>
            Discuss the role of context
            in communication.
        </li>

    </ol>

</section>


`
            },


            /* =================================================
               MODULE 04
            ================================================= */

            "04": {

                number: "04",

                title:
                    "English Usage and Academic Communication",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "Application of English language knowledge to formal, academic and professional communication.",

                learningObjectives: [

                    "Explain effective language use.",

                    "Identify features of formal academic communication.",

                    "Distinguish formal and informal usage.",

                    "Apply principles of clear academic communication."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Effective Language Use</h2>

    <p>

        Effective communication requires the
        speaker or writer to select language
        appropriate to the audience, purpose
        and context.

    </p>

    <p>

        Good academic communication should be
        <strong>clear, organized, precise and
        logically developed</strong>.

    </p>

</section>



<section class="lesson-section">

    <h2>2. Formal Academic Communication</h2>

    <p>

        Formal academic communication normally
        uses carefully structured sentences,
        appropriate vocabulary and logically
        connected ideas.

    </p>

    <ul>

        <li>
            Avoid unnecessary informality.
        </li>

        <li>
            Use precise vocabulary.
        </li>

        <li>
            Organize ideas logically.
        </li>

        <li>
            Support important claims appropriately.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>3. Formal and Informal Language</h2>

    <div class="concept-card">

        <h3>Formal</h3>

        <p>

            Appropriate for academic writing,
            official communication and many
            professional contexts.

        </p>

    </div>


    <div class="concept-card">

        <h3>Informal</h3>

        <p>

            Common in casual conversation,
            personal messages and relaxed
            social interaction.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>4. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Effective language depends on
                audience, purpose and context.
            </li>

            <li>
                Academic communication should
                be clear and logically organized.
            </li>

            <li>
                Formal and informal language
                serve different communicative
                situations.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>5. Examination Practice</h2>

    <ol>

        <li>
            Explain effective language use.
        </li>

        <li>
            Discuss four features of academic
            communication.
        </li>

        <li>
            Distinguish formal from informal
            language.
        </li>

        <li>
            Explain the importance of audience
            and context in communication.
        </li>

    </ol>

</section>


`
            }

        }

    },



    /* =====================================================
       EDU 211
       DEVELOPMENTAL PSYCHOLOGY
       PREMIUM COURSE
    ===================================================== */

    EDU211: {

        code:
            "EDU 211",

        title:
            "Developmental Psychology",

        department:
            "Education",

        units: 2,

        access:
            "premium",

        productCode:
            "200L_FIRST_SEMESTER_PREMIUM",

        description:
            "A study of human development across physical, cognitive, emotional and social dimensions, with applications to teaching and learning.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {


            /* =================================================
               MODULE 01
            ================================================= */

            "01": {

                number: "01",

                title:
                    "Introduction to Human Development",

                access:
                    "premium",

                preview:
                    true,

                description:
                    "Introduction to developmental psychology, principles of development and major dimensions of human growth.",

                learningObjectives: [

                    "Define developmental psychology.",

                    "Distinguish growth from development.",

                    "Explain major principles of development.",

                    "Identify major domains of human development."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Meaning of Developmental Psychology</h2>

    <p>

        <strong>Developmental psychology</strong>
        is the systematic study of changes and
        continuities in human behaviour and
        psychological functioning across the
        lifespan.

    </p>

    <p>

        It examines how people develop physically,
        cognitively, emotionally and socially.

    </p>

    <div class="callout">

        <strong>EDUCATION CONNECTION</strong>

        <p>

            Understanding development helps teachers
            recognize that learners differ in their
            abilities, needs and developmental levels.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>2. Growth and Development</h2>

    <h3>Growth</h3>

    <p>

        Growth commonly refers to measurable
        quantitative changes, especially physical
        changes.

    </p>

    <h3>Development</h3>

    <p>

        Development refers more broadly to
        progressive changes in abilities,
        behaviour and functioning.

    </p>

</section>



<section class="lesson-section">

    <h2>3. Major Domains of Development</h2>

    <div class="concept-card">

        <h3>Physical Development</h3>

        <p>

            Changes in body structure,
            motor abilities and physical functioning.

        </p>

    </div>


    <div class="concept-card">

        <h3>Cognitive Development</h3>

        <p>

            Changes in thinking, reasoning,
            memory, problem-solving and language.

        </p>

    </div>


    <div class="concept-card">

        <h3>Social Development</h3>

        <p>

            Changes in relationships,
            social behaviour and interaction.

        </p>

    </div>


    <div class="concept-card">

        <h3>Emotional Development</h3>

        <p>

            Changes in emotional understanding,
            expression and regulation.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>4. Principles of Development</h2>

    <ul>

        <li>
            Development is generally continuous.
        </li>

        <li>
            Development involves multiple dimensions.
        </li>

        <li>
            Individuals develop at different rates.
        </li>

        <li>
            Development is influenced by both
            biological and environmental factors.
        </li>

        <li>
            Earlier development can influence
            later development.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>5. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Developmental psychology studies
                changes and continuities across
                the lifespan.
            </li>

            <li>
                Growth usually emphasizes
                quantitative change.
            </li>

            <li>
                Development is broader and includes
                physical, cognitive, social and
                emotional dimensions.
            </li>

            <li>
                Learners develop at different rates.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>6. Examination Practice</h2>

    <ol>

        <li>
            Define developmental psychology.
        </li>

        <li>
            Distinguish growth from development.
        </li>

        <li>
            Discuss four major domains
            of human development.
        </li>

        <li>
            Explain five principles of development.
        </li>

    </ol>

</section>


`
            },


            /* =================================================
               MODULE 02
            ================================================= */

            "02": {

                number: "02",

                title:
                    "Cognitive Development",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "Study of changes in thinking, reasoning, memory, language and problem-solving abilities.",

                learningObjectives: [

                    "Explain cognitive development.",

                    "Discuss factors influencing cognition.",

                    "Explain the importance of language and memory.",

                    "Relate cognitive development to classroom learning."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Meaning of Cognitive Development</h2>

    <p>

        <strong>Cognitive development</strong>
        refers to changes in mental processes
        involved in thinking, learning, memory,
        reasoning and problem-solving.

    </p>

</section>



<section class="lesson-section">

    <h2>2. Major Cognitive Processes</h2>

    <ul>

        <li>
            <strong>Attention</strong> —
            focusing mental resources.
        </li>

        <li>
            <strong>Memory</strong> —
            encoding, storing and retrieving
            information.
        </li>

        <li>
            <strong>Reasoning</strong> —
            drawing conclusions from information.
        </li>

        <li>
            <strong>Problem-solving</strong> —
            developing solutions to problems.
        </li>

        <li>
            <strong>Language</strong> —
            understanding and producing
            linguistic information.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>3. Cognitive Development and Learning</h2>

    <p>

        Learners do not process information
        identically.

        Their prior knowledge, developmental
        level, attention, memory and learning
        environment can influence academic
        performance.

    </p>

    <div class="callout">

        <strong>TEACHING APPLICATION</strong>

        <p>

            Effective teaching should consider
            the learner's existing knowledge
            and cognitive readiness.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>4. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Cognitive development concerns
                changes in mental processes.
            </li>

            <li>
                Memory, attention, reasoning,
                language and problem-solving
                are important cognitive processes.
            </li>

            <li>
                Cognitive differences can affect
                classroom learning.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>5. Examination Practice</h2>

    <ol>

        <li>
            Define cognitive development.
        </li>

        <li>
            Explain five cognitive processes.
        </li>

        <li>
            Discuss the relationship between
            cognitive development and learning.
        </li>

    </ol>

</section>


`
            },


            /* =================================================
               MODULE 03
            ================================================= */

            "03": {

                number: "03",

                title:
                    "Social and Emotional Development",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "Study of emotional growth, social relationships, self-concept and interpersonal development.",

                learningObjectives: [

                    "Explain social development.",

                    "Explain emotional development.",

                    "Discuss the role of relationships.",

                    "Relate social-emotional development to education."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Social Development</h2>

    <p>

        <strong>Social development</strong> refers
        to changes in the way individuals interact
        with others and participate in social
        relationships.

    </p>

</section>



<section class="lesson-section">

    <h2>2. Emotional Development</h2>

    <p>

        <strong>Emotional development</strong>
        involves changes in the ability to
        understand, express and regulate emotions.

    </p>

    <p>

        Emotional development is important
        because emotions can influence
        attention, motivation, relationships
        and learning.

    </p>

</section>



<section class="lesson-section">

    <h2>3. Self-Concept</h2>

    <p>

        <strong>Self-concept</strong> refers to
        an individual's understanding and
        perception of themselves.

    </p>

    <p>

        A learner's perception of their academic
        ability can influence motivation,
        participation and persistence.

    </p>

</section>



<section class="lesson-section">

    <h2>4. Importance to Teaching</h2>

    <ul>

        <li>
            Teachers should create supportive
            classroom relationships.
        </li>

        <li>
            Learners should be treated with
            dignity and respect.
        </li>

        <li>
            Emotional difficulties can influence
            classroom participation.
        </li>

        <li>
            Positive social interaction can
            support learning.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>5. Quick Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Social development concerns
                relationships and interaction.
            </li>

            <li>
                Emotional development concerns
                understanding and regulating emotions.
            </li>

            <li>
                Self-concept can influence
                academic motivation.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>6. Examination Practice</h2>

    <ol>

        <li>
            Define social development.
        </li>

        <li>
            Explain emotional development.
        </li>

        <li>
            What is self-concept?
        </li>

        <li>
            Discuss the educational importance
            of social and emotional development.
        </li>

    </ol>

</section>


`
            },


            /* =================================================
               MODULE 04
            ================================================= */

            "04": {

                number: "04",

                title:
                    "Development and Classroom Practice",

                access:
                    "premium",

                preview:
                    false,

                description:
                    "Application of developmental psychology to teaching, classroom management and learner support.",

                learningObjectives: [

                    "Explain why developmental knowledge matters to teachers.",

                    "Relate learner differences to classroom practice.",

                    "Explain developmentally appropriate teaching.",

                    "Apply developmental principles to education."

                ],

                content: `


<section class="lesson-section">

    <h2>1. Development and Teaching</h2>

    <p>

        Teachers work with learners who differ
        in age, experience, cognitive ability,
        emotional development, social background
        and learning needs.

    </p>

    <p>

        Knowledge of development enables teachers
        to design learning experiences that are
        more appropriate to their students.

    </p>

</section>



<section class="lesson-section">

    <h2>2. Individual Differences</h2>

    <p>

        Learners do not develop at exactly the
        same rate.

        Individual differences may occur in
        cognition, language, emotional regulation,
        social behaviour and academic performance.

    </p>

    <div class="callout">

        <strong>TEACHER'S RESPONSIBILITY</strong>

        <p>

            Effective teaching should recognize
            learner differences without lowering
            appropriate academic expectations.

        </p>

    </div>

</section>



<section class="lesson-section">

    <h2>3. Developmentally Appropriate Teaching</h2>

    <p>

        Teaching should consider what learners
        are developmentally prepared to understand
        while still providing opportunities for
        intellectual growth.

    </p>

    <ul>

        <li>
            Use clear explanations.
        </li>

        <li>
            Connect new knowledge with prior knowledge.
        </li>

        <li>
            Provide suitable learning activities.
        </li>

        <li>
            Encourage active participation.
        </li>

        <li>
            Monitor learner progress.
        </li>

    </ul>

</section>



<section class="lesson-section">

    <h2>4. Final EDU 211 Revision</h2>

    <div class="revision-box">

        <ul>

            <li>
                Developmental psychology studies
                human development across the lifespan.
            </li>

            <li>
                Development includes physical,
                cognitive, social and emotional
                dimensions.
            </li>

            <li>
                Cognitive development affects
                learning and problem-solving.
            </li>

            <li>
                Social and emotional development
                influences classroom behaviour.
            </li>

            <li>
                Teachers should consider
                developmental differences
                when planning instruction.
            </li>

        </ul>

    </div>

</section>



<section class="lesson-section section-exam">

    <h2>5. Examination Practice</h2>

    <ol>

        <li>
            Explain the importance of developmental
            psychology to teachers.
        </li>

        <li>
            Discuss individual differences
            among learners.
        </li>

        <li>
            Explain developmentally appropriate
            teaching.
        </li>

        <li>
            Discuss four ways developmental
            psychology can improve classroom practice.
        </li>

    </ol>

</section>


`
            }

        }

    },


    /* =====================================================
       NEXT PART:
       EDU 201
       UNIBENEDU212
       GST 211
       ENG 205
       LAS 244
    ===================================================== */

        /* =====================================================
       EDU 201
       CURRICULUM, CURRICULUM DELIVERY AND
       GENERAL TEACHING METHODS
    ===================================================== */

    EDU201: {

        code:
            "EDU 201",

        title:
            "Curriculum, Curriculum Delivery and General Teaching Methods",

        department:
            "Education",

        units: 2,

        access:
            "free",

        description:
            "A study of curriculum concepts, curriculum development, curriculum delivery and general teaching methods used in educational practice.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {

            "01": {

                title:
                    "Meaning, Nature and Scope of Curriculum",

                subtitle:
                    "Understanding curriculum and its place in education",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Meaning of Curriculum",

                        content: `
                            <p>
                                Curriculum refers to the totality of planned learning
                                experiences provided by an educational institution to
                                achieve specified educational objectives.
                            </p>

                            <p>
                                It is broader than a mere list of subjects. Curriculum
                                includes what learners are expected to learn, the
                                learning experiences provided, the methods used,
                                instructional materials and the ways learning outcomes
                                are assessed.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Major Elements of Curriculum",

                        content: `
                            <div class="concept-card">
                                <h4>Objectives</h4>
                                <p>
                                    The knowledge, skills, attitudes and values learners
                                    are expected to acquire.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Content</h4>
                                <p>
                                    The subject matter, concepts, principles and skills
                                    selected for learning.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Learning Experiences</h4>
                                <p>
                                    The activities through which learners interact with
                                    the content and develop the intended competencies.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Evaluation</h4>
                                <p>
                                    The processes used to determine whether curriculum
                                    objectives have been achieved.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Characteristics of Curriculum",

                        content: `
                            <ul>
                                <li>Curriculum is purposeful.</li>
                                <li>It is planned and organized.</li>
                                <li>It is learner-oriented.</li>
                                <li>It responds to societal needs.</li>
                                <li>It includes both academic and practical learning.</li>
                                <li>It is subject to evaluation and revision.</li>
                                <li>It may include formal and informal learning experiences.</li>
                            </ul>
                        `
                    },

                    {
                        type: "callout",

                        heading:
                            "Exam Focus",

                        content: `
                            <p>
                                Do not define curriculum simply as a "list of subjects".
                                In an examination, emphasize <strong>planned learning
                                experiences</strong>, <strong>objectives</strong>,
                                <strong>content</strong>, <strong>instruction</strong>
                                and <strong>evaluation</strong>.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Define curriculum.</li>
                                <li>Explain five characteristics of curriculum.</li>
                                <li>Identify and explain the major elements of curriculum.</li>
                                <li>Distinguish between curriculum and syllabus.</li>
                            </ol>
                        `
                    }

                ]
            },


            "02": {

                title:
                    "Curriculum Development and Design",

                subtitle:
                    "How curriculum is planned, organized and improved",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Curriculum Development",

                        content: `
                            <p>
                                Curriculum development is the systematic process of
                                planning, designing, implementing, evaluating and
                                improving a curriculum.
                            </p>

                            <p>
                                It involves identifying educational needs and deciding
                                what learners should know, what experiences they should
                                receive and how achievement should be assessed.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Major Stages of Curriculum Development",

                        content: `
                            <div class="concept-card">
                                <h4>1. Identification of Needs</h4>
                                <p>
                                    Determine the educational and societal needs that
                                    the curriculum should address.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>2. Formulation of Objectives</h4>
                                <p>
                                    Establish clear educational goals and learning
                                    outcomes.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>3. Selection of Content</h4>
                                <p>
                                    Choose relevant knowledge, concepts, skills and
                                    values.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>4. Organization of Content</h4>
                                <p>
                                    Arrange selected content logically and progressively.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>5. Selection of Learning Experiences</h4>
                                <p>
                                    Decide how learners will interact with the content.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>6. Evaluation</h4>
                                <p>
                                    Determine whether the curriculum has achieved its
                                    intended objectives.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Principles of Curriculum Organization",

                        content: `
                            <ul>
                                <li><strong>Continuity:</strong> important learning experiences recur over time.</li>
                                <li><strong>Sequence:</strong> learning progresses from simpler to more complex ideas.</li>
                                <li><strong>Integration:</strong> related areas of knowledge are connected.</li>
                                <li><strong>Balance:</strong> appropriate attention is given to different areas of learning.</li>
                                <li><strong>Relevance:</strong> content should respond to learner and societal needs.</li>
                            </ul>
                        `
                    },

                    {
                        type: "callout",

                        heading:
                            "Remember",

                        content: `
                            <p>
                                Curriculum development is <strong>cyclical</strong>.
                                Evaluation can reveal weaknesses that require the
                                curriculum to be revised or redesigned.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Explain the major stages of curriculum development.</li>
                                <li>Discuss five principles of curriculum organization.</li>
                                <li>Why is curriculum evaluation important?</li>
                                <li>Explain the relationship between curriculum objectives and content.</li>
                            </ol>
                        `
                    }

                ]
            },


            "03": {

                title:
                    "Curriculum Delivery and Teaching Methods",

                subtitle:
                    "Translating curriculum into classroom learning",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Meaning of Curriculum Delivery",

                        content: `
                            <p>
                                Curriculum delivery refers to the process of putting
                                curriculum plans into practice through teaching,
                                learning activities, instructional materials and
                                assessment.
                            </p>

                            <p>
                                The teacher plays a central role in translating
                                curriculum objectives and content into meaningful
                                classroom experiences.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Factors Affecting Curriculum Delivery",

                        content: `
                            <div class="concept-card">
                                <h4>Teacher Competence</h4>
                                <p>
                                    Teachers need appropriate subject knowledge,
                                    pedagogical skills and classroom-management
                                    abilities.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Learner Characteristics</h4>
                                <p>
                                    Age, ability, prior knowledge, motivation and
                                    individual differences influence instruction.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Instructional Materials</h4>
                                <p>
                                    Textbooks, charts, digital resources, models and
                                    other materials support effective teaching.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Learning Environment</h4>
                                <p>
                                    Classroom facilities, class size, time and school
                                    resources affect curriculum implementation.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Major Teaching Methods",

                        content: `
                            <ul>
                                <li>
                                    <strong>Lecture Method:</strong>
                                    the teacher presents information directly to learners.
                                </li>

                                <li>
                                    <strong>Discussion Method:</strong>
                                    learners and teacher exchange ideas around a topic.
                                </li>

                                <li>
                                    <strong>Demonstration Method:</strong>
                                    the teacher or learner shows how a process,
                                    procedure or skill is performed.
                                </li>

                                <li>
                                    <strong>Project Method:</strong>
                                    learners investigate a problem or complete a
                                    practical task over a period of time.
                                </li>

                                <li>
                                    <strong>Question-and-Answer Method:</strong>
                                    carefully designed questions are used to stimulate
                                    thinking and assess understanding.
                                </li>
                            </ul>
                        `
                    },

                    {
                        type: "callout",

                        heading:
                            "Teaching Principle",

                        content: `
                            <p>
                                There is no single teaching method that is best for
                                every situation. The appropriate method depends on the
                                <strong>objective, content, learners, available
                                resources and learning environment</strong>.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Define curriculum delivery.</li>
                                <li>Discuss five factors affecting curriculum delivery.</li>
                                <li>Explain five teaching methods.</li>
                                <li>State the advantages and limitations of the lecture method.</li>
                            </ol>
                        `
                    }

                ]
            },


            "04": {

                title:
                    "Lesson Planning, Classroom Management and Evaluation",

                subtitle:
                    "Practical principles for effective teaching",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Lesson Planning",

                        content: `
                            <p>
                                A lesson plan is a structured outline of what a teacher
                                intends to teach and how the teaching and learning
                                activities will be carried out within a particular
                                period.
                            </p>

                            <p>
                                Effective lesson planning connects objectives, content,
                                teaching methods, learning activities, instructional
                                materials and evaluation.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Important Components of a Lesson Plan",

                        content: `
                            <div class="concept-card">
                                <h4>Objectives</h4>
                                <p>
                                    Statements describing what learners should achieve
                                    by the end of the lesson.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Content</h4>
                                <p>
                                    The specific knowledge, skills or values to be taught.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Teaching Activities</h4>
                                <p>
                                    The actions performed by the teacher and learners
                                    during instruction.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Resources</h4>
                                <p>
                                    Materials and facilities required to support learning.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Evaluation</h4>
                                <p>
                                    Activities used to determine whether learners have
                                    achieved the stated objectives.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Classroom Management",

                        content: `
                            <p>
                                Classroom management involves the strategies teachers
                                use to create and maintain an orderly, supportive and
                                productive learning environment.
                            </p>

                            <ul>
                                <li>Establishing clear classroom rules.</li>
                                <li>Managing instructional time effectively.</li>
                                <li>Maintaining learner attention.</li>
                                <li>Encouraging positive behaviour.</li>
                                <li>Managing classroom resources.</li>
                                <li>Responding appropriately to learner differences.</li>
                            </ul>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Educational Evaluation",

                        content: `
                            <p>
                                Evaluation is the systematic process of collecting and
                                interpreting information to determine the extent to which
                                educational objectives have been achieved.
                            </p>

                            <p>
                                Evaluation may occur before, during or after instruction.
                                Diagnostic evaluation identifies learning needs,
                                formative evaluation provides feedback during learning,
                                while summative evaluation determines achievement after
                                a period of instruction.
                            </p>
                        `
                    },

                    {
                        type: "revision-box",

                        heading:
                            "EDU 201 Final Revision Points",

                        content: `
                            <ul>
                                <li>Curriculum is broader than a syllabus.</li>
                                <li>Objectives guide content selection and instruction.</li>
                                <li>Curriculum development involves planning, implementation and evaluation.</li>
                                <li>Teaching methods should match instructional objectives.</li>
                                <li>Lesson planning improves organization and instructional effectiveness.</li>
                                <li>Classroom management creates conditions for effective learning.</li>
                                <li>Evaluation determines the extent to which objectives have been achieved.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Hard Mock Questions",

                        content: `
                            <ol>
                                <li>
                                    Critically examine the relationship between curriculum
                                    objectives, content, teaching methods and evaluation.
                                </li>

                                <li>
                                    Discuss the factors that may hinder effective
                                    curriculum implementation in Nigerian schools.
                                </li>

                                <li>
                                    Compare formative and summative evaluation and state
                                    their educational uses.
                                </li>

                                <li>
                                    Explain how effective lesson planning can improve
                                    classroom instruction.
                                </li>

                                <li>
                                    "The success of a curriculum depends largely on its
                                    implementation." Discuss.
                                </li>
                            </ol>
                        `
                    }

                ]
            }

        }

    },


    /* =====================================================
       UNIBENEDU 212
       PHILOSOPHY OF EDUCATION
    ===================================================== */

    UNIBENEDU212: {

        code:
            "UNIBENEDU 212",

        title:
            "Philosophy of Education",

        department:
            "Education",

        units: 2,

        access:
            "free",

        description:
            "An examination of philosophical ideas about education, knowledge, values, aims, teaching, learning and society.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {

            "01": {

                title:
                    "Meaning, Nature and Scope of Philosophy of Education",

                subtitle:
                    "Understanding philosophical inquiry in education",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Meaning of Philosophy",

                        content: `
                            <p>
                                Philosophy is the systematic and critical examination
                                of fundamental questions concerning reality, knowledge,
                                values, reason and human existence.
                            </p>

                            <p>
                                Philosophy of education applies philosophical reasoning
                                to educational questions. It examines what education
                                means, why education is necessary, what should be taught,
                                how people should learn and what educational institutions
                                should achieve.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Major Branches of Philosophy",

                        content: `
                            <div class="concept-card">
                                <h4>Metaphysics</h4>
                                <p>
                                    The study of reality, existence, being and the nature
                                    of things.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Epistemology</h4>
                                <p>
                                    The study of knowledge, its sources, limits and
                                    justification.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Axiology</h4>
                                <p>
                                    The study of values, including ethics and aesthetics.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Logic</h4>
                                <p>
                                    The study of correct reasoning and principles of
                                    valid argumentation.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Functions of Philosophy of Education",

                        content: `
                            <ul>
                                <li>Clarifies educational concepts.</li>
                                <li>Examines educational aims and values.</li>
                                <li>Encourages critical thinking.</li>
                                <li>Provides a basis for evaluating educational practices.</li>
                                <li>Examines assumptions underlying educational policies.</li>
                                <li>Helps teachers understand the purposes of education.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Define philosophy of education.</li>
                                <li>Explain four major branches of philosophy.</li>
                                <li>Discuss five functions of philosophy of education.</li>
                            </ol>
                        `
                    }

                ]
            },


            "02": {

                title:
                    "Knowledge, Values and Aims of Education",

                subtitle:
                    "What should education teach and why?",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Knowledge and Education",

                        content: `
                            <p>
                                Knowledge is central to education because education
                                involves helping learners acquire, understand, evaluate
                                and apply knowledge.
                            </p>

                            <p>
                                Philosophical discussions of knowledge consider questions
                                about its sources, certainty, justification and limits.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Common Sources of Knowledge",

                        content: `
                            <div class="concept-card">
                                <h4>Reason</h4>
                                <p>
                                    Knowledge obtained through logical thinking and
                                    intellectual reflection.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Experience</h4>
                                <p>
                                    Knowledge gained through observation and interaction
                                    with the world.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Authority</h4>
                                <p>
                                    Knowledge accepted from reliable experts, teachers,
                                    institutions or recognized sources.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Intuition</h4>
                                <p>
                                    Immediate understanding or awareness that does not
                                    necessarily arise from explicit reasoning.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Values in Education",

                        content: `
                            <p>
                                Values are principles or standards used to judge what is
                                desirable, worthwhile, right or important.
                            </p>

                            <p>
                                Education transmits and develops intellectual, moral,
                                social and civic values. Schools therefore contribute
                                not only to academic development but also to character
                                formation.
                            </p>
                        `
                    },

                    {
                        type: "callout",

                        heading:
                            "Exam Connection",

                        content: `
                            <p>
                                When discussing the aims of education, avoid limiting
                                your answer to academic knowledge. Strong answers connect
                                education with <strong>intellectual, moral, social,
                                vocational and civic development</strong>.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Discuss the relationship between knowledge and education.</li>
                                <li>Explain four sources of knowledge.</li>
                                <li>What role do values play in education?</li>
                                <li>Discuss the major aims of education.</li>
                            </ol>
                        `
                    }

                ]
            },


            "03": {

                title:
                    "Major Philosophies and Educational Implications",

                subtitle:
                    "How philosophical positions influence education",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Idealism",

                        content: `
                            <p>
                                Idealism emphasizes the importance of ideas, mind,
                                reason and spiritual or intellectual reality.
                            </p>

                            <p>
                                In education, idealism tends to emphasize intellectual
                                development, moral formation, disciplined thinking and
                                the pursuit of enduring values.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Realism",

                        content: `
                            <p>
                                Realism holds that reality exists independently of
                                individual thought and emphasizes the importance of
                                objective knowledge and the external world.
                            </p>

                            <p>
                                Realist education places importance on observation,
                                scientific knowledge, facts and systematic study of the
                                natural and social environment.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Pragmatism",

                        content: `
                            <p>
                                Pragmatism emphasizes experience, action, problem-solving
                                and the practical consequences of ideas.
                            </p>

                            <p>
                                Pragmatist education supports learning by doing,
                                experimentation, cooperation and problem-solving.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Existentialism",

                        content: `
                            <p>
                                Existentialism emphasizes individual freedom, choice,
                                responsibility and personal meaning.
                            </p>

                            <p>
                                In education, it gives attention to individuality,
                                personal choice, self-understanding and responsible
                                decision-making.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Comparative Practice",

                        content: `
                            <ol>
                                <li>Compare idealism and realism as philosophies of education.</li>
                                <li>Explain the educational implications of pragmatism.</li>
                                <li>Discuss existentialism and its implications for teaching.</li>
                                <li>Which philosophical position places strong emphasis on learning through experience? Explain.</li>
                            </ol>
                        `
                    }

                ]
            },


            "04": {

                title:
                    "Teacher, Learner, Society and Education",

                subtitle:
                    "The social and professional dimensions of education",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "The Teacher",

                        content: `
                            <p>
                                The teacher is not merely a transmitter of information.
                                A professional teacher facilitates learning, guides
                                learners, models appropriate behaviour and evaluates
                                learning outcomes.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "The Learner",

                        content: `
                            <p>
                                The learner is an active participant in the educational
                                process. Effective education considers learners'
                                differences in ability, experience, interests,
                                development and learning needs.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Education and Society",

                        content: `
                            <p>
                                Education and society influence one another. Society
                                determines many of the values, knowledge and skills
                                transmitted through education, while education can
                                transform society by developing knowledgeable,
                                skilled and responsible citizens.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Major Social Functions of Education",

                        content: `
                            <div class="concept-card">
                                <h4>Socialization</h4>
                                <p>
                                    Preparing individuals to participate effectively in society.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Cultural Transmission</h4>
                                <p>
                                    Passing important knowledge, values and traditions
                                    from one generation to another.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Social Integration</h4>
                                <p>
                                    Promoting shared values, cooperation and social cohesion.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Social Transformation</h4>
                                <p>
                                    Providing knowledge and skills that can contribute to
                                    social and economic development.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "revision-box",

                        heading:
                            "Final Revision",

                        content: `
                            <ul>
                                <li>Philosophy encourages critical examination of educational ideas.</li>
                                <li>Metaphysics concerns reality and existence.</li>
                                <li>Epistemology concerns knowledge.</li>
                                <li>Axiology concerns values.</li>
                                <li>Logic concerns valid reasoning.</li>
                                <li>Educational philosophies influence aims, curriculum and teaching methods.</li>
                                <li>Education is both an individual and social process.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Hard Mock Questions",

                        content: `
                            <ol>
                                <li>
                                    "Education is never philosophically neutral."
                                    Discuss this statement.
                                </li>

                                <li>
                                    Examine the relationship between the teacher,
                                    learner and society in the educational process.
                                </li>

                                <li>
                                    Compare the educational implications of idealism,
                                    realism and pragmatism.
                                </li>

                                <li>
                                    Explain how education can contribute to social
                                    transformation.
                                </li>
                            </ol>
                        `
                    }

                ]
            }

        }

    },


    /* =====================================================
       GST 211
       ENTREPRENEURSHIP AND INNOVATION
    ===================================================== */

    GST211: {

        code:
            "GST 211",

        title:
            "Entrepreneurship and Innovation",

        department:
            "General Studies",

        units: 2,

        access:
            "free",

        description:
            "An introduction to entrepreneurship, innovation, opportunity recognition, business creation and entrepreneurial development.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {

            "01": {

                title:
                    "Meaning and Nature of Entrepreneurship",

                subtitle:
                    "Understanding entrepreneurs and entrepreneurial activity",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Meaning of Entrepreneurship",

                        content: `
                            <p>
                                Entrepreneurship is the process of identifying
                                opportunities, mobilizing resources and creating value
                                through the development of products, services or
                                ventures.
                            </p>

                            <p>
                                Entrepreneurship involves initiative, creativity,
                                decision-making, problem-solving and willingness to
                                manage uncertainty.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Characteristics of an Entrepreneur",

                        content: `
                            <div class="concept-card">
                                <h4>Initiative</h4>
                                <p>
                                    The ability to act without waiting for others to
                                    provide direction.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Creativity</h4>
                                <p>
                                    The ability to generate useful new ideas.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Calculated Risk-Taking</h4>
                                <p>
                                    Willingness to accept uncertainty after considering
                                    possible outcomes.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Persistence</h4>
                                <p>
                                    Continuing to pursue worthwhile goals despite
                                    obstacles and setbacks.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Problem-Solving</h4>
                                <p>
                                    Identifying problems and developing practical solutions.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Importance of Entrepreneurship",

                        content: `
                            <ul>
                                <li>Creates employment opportunities.</li>
                                <li>Encourages innovation.</li>
                                <li>Generates income and wealth.</li>
                                <li>Promotes economic development.</li>
                                <li>Encourages self-reliance.</li>
                                <li>Provides solutions to social and economic problems.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Define entrepreneurship.</li>
                                <li>Explain five characteristics of an entrepreneur.</li>
                                <li>Discuss the importance of entrepreneurship to economic development.</li>
                            </ol>
                        `
                    }

                ]
            },


            "02": {

                title:
                    "Innovation, Creativity and Opportunity Recognition",

                subtitle:
                    "Turning problems into opportunities",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Creativity and Innovation",

                        content: `
                            <p>
                                <strong>Creativity</strong> is the ability to generate
                                original and useful ideas.
                            </p>

                            <p>
                                <strong>Innovation</strong> involves applying ideas in
                                ways that create value. An idea becomes an innovation
                                when it is developed and implemented successfully.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Sources of Business Opportunities",

                        content: `
                            <ul>
                                <li>Unmet customer needs.</li>
                                <li>Existing problems and inefficiencies.</li>
                                <li>Technological developments.</li>
                                <li>Changes in consumer behaviour.</li>
                                <li>Changes in government policy.</li>
                                <li>Social and demographic changes.</li>
                                <li>Gaps in existing markets.</li>
                            </ul>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Opportunity Recognition",

                        content: `
                            <p>
                                Opportunity recognition is the process of identifying
                                situations in which a product, service or business
                                solution can create value.
                            </p>

                            <p>
                                Entrepreneurs should evaluate opportunities by examining
                                customer needs, market demand, available resources,
                                competition, costs and potential value.
                            </p>
                        `
                    },

                    {
                        type: "callout",

                        heading:
                            "Key Distinction",

                        content: `
                            <p>
                                <strong>Creativity generates possibilities;</strong>
                                <strong>innovation implements useful possibilities.</strong>
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Distinguish between creativity and innovation.</li>
                                <li>Identify five sources of entrepreneurial opportunities.</li>
                                <li>Explain the process of opportunity recognition.</li>
                            </ol>
                        `
                    }

                ]
            },


            "03": {

                title:
                    "Business Planning and Enterprise Development",

                subtitle:
                    "Moving from an idea to an organized venture",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Business Plan",

                        content: `
                            <p>
                                A business plan is a structured document that describes
                                a proposed business, its objectives, target market,
                                products or services, marketing strategy, operations
                                and financial expectations.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Major Components of a Business Plan",

                        content: `
                            <div class="concept-card">
                                <h4>Executive Summary</h4>
                                <p>
                                    A concise overview of the proposed business and its
                                    major objectives.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Market Analysis</h4>
                                <p>
                                    Examination of customers, competitors and market conditions.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Marketing Plan</h4>
                                <p>
                                    Plans for product positioning, pricing, promotion
                                    and distribution.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Operations Plan</h4>
                                <p>
                                    Explanation of how the business will produce and
                                    deliver its products or services.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Financial Plan</h4>
                                <p>
                                    Estimates of costs, revenue, cash flow and profitability.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Sources of Business Finance",

                        content: `
                            <ul>
                                <li>Personal savings.</li>
                                <li>Family and friends.</li>
                                <li>Bank financing.</li>
                                <li>Cooperative societies.</li>
                                <li>Government support programmes.</li>
                                <li>Angel investors and other private investors.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>What is a business plan?</li>
                                <li>Explain five components of a business plan.</li>
                                <li>Discuss five sources of entrepreneurial finance.</li>
                            </ol>
                        `
                    }

                ]
            },


            "04": {

                title:
                    "Entrepreneurial Skills, Ethics and Sustainability",

                subtitle:
                    "Building responsible and sustainable enterprises",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Important Entrepreneurial Skills",

                        content: `
                            <ul>
                                <li>Communication.</li>
                                <li>Leadership.</li>
                                <li>Negotiation.</li>
                                <li>Financial management.</li>
                                <li>Marketing.</li>
                                <li>Time management.</li>
                                <li>Decision-making.</li>
                                <li>Networking.</li>
                                <li>Problem-solving.</li>
                            </ul>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Business Ethics",

                        content: `
                            <p>
                                Business ethics refers to moral principles that guide
                                behaviour in business activities.
                            </p>

                            <p>
                                Ethical entrepreneurship requires honesty, transparency,
                                fairness, respect for customers and employees, responsible
                                use of resources and compliance with applicable laws.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Entrepreneurship and Sustainable Development",

                        content: `
                            <p>
                                Sustainable entrepreneurship seeks to create economic
                                value while considering social and environmental
                                consequences.
                            </p>

                            <p>
                                Entrepreneurs can contribute to sustainability through
                                efficient resource use, responsible production,
                                employment creation and solutions to social problems.
                            </p>
                        `
                    },

                    {
                        type: "revision-box",

                        heading:
                            "GST 211 Final Revision",

                        content: `
                            <ul>
                                <li>Entrepreneurship involves opportunity recognition and value creation.</li>
                                <li>Creativity generates ideas while innovation implements useful ideas.</li>
                                <li>A business plan provides direction for a proposed venture.</li>
                                <li>Entrepreneurs require both technical and interpersonal skills.</li>
                                <li>Ethical conduct supports trust and long-term business sustainability.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Hard Mock Questions",

                        content: `
                            <ol>
                                <li>
                                    Explain how entrepreneurship can contribute to
                                    employment generation and economic development.
                                </li>

                                <li>
                                    Distinguish clearly between creativity, invention
                                    and innovation.
                                </li>

                                <li>
                                    Discuss the major components of a business plan and
                                    explain why each is important.
                                </li>

                                <li>
                                    Examine the importance of ethics to entrepreneurial
                                    success.
                                </li>

                                <li>
                                    Discuss how an entrepreneur can identify and evaluate
                                    a viable business opportunity.
                                </li>
                            </ol>
                        `
                    }

                ]
            }

        }

    },

        /* =====================================================
       ENG 205
       INTRODUCTION TO ENGLISH LANGUAGE
    ===================================================== */

    ENG205: {

        code:
            "ENG 205",

        title:
            "Introduction to English Language",

        department:
            "English and Literature",

        units: 2,

        access:
            "free",

        description:
            "An introduction to the nature, structure, functions and varieties of the English language.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {

            "01": {

                title:
                    "Language: Meaning, Nature and Functions",

                subtitle:
                    "Understanding language as a system of human communication",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Meaning of Language",

                        content: `
                            <p>
                                Language is a systematic and conventional means of
                                communication through which human beings express ideas,
                                feelings, intentions and experiences.
                            </p>

                            <p>
                                Human language is characterized by its systematic
                                organization, social nature, creativity and ability to
                                communicate ideas that are not immediately present.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Characteristics of Human Language",

                        content: `
                            <div class="concept-card">
                                <h4>Arbitrariness</h4>
                                <p>
                                    There is generally no natural connection between a
                                    linguistic form and what it represents.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Productivity</h4>
                                <p>
                                    Speakers can produce and understand new utterances
                                    they have never encountered before.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Duality of Patterning</h4>
                                <p>
                                    Meaningful linguistic units can be built from smaller
                                    units that do not themselves carry meaning.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Displacement</h4>
                                <p>
                                    Language can communicate about things that are
                                    distant in time or space.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Cultural Transmission</h4>
                                <p>
                                    Language is acquired through interaction with members
                                    of a speech community.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Functions of Language",

                        content: `
                            <ul>
                                <li><strong>Informative:</strong> communicating information.</li>
                                <li><strong>Expressive:</strong> expressing feelings and attitudes.</li>
                                <li><strong>Directive:</strong> influencing the behaviour of others.</li>
                                <li><strong>Phatic:</strong> establishing or maintaining social contact.</li>
                                <li><strong>Imaginative:</strong> creating imaginative or fictional experiences.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Define language.</li>
                                <li>Explain five characteristics of human language.</li>
                                <li>Discuss five functions of language.</li>
                                <li>Explain the concept of productivity in language.</li>
                            </ol>
                        `
                    }

                ]
            },


            "02": {

                title:
                    "Language Structure and Levels of Analysis",

                subtitle:
                    "How linguists study the organization of language",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Levels of Linguistic Analysis",

                        content: `
                            <p>
                                Language can be studied at different but interconnected
                                levels. Each level focuses on a particular aspect of
                                linguistic structure.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Major Levels",

                        content: `
                            <div class="concept-card">
                                <h4>Phonetics</h4>
                                <p>
                                    The scientific study of speech sounds and their
                                    physical properties.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Phonology</h4>
                                <p>
                                    The study of how sounds function and pattern within
                                    a particular language.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Morphology</h4>
                                <p>
                                    The study of morphemes and word structure.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Syntax</h4>
                                <p>
                                    The study of how words combine to form phrases,
                                    clauses and sentences.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Semantics</h4>
                                <p>
                                    The study of meaning encoded in linguistic expressions.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Pragmatics</h4>
                                <p>
                                    The study of meaning as influenced by context and
                                    language use.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Interrelationship of Linguistic Levels",

                        content: `
                            <p>
                                Linguistic levels are not isolated. Sound patterns
                                contribute to word formation; words combine into
                                syntactic structures; and linguistic structures are
                                interpreted for meaning in particular contexts.
                            </p>
                        `
                    },

                    {
                        type: "callout",

                        heading:
                            "Exam Tip",

                        content: `
                            <p>
                                Learn the distinction between <strong>phonetics,
                                phonology, morphology, syntax, semantics and
                                pragmatics</strong>. Questions often test both their
                                definitions and their differences.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Define morphology and syntax.</li>
                                <li>Distinguish between semantics and pragmatics.</li>
                                <li>Explain the relationship between phonetics and phonology.</li>
                                <li>Discuss the major levels of linguistic analysis.</li>
                            </ol>
                        `
                    }

                ]
            },


            "03": {

                title:
                    "English as a Global Language",

                subtitle:
                    "Spread, varieties and functions of English",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Global Spread of English",

                        content: `
                            <p>
                                English has developed into a major international language
                                used in education, government, science, technology,
                                business, diplomacy and international communication.
                            </p>

                            <p>
                                Its global spread has resulted from historical,
                                political, economic, educational and technological
                                factors.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Major Contexts of English Use",

                        content: `
                            <div class="concept-card">
                                <h4>Native English Contexts</h4>
                                <p>
                                    English is historically established as a first
                                    language for large populations.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Second-Language Contexts</h4>
                                <p>
                                    English serves important institutional and
                                    communicative functions alongside indigenous languages.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Foreign-Language Contexts</h4>
                                <p>
                                    English is primarily learned for international
                                    communication rather than being a major local language.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "English in Nigeria",

                        content: `
                            <p>
                                English performs major official, educational and
                                institutional functions in Nigeria. It is widely used in
                                schools, government, formal communication, the media and
                                many professional contexts.
                            </p>

                            <p>
                                Nigerian English also reflects the influence of Nigeria's
                                multilingual environment. Contact with indigenous
                                languages can influence pronunciation, vocabulary,
                                grammar and patterns of usage.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Code-Switching and Code-Mixing",

                        content: `
                            <p>
                                <strong>Code-switching</strong> refers to movement from
                                one language or variety to another during communication.
                            </p>

                            <p>
                                <strong>Code-mixing</strong> refers to the incorporation
                                of elements from different linguistic codes within
                                communication.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Discuss the major factors responsible for the global spread of English.</li>
                                <li>Explain the functions of English in Nigeria.</li>
                                <li>Distinguish between code-switching and code-mixing.</li>
                                <li>Discuss the concept of World Englishes.</li>
                            </ol>
                        `
                    }

                ]
            },


            "04": {

                title:
                    "Language, Society and Communication",

                subtitle:
                    "Understanding language variation and use",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Language and Society",

                        content: `
                            <p>
                                Language is closely connected to society because speakers
                                use language within social groups and cultural contexts.
                                Social factors can influence how people speak and the
                                varieties they use.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Factors Influencing Language Variation",

                        content: `
                            <ul>
                                <li>Geographical location.</li>
                                <li>Social class.</li>
                                <li>Age.</li>
                                <li>Gender and social roles.</li>
                                <li>Occupation.</li>
                                <li>Education.</li>
                                <li>Ethnic and cultural background.</li>
                                <li>Communication context.</li>
                            </ul>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Dialect and Register",

                        content: `
                            <p>
                                A <strong>dialect</strong> is a variety of language
                                associated with a particular geographical or social group.
                            </p>

                            <p>
                                A <strong>register</strong> is a variety of language
                                associated with a particular situation, activity,
                                profession or level of formality.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Effective Communication",

                        content: `
                            <p>
                                Effective communication requires more than grammatical
                                knowledge. Speakers need to consider the purpose,
                                audience, context, appropriate vocabulary and the
                                relationship between participants.
                            </p>
                        `
                    },

                    {
                        type: "revision-box",

                        heading:
                            "ENG 205 Final Revision",

                        content: `
                            <ul>
                                <li>Language is systematic, conventional and productive.</li>
                                <li>Phonetics studies speech sounds physically.</li>
                                <li>Phonology studies sound systems and patterns.</li>
                                <li>Morphology studies word structure.</li>
                                <li>Syntax studies sentence structure.</li>
                                <li>Semantics studies linguistic meaning.</li>
                                <li>Pragmatics studies context-dependent meaning.</li>
                                <li>English functions as an important international language.</li>
                                <li>Language varies according to social and contextual factors.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Hard Mock Questions",

                        content: `
                            <ol>
                                <li>
                                    Discuss the major characteristics that distinguish
                                    human language from other communication systems.
                                </li>

                                <li>
                                    Explain the relationship between language and society,
                                    using appropriate examples.
                                </li>

                                <li>
                                    Distinguish between dialect, register, code-switching
                                    and code-mixing.
                                </li>

                                <li>
                                    Discuss the major levels of linguistic analysis and
                                    explain how they relate to one another.
                                </li>

                                <li>
                                    Examine the position and functions of English in
                                    contemporary Nigerian society.
                                </li>
                            </ol>
                        `
                    }

                ]
            }

        }

    },


    /* =====================================================
       LAS 244
       LIBRARY / INFORMATION STUDIES
    ===================================================== */

    LAS244: {

        code:
            "LAS 244",

        title:
            "Library and Information Studies",

        department:
            "General Studies",

        units: 2,

        access:
            "free",

        description:
            "An introduction to libraries, information resources, research skills, information literacy and effective academic information use.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {

            "01": {

                title:
                    "Meaning, Types and Functions of Libraries",

                subtitle:
                    "Understanding libraries as information centres",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Meaning of a Library",

                        content: `
                            <p>
                                A library is an organized institution or service that
                                selects, acquires, organizes, preserves and provides
                                access to information resources for users.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Types of Libraries",

                        content: `
                            <div class="concept-card">
                                <h4>Academic Library</h4>
                                <p>
                                    Supports teaching, learning and research within
                                    universities and other tertiary institutions.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Public Library</h4>
                                <p>
                                    Provides information and educational resources to the
                                    general public.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>School Library</h4>
                                <p>
                                    Supports teaching and learning within primary or
                                    secondary educational institutions.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Special Library</h4>
                                <p>
                                    Serves the information needs of a particular
                                    organization, profession or specialized field.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>National Library</h4>
                                <p>
                                    Serves national information and bibliographic
                                    functions and preserves important national publications.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Functions of Libraries",

                        content: `
                            <ul>
                                <li>Providing access to information.</li>
                                <li>Supporting education and research.</li>
                                <li>Preserving knowledge and cultural materials.</li>
                                <li>Promoting reading and lifelong learning.</li>
                                <li>Providing reference and information services.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Define a library.</li>
                                <li>Explain five types of libraries.</li>
                                <li>Discuss five functions of an academic library.</li>
                            </ol>
                        `
                    }

                ]
            },


            "02": {

                title:
                    "Information Sources and Resources",

                subtitle:
                    "Finding reliable academic information",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Primary Sources",

                        content: `
                            <p>
                                Primary sources contain original information or direct
                                evidence about a subject. Examples include original
                                research articles, interviews, datasets, official
                                documents and certain historical records.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Secondary Sources",

                        content: `
                            <p>
                                Secondary sources analyze, interpret, summarize or
                                discuss information contained in primary sources.
                                Examples include review articles, biographies and many
                                scholarly books.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Tertiary Sources",

                        content: `
                            <p>
                                Tertiary sources organize or summarize information from
                                primary and secondary sources. Examples include
                                encyclopedias, indexes and some reference databases.
                            </p>
                        `
                    },

                    {
                        type: "callout",

                        heading:
                            "Academic Rule",

                        content: `
                            <p>
                                Always evaluate information before relying on it.
                                Consider the <strong>authority, accuracy, currency,
                                relevance and purpose</strong> of the source.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Distinguish between primary and secondary sources.</li>
                                <li>What are tertiary information sources?</li>
                                <li>State five criteria for evaluating an information source.</li>
                            </ol>
                        `
                    }

                ]
            },


            "03": {

                title:
                    "Information Literacy and Research Skills",

                subtitle:
                    "Finding, evaluating and using information effectively",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Information Literacy",

                        content: `
                            <p>
                                Information literacy is the ability to recognize an
                                information need and to locate, evaluate, use and
                                communicate information effectively and ethically.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Basic Research Process",

                        content: `
                            <div class="concept-card">
                                <h4>1. Identify the Topic</h4>
                                <p>
                                    Clearly determine the question or problem being investigated.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>2. Develop Search Terms</h4>
                                <p>
                                    Identify keywords and related terms that can improve
                                    information retrieval.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>3. Locate Sources</h4>
                                <p>
                                    Search library catalogues, databases, books,
                                    journals and reliable online sources.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>4. Evaluate Sources</h4>
                                <p>
                                    Check authority, accuracy, relevance, currency and
                                    purpose.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>5. Record and Cite Information</h4>
                                <p>
                                    Keep accurate notes and acknowledge sources properly.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Avoiding Plagiarism",

                        content: `
                            <p>
                                Plagiarism is the presentation of another person's words,
                                ideas or intellectual work as one's own without
                                appropriate acknowledgement.
                            </p>

                            <p>
                                Students can avoid plagiarism by using proper citation,
                                quotation where necessary, accurate paraphrasing and
                                maintaining clear research notes.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Define information literacy.</li>
                                <li>Explain the major stages of the research process.</li>
                                <li>What is plagiarism?</li>
                                <li>State four ways of avoiding plagiarism.</li>
                            </ol>
                        `
                    }

                ]
            },


            "04": {

                title:
                    "Digital Information, Library Services and Academic Success",

                subtitle:
                    "Using modern information systems responsibly",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Digital Libraries",

                        content: `
                            <p>
                                A digital library provides organized electronic access
                                to information resources through computers and other
                                digital devices.
                            </p>

                            <p>
                                Digital resources may include electronic books,
                                scholarly journals, institutional repositories,
                                databases, theses and multimedia materials.
                            </p>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Advantages of Digital Information Services",

                        content: `
                            <ul>
                                <li>Rapid access to information.</li>
                                <li>Remote availability.</li>
                                <li>Large storage capacity.</li>
                                <li>Powerful search capabilities.</li>
                                <li>Access to current scholarly materials.</li>
                            </ul>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Responsible Use of Information",

                        content: `
                            <p>
                                Responsible information use requires respect for
                                intellectual property, privacy, academic integrity and
                                the rights of information creators.
                            </p>

                            <p>
                                Students should verify online information instead of
                                accepting every digital source as accurate.
                            </p>
                        `
                    },

                    {
                        type: "revision-box",

                        heading:
                            "LAS 244 Final Revision",

                        content: `
                            <ul>
                                <li>Libraries organize and provide access to information.</li>
                                <li>Academic libraries support teaching, learning and research.</li>
                                <li>Primary sources provide original evidence.</li>
                                <li>Secondary sources analyze or interpret existing information.</li>
                                <li>Information literacy involves finding, evaluating and using information effectively.</li>
                                <li>Plagiarism violates academic integrity.</li>
                                <li>Digital information must be evaluated critically.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Hard Mock Questions",

                        content: `
                            <ol>
                                <li>
                                    Discuss the role of the academic library in
                                    university education.
                                </li>

                                <li>
                                    Differentiate between primary, secondary and
                                    tertiary sources with examples.
                                </li>

                                <li>
                                    Explain the importance of information literacy
                                    to university students.
                                </li>

                                <li>
                                    Discuss plagiarism and explain practical ways
                                    students can avoid it.
                                </li>

                                <li>
                                    Examine the advantages and limitations of digital
                                    information resources.
                                </li>
                            </ol>
                        `
                    }

                ]
            }

        }

    },

        /* =====================================================
       COURSE LIBRARY COMPLETION
       Remaining course entries
    ===================================================== */


    /* =====================================================
       COURSE: EDU 212
       INTRODUCTION TO EDUCATIONAL TECHNOLOGY
    ===================================================== */

    EDU212: {

        code:
            "EDU 212",

        title:
            "Introduction to Educational Technology",

        department:
            "Education",

        units: 2,

        access:
            "free",

        description:
            "An introduction to educational technology, instructional media, communication and the effective use of technology in teaching and learning.",

        examFocus: true,

        sequential: true,

        moduleCount: 4,

        notes: {

            "01": {

                title:
                    "Meaning and Scope of Educational Technology",

                subtitle:
                    "Understanding technology in education",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Meaning of Educational Technology",

                        content: `
                            <p>
                                Educational technology is the systematic application
                                of knowledge, processes, tools and resources to improve
                                teaching, learning and educational performance.
                            </p>

                            <p>
                                It is not limited to computers or digital devices.
                                Educational technology also includes instructional
                                methods, materials, processes and systems designed to
                                facilitate learning.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Major Components",

                        content: `
                            <div class="concept-card">
                                <h4>People</h4>
                                <p>
                                    Teachers, learners, administrators, technicians and
                                    other participants in the educational process.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Processes</h4>
                                <p>
                                    Planning, designing, teaching, assessment and
                                    evaluation procedures.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Materials</h4>
                                <p>
                                    Textbooks, charts, models, audio resources,
                                    audiovisual materials and digital resources.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Equipment</h4>
                                <p>
                                    Computers, projectors, cameras and other technological
                                    devices used to support instruction.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Importance of Educational Technology",

                        content: `
                            <ul>
                                <li>Improves access to learning resources.</li>
                                <li>Supports different learning experiences.</li>
                                <li>Can increase learner engagement.</li>
                                <li>Facilitates communication and collaboration.</li>
                                <li>Supports efficient assessment and feedback.</li>
                                <li>Provides access to current information.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Define educational technology.</li>
                                <li>Explain four components of educational technology.</li>
                                <li>Discuss five benefits of educational technology.</li>
                            </ol>
                        `
                    }

                ]
            },


            "02": {

                title:
                    "Instructional Media and Learning Resources",

                subtitle:
                    "Selecting and using materials effectively",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Instructional Media",

                        content: `
                            <p>
                                Instructional media are materials, devices or channels
                                used to communicate information and facilitate teaching
                                and learning.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Examples of Instructional Media",

                        content: `
                            <div class="concept-card">
                                <h4>Visual Media</h4>
                                <p>
                                    Charts, diagrams, maps, photographs, posters and
                                    models.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Audio Media</h4>
                                <p>
                                    Recorded speech, radio programmes, podcasts and
                                    other sound-based materials.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Audiovisual Media</h4>
                                <p>
                                    Videos, educational films and multimedia presentations.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Digital Media</h4>
                                <p>
                                    Websites, learning management systems, educational
                                    applications and electronic books.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Principles for Selecting Instructional Materials",

                        content: `
                            <ul>
                                <li>Relevance to the lesson objectives.</li>
                                <li>Suitability for the learners.</li>
                                <li>Accuracy of information.</li>
                                <li>Clarity and simplicity.</li>
                                <li>Availability and affordability.</li>
                                <li>Safety and durability.</li>
                                <li>Ease of use.</li>
                            </ul>
                        `
                    },

                    {
                        type: "callout",

                        heading:
                            "Key Principle",

                        content: `
                            <p>
                                A technologically advanced resource is not automatically
                                an effective instructional resource. Its usefulness
                                depends on how well it supports the intended learning
                                objective.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>What are instructional media?</li>
                                <li>Explain four categories of instructional media.</li>
                                <li>Discuss five factors to consider when selecting instructional materials.</li>
                            </ol>
                        `
                    }

                ]
            },


            "03": {

                title:
                    "Communication and Technology in Teaching",

                subtitle:
                    "Using technology to improve classroom communication",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Communication in Education",

                        content: `
                            <p>
                                Educational communication is the process through which
                                teachers and learners exchange information, ideas,
                                instructions, feedback and meanings during the learning
                                process.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Elements of Communication",

                        content: `
                            <div class="concept-card">
                                <h4>Sender</h4>
                                <p>
                                    The person or source initiating the message.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Message</h4>
                                <p>
                                    The information or idea being communicated.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Channel</h4>
                                <p>
                                    The medium through which the message is transmitted.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Receiver</h4>
                                <p>
                                    The person or group for whom the message is intended.
                                </p>
                            </div>

                            <div class="concept-card">
                                <h4>Feedback</h4>
                                <p>
                                    The response that indicates how the receiver
                                    understood the message.
                                </p>
                            </div>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Barriers to Educational Communication",

                        content: `
                            <ul>
                                <li>Language difficulties.</li>
                                <li>Noise and environmental distractions.</li>
                                <li>Poorly designed instructional materials.</li>
                                <li>Lack of learner attention.</li>
                                <li>Technical problems.</li>
                                <li>Differences in prior knowledge.</li>
                                <li>Unclear instructions.</li>
                            </ul>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Technology-Enhanced Communication",

                        content: `
                            <p>
                                Digital platforms can support communication through
                                online classrooms, discussion forums, email, learning
                                management systems, video lessons and collaborative
                                documents.
                            </p>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Practice Questions",

                        content: `
                            <ol>
                                <li>Explain the elements of communication.</li>
                                <li>Discuss five barriers to effective classroom communication.</li>
                                <li>Explain how technology can improve educational communication.</li>
                            </ol>
                        `
                    }

                ]
            },


            "04": {

                title:
                    "Technology Integration and Educational Evaluation",

                subtitle:
                    "Making technology part of effective instruction",

                sections: [

                    {
                        type: "lesson",

                        heading:
                            "Technology Integration",

                        content: `
                            <p>
                                Technology integration refers to the purposeful use of
                                technological resources as part of teaching, learning
                                and assessment.
                            </p>

                            <p>
                                Effective integration begins with the learning objective,
                                not with the technology itself.
                            </p>
                        `
                    },

                    {
                        type: "concept",

                        heading:
                            "Benefits of Technology Integration",

                        content: `
                            <ul>
                                <li>Improved access to learning materials.</li>
                                <li>Greater opportunities for collaboration.</li>
                                <li>Flexible learning environments.</li>
                                <li>Faster access to feedback.</li>
                                <li>Support for multimedia learning.</li>
                                <li>Opportunities for personalized learning.</li>
                            </ul>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Challenges of Educational Technology",

                        content: `
                            <ul>
                                <li>Limited electricity or internet access.</li>
                                <li>Cost of devices and infrastructure.</li>
                                <li>Insufficient teacher training.</li>
                                <li>Technical difficulties.</li>
                                <li>Digital inequality.</li>
                                <li>Distraction and inappropriate technology use.</li>
                            </ul>
                        `
                    },

                    {
                        type: "lesson",

                        heading:
                            "Evaluation of Technology-Based Learning",

                        content: `
                            <p>
                                Technology-based instruction should still be evaluated
                                according to learning outcomes. Teachers should determine
                                whether the technology improves understanding,
                                participation, achievement or efficiency.
                            </p>
                        `
                    },

                    {
                        type: "revision-box",

                        heading:
                            "EDU 212 Final Revision",

                        content: `
                            <ul>
                                <li>Educational technology includes people, processes, materials and equipment.</li>
                                <li>Instructional media support communication of learning content.</li>
                                <li>Technology should serve learning objectives.</li>
                                <li>Effective communication requires feedback.</li>
                                <li>Technology integration has both benefits and challenges.</li>
                                <li>Educational technology should be evaluated by its effect on learning.</li>
                            </ul>
                        `
                    },

                    {
                        type: "section-exam",

                        heading:
                            "Hard Mock Questions",

                        content: `
                            <ol>
                                <li>
                                    Explain the concept of educational technology and
                                    distinguish it from the mere use of electronic devices.
                                </li>

                                <li>
                                    Discuss the major factors that should guide the
                                    selection of instructional media.
                                </li>

                                <li>
                                    Examine the barriers to effective technology
                                    integration in Nigerian education.
                                </li>

                                <li>
                                    Explain how technology can improve teaching,
                                    learning and assessment.
                                </li>
                            </ol>
                        `
                    }

                ]
            }

        }

    },


    /* =====================================================
       SAFETY FALLBACK METADATA
       Keeps course navigation predictable.
    ===================================================== */

    COURSE_ORDER: [
        "GST212",
        "GST211",
        "EDU201",
        "UNIBENEDU212",
        "ENG205",
        "LAS244",
        "ENG201",
        "ENG203",
        "ENL210",
        "EDU211",
        "EDU212"
    ]

};




/* =========================================================
   COURSE ID COMPATIBILITY
   ---------------------------------------------------------
   The main course system uses these IDs:
   ENT211
   UNIBENEDU211
   UNIBENENL210

   Some older note-library entries use:
   GST211
   EDU211
   ENL210

   These aliases keep the existing course notes working
   without duplicating or rewriting the note content.
========================================================= */

noteLibrary.ENT211 =
    noteLibrary.GST211;

noteLibrary.UNIBENEDU211 =
    noteLibrary.EDU211;

noteLibrary.UNIBENENL210 =
    noteLibrary.ENL210;


/* =========================================================
   BOOKWORM COURSE READER
========================================================= */

const Reader = {

    course: null,

    note: null,

    courseSlug: "",

    moduleNumber: "01",

    sections: [],

    examQuestions: [],

    savedProgress: 0,

    progressSaveTimer: null,

    progressLastSaved: 0,


    /* =====================================================
       INITIALISE READER
    ===================================================== */

    async init() {

        const params =
            new URLSearchParams(
                window.location.search
            );


        this.courseSlug =
            String(
                params.get("course") ||
                "GST212"
            )
                .trim()
                .toUpperCase()
                .replace(
                    /\s+/g,
                    ""
                );


        this.moduleNumber =
            String(
                params.get("module") ||
                "01"
            ).padStart(
                2,
                "0"
            );


        /*
         * -----------------------------------------------
         * FIND COURSE
         * -----------------------------------------------
         */

        this.course =
            noteLibrary[
                this.courseSlug
            ];


        if (!this.course) {

            this.showError(
                "Course not found",
                "The requested course could not be found."
            );

            return;

        }


        /*
         * -----------------------------------------------
         * FIND MODULE
         * -----------------------------------------------
         */

        this.note =
            this.course.notes[
                this.moduleNumber
            ];


        if (!this.note) {

            this.showError(
                "Module not found",
                "This module has not been published yet."
            );

            return;

        }


        /*
         * -----------------------------------------------
         * PREMIUM CHECK
         * -----------------------------------------------
         *
         * Wait for the existing premium engine.
         */

        if (
            window.BookwormPremium &&
            window.BookwormPremium.ready
        ) {

            await window.BookwormPremium.ready;

        }


        /*
         * Check access BEFORE rendering
         * protected content.
         */

        if (
            window.BookwormPremium
        ) {

            const allowed =
                window.BookwormPremium
                    .canAccessModule(
                        this.courseSlug,
                        parseInt(
                            this.moduleNumber,
                            10
                        )
                    );


            if (!allowed) {

                this.renderHeader();

                this.renderPremiumLock();

                this.renderNavigation();

                this.bindEvents();

                return;

            }

        }


        /*
         * -----------------------------------------------
         * NORMAL READER
         * -----------------------------------------------
         */

        this.render();

        this.bindEvents();

        await this.loadSavedProgress();

        this.prepareReadingExperience();

    },


    /* =====================================================
       RENDER EVERYTHING
    ===================================================== */

    render() {

        this.renderHeader();

        this.renderContent();

        this.renderExamPractice();

        this.renderNavigation();

    },


    /* =====================================================
       HEADER
    ===================================================== */

    renderHeader() {

        const courseCode =
            document.getElementById(
                "noteCourseCode"
            );


        const moduleLabel =
            document.getElementById(
                "noteModuleLabel"
            );


        const title =
            document.getElementById(
                "noteTitle"
            );


        const meta =
            document.getElementById(
                "noteMeta"
            );


        if (courseCode) {

            courseCode.textContent =
                this.course.code ||
                this.courseSlug;

        }


        if (moduleLabel) {

            moduleLabel.textContent =
                `MODULE ${this.moduleNumber}`;

        }


        if (title) {

            title.textContent =
                this.note.title ||
                "Untitled Module";

        }


        if (meta) {

            const subtitle =
                this.note.subtitle ||
                this.note.description ||
                this.course.description ||
                "";


            meta.textContent =
                subtitle;

        }


        document.title =
            `${this.note.title || "Course Note"} | Bookworm Club`;

    },


    /* =====================================================
       RENDER LESSON CONTENT
       Supports:
       1. Legacy content
       2. Structured sections[]
    ===================================================== */

    renderContent() {

        const container =
            document.getElementById(
                "noteContent"
            );


        if (!container) {

            return;

        }


        /*
         * Legacy note format.
         */

        if (
            typeof this.note.content ===
            "string"
        ) {

            container.innerHTML =
                this.note.content;

        }


        /*
         * Structured note format.
         */

        else if (
            Array.isArray(
                this.note.sections
            )
        ) {

            container.innerHTML =
                this.renderStructuredSections(
                    this.note.sections
                );

        }


        /*
         * Safety fallback.
         */

        else {

            container.innerHTML = `

                <section class="lesson-section">

                    <h2>
                        Content unavailable
                    </h2>

                    <p>
                        This module is currently being
                        prepared. Please check again later.
                    </p>

                </section>

            `;

        }


        this.sections =
            Array.from(
                container.querySelectorAll(
                    ".lesson-section"
                )
            );


        this.decorateSections();

        this.decorateLists();

        this.decorateBlockquotes();

        this.decorateHeadings();

        this.decorateRevisionBoxes();

        this.decorateConceptSections();

    },


    /* =====================================================
       STRUCTURED SECTION RENDERER
    ===================================================== */

    renderStructuredSections(
        sections
    ) {

        if (
            !Array.isArray(sections) ||
            !sections.length
        ) {

            return `

                <section class="lesson-section">

                    <h2>
                        Module Content
                    </h2>

                    <p>
                        No lesson content is available yet.
                    </p>

                </section>

            `;

        }


        return sections.map(
            (section, index) => {

                if (!section) {

                    return "";

                }


                const type =
                    String(
                        section.type ||
                        "lesson"
                    ).toLowerCase();


                const heading =
                    section.heading ||
                    "";


                const content =
                    section.content ||
                    "";


                let classes =
                    "lesson-section";


                if (
                    type === "callout"
                ) {

                    classes +=
                        " callout";

                }


                if (
                    type === "concept"
                ) {

                    classes +=
                        " concept-section";

                }


        if (
    type === "section-exam"
) {

    classes +=
        " section-exam exam-practice-panel";

}

                if (
                    type === "revision-box"
                ) {

                    classes +=
                        " revision-box";

                }


                if (
                    type === "example"
                ) {

                    classes +=
                        " section-example";

                }


                return `

                    <section
                        class="${classes}"
                        data-structured-type="${this.escapeHTML(type)}"
                        data-section-index="${index + 1}"
                    >

                        ${
                            heading
                                ? `<h2>${this.escapeHTML(heading)}</h2>`
                                : ""
                        }

                        ${content}

                    </section>

                `;

            }
        ).join("");

    },


    /* =====================================================
       EXAM PRACTICE
    ===================================================== */

    renderExamPractice() {

        const container =
            document.getElementById(
                "examQuestions"
            );


        const examSection =
            document.getElementById(
                "examPractice"
            );


        if (
            !container
        ) {

            return;

        }


        let examHTML = "";


        /*
         * Explicit examQuestions support.
         */

        if (
            Array.isArray(
                this.note.examQuestions
            ) &&
            this.note.examQuestions.length
        ) {

            examHTML = `

                <ol>

                    ${
                        this.note.examQuestions
                            .map(
                                question => `
                                    <li>
                                        ${question}
                                    </li>
                                `
                            )
                            .join("")
                    }

                </ol>

            `;

        }


        /*
         * Structured notes use section-exam.
         */

        else if (
            Array.isArray(
                this.note.sections
            )
        ) {

            const examSections =
                this.note.sections.filter(
                    section =>
                        section &&
                        String(
                            section.type ||
                            ""
                        ).toLowerCase() ===
                        "section-exam"
                );


            if (
                examSections.length
            ) {

                examHTML =
                    examSections
                        .map(
                            section =>
                                section.content ||
                                ""
                        )
                        .join("");

            }

        }


        /*
         * Legacy notes.
         */

        else if (
            typeof this.note.content ===
            "string"
        ) {

            const temporary =
                document.createElement(
                    "div"
                );


            temporary.innerHTML =
                this.note.content;


            const examBlocks =
                temporary.querySelectorAll(
                    ".section-exam"
                );


            examHTML =
                Array.from(
                    examBlocks
                )
                    .map(
                        block =>
                            block.innerHTML
                    )
                    .join("");

        }


        if (
            examHTML
        ) {

            container.innerHTML =
                examHTML;

            if (examSection) {

                examSection.style.display =
                    "";

            }

        } else {

            container.innerHTML = "";

            if (examSection) {

                examSection.style.display =
                    "none";

            }

        }

    },


    /* =====================================================
       NAVIGATION
    ===================================================== */

    renderNavigation() {

        const previous =
            document.getElementById(
                "previousModule"
            );


        const next =
            document.getElementById(
                "nextModule"
            );


        const previousTitle =
            document.getElementById(
                "previousModuleTitle"
            );


        const nextTitle =
            document.getElementById(
                "nextModuleTitle"
            );


        const backTop =
            document.getElementById(
                "backToCourse"
            );


        const backBottom =
            document.getElementById(
                "backToCourseBottom"
            );

            const moduleProgress =
    document.getElementById(
        "moduleProgress"
    );


        const current =
            parseInt(
                this.moduleNumber,
                10
            );


        const total =
            Number(
                this.course.moduleCount ||
                Object.keys(
                    this.course.notes || {}
                ).length
            );

            if (moduleProgress) {

    moduleProgress.textContent =
        `${String(current).padStart(2, "0")} / ${String(total).padStart(2, "0")}`;

}


        /*
         * -----------------------------------------------
         * BACK TO COURSE
         * -----------------------------------------------
         */

        const courseURL =
            `course.html?course=${encodeURIComponent(
                this.courseSlug
            )}`;


        if (backTop) {

            backTop.href =
                courseURL;

        }


        if (backBottom) {

            backBottom.href =
                courseURL;

        }


        /*
         * -----------------------------------------------
         * PREVIOUS
         * -----------------------------------------------
         */

        if (
            current > 1
        ) {

            const previousNumber =
                String(
                    current - 1
                ).padStart(
                    2,
                    "0"
                );


            const previousNote =
                this.course.notes[
                    previousNumber
                ];


            if (previous) {

                previous.href =
                    `course-note.html?course=${encodeURIComponent(
                        this.courseSlug
                    )}&module=${previousNumber}`;

                previous.dataset.module =
                    previousNumber;

                previous.classList.remove(
                    "is-disabled"
                );

            }


            if (previousTitle) {

                previousTitle.textContent =
                    previousNote?.title ||
                    `Module ${previousNumber}`;

            }

        } else {

            if (previous) {

                previous.href =
                    "#";

                previous.classList.add(
                    "is-disabled"
                );

            }


            if (previousTitle) {

                previousTitle.textContent =
                    "Beginning of course";

            }

        }


        /*
         * -----------------------------------------------
         * NEXT
         * -----------------------------------------------
         */

        if (
            current < total
        ) {

            const nextNumber =
                String(
                    current + 1
                ).padStart(
                    2,
                    "0"
                );


            const nextNote =
                this.course.notes[
                    nextNumber
                ];


            const nextAllowed =
                window.BookwormPremium
                    ? window.BookwormPremium
                        .canAccessModule(
                            this.courseSlug,
                            current + 1
                        )
                    : true;


            if (next) {

                next.href =
                    `course-note.html?course=${encodeURIComponent(
                        this.courseSlug
                    )}&module=${nextNumber}`;

                next.dataset.module =
                    nextNumber;


                if (!nextAllowed) {

                    next.classList.add(
                        "premium-next"
                    );

                } else {

                    next.classList.remove(
                        "premium-next"
                    );

                }

            }


            if (nextTitle) {

                nextTitle.textContent =
                    nextAllowed
                        ? (
                            nextNote?.title ||
                            `Module ${nextNumber}`
                        )
                        : "🔒 Unlock Premium";

            }

        } else {

            if (next) {

                next.href =
                    "#";

                next.classList.add(
                    "is-disabled"
                );

            }


            if (nextTitle) {

                nextTitle.textContent =
                    "End of course";

            }

        }

    },


    /* =====================================================
       PREMIUM LOCK
    ===================================================== */

    renderPremiumLock() {

        const container =
            document.getElementById(
                "noteContent"
            );


        if (!container) {

            return;

        }


        container.innerHTML = `

            <section class="premium-lock-screen">

                <div class="premium-lock-icon">
                    🔒
                </div>

                <p class="premium-eyebrow">
                    PREMIUM COURSE
                </p>

                <h2>
                    Unlock this module
                </h2>

                <p>
                    Module ${this.moduleNumber}
                    is part of the
                    <strong>
                        200 Level First Semester Premium Access
                    </strong>
                    package.
                </p>

                <p>
                    Module 01 is available as a free preview.
                    Premium access unlocks the remaining modules.
                </p>

                <div class="premium-lock-actions">

                    <a
                        href="premium.html"
                        class="btn btn-primary"
                    >
                        View Premium Access
                    </a>

                    <a
                        href="course.html?course=${encodeURIComponent(
                            this.courseSlug
                        )}"
                        class="btn btn-secondary"
                    >
                        Back to Course
                    </a>

                </div>

            </section>

        `;


        const exam =
            document.getElementById(
                "examPractice"
            );


        if (exam) {

            exam.style.display =
                "none";

        }


        const progress =
            document.getElementById(
                "readingProgress"
            );


        if (progress) {

            progress.style.width =
                "0%";

        }

    },


    /* =====================================================
       EVENTS
    ===================================================== */

    bindEvents() {

        const previous =
            document.getElementById(
                "previousModule"
            );


        const next =
            document.getElementById(
                "nextModule"
            );


        if (previous) {

            previous.addEventListener(
                "click",
                event => {

                    if (
                        previous.classList.contains(
                            "is-disabled"
                        )
                    ) {

                        event.preventDefault();

                    }

                }
            );

        }


        if (next) {

            next.addEventListener(
                "click",
                event => {

                    if (
                        next.classList.contains(
                            "is-disabled"
                        )
                    ) {

                        event.preventDefault();

                        return;

                    }


                    const targetModule =
                        parseInt(
                            next.dataset.module,
                            10
                        );


                    if (
                        window.BookwormPremium
                    ) {

                        const allowed =
                            window.BookwormPremium
                                .canAccessModule(
                                    this.courseSlug,
                                    targetModule
                                );


                        if (!allowed) {

                            event.preventDefault();

                            this.showPremiumMessage();

                        }

                    }

                }
            );

        }


        /*
         * Keyboard navigation.
         */

        document.addEventListener(
            "keydown",
            event => {

                if (
                    event.key ===
                    "ArrowLeft"
                ) {

                    if (
                        previous &&
                        !previous.classList.contains(
                            "is-disabled"
                        )
                    ) {

                        previous.click();

                    }

                }


                if (
                    event.key ===
                    "ArrowRight"
                ) {

                    if (
                        next &&
                        !next.classList.contains(
                            "is-disabled"
                        )
                    ) {

                        next.click();

                    }

                }

            }
        );

    },


    /* =====================================================
       PREMIUM MESSAGE
    ===================================================== */

    showPremiumMessage() {

        const title =
            document.getElementById(
                "nextModuleTitle"
            );


        if (title) {

            const original =
                title.textContent;


            title.textContent =
                "🔒 Premium access required";


            setTimeout(
                () => {

                    title.textContent =
                        original;

                },
                2500
            );

        }

    },


    /* =====================================================
       READING EXPERIENCE
    ===================================================== */

    prepareReadingExperience() {

        this.updateReadingProgress();


        window.addEventListener(
            "scroll",
            () => {

                this.updateReadingProgress();

            },
            {
                passive: true
            }
        );

    },


    updateReadingProgress() {

        const progressBar =
            document.getElementById(
                "readingProgress"
            );


        if (!progressBar) {

            return;

        }


        const documentHeight =
            document.documentElement
                .scrollHeight -
            window.innerHeight;


        if (
            documentHeight <= 0
        ) {

            progressBar.style.width =
                "100%";

            return;

        }


        const percent =
            Math.round(
                (
                    window.scrollY /
                    documentHeight
                ) * 100
            );


        const safePercent =
            Math.max(
                0,
                Math.min(
                    100,
                    percent
                )
            );


        progressBar.style.width =
            `${safePercent}%`;


        /*
         * Save progress only after the student
         * has meaningfully read the module.
         */

        if (
            safePercent >= 90
        ) {

            this.scheduleProgressSave(
                100
            );

        } else {

            this.scheduleProgressSave(
                safePercent
            );

        }

    },


    /* =====================================================
       PROGRESS SAVE
    ===================================================== */

    scheduleProgressSave(
        percent
    ) {

        if (
            !window.BookwormProgress ||
            !window.BookwormProgress.saveModuleProgress
        ) {

            return;

        }


        const rounded =
            Math.max(
                0,
                Math.min(
                    100,
                    Math.round(
                        percent
                    )
                )
            );


        if (
            rounded <=
            this.progressLastSaved
        ) {

            return;

        }


        clearTimeout(
            this.progressSaveTimer
        );


        this.progressSaveTimer =
            setTimeout(
                async () => {

                    try {

                        await window.BookwormProgress
                            .saveModuleProgress(
                                this.course.code ||
                                this.courseSlug,
                                parseInt(
                                    this.moduleNumber,
                                    10
                                ),
                                rounded
                            );


                        this.progressLastSaved =
                            rounded;

                    } catch (error) {

                        console.error(
                            "Bookworm Reader: progress save failed.",
                            error
                        );

                    }

                },
                700
            );

    },


    /* =====================================================
       LOAD SAVED PROGRESS
    ===================================================== */

    async loadSavedProgress() {

        if (
            !window.BookwormProgress ||
            !window.BookwormProgress.getModuleProgress
        ) {

            return;

        }


        try {

            const progress =
                await window.BookwormProgress
                    .getModuleProgress(
                        this.course.code ||
                        this.courseSlug,
                        parseInt(
                            this.moduleNumber,
                            10
                        )
                    );


            if (
                progress &&
                typeof progress.progress_percent !==
                "undefined"
            ) {

                this.savedProgress =
                    Number(
                        progress.progress_percent
                    ) || 0;

                this.progressLastSaved =
                    this.savedProgress;

            }

        } catch (error) {

            console.warn(
                "Bookworm Reader: could not load saved progress.",
                error
            );

        }

    },


    /* =====================================================
       VISUAL DECORATORS
    ===================================================== */

    decorateSections() {

        this.sections.forEach(
            (section, index) => {

                section.dataset.section =
                    String(
                        index + 1
                    );

            }
        );

    },


    decorateLists() {

        const container =
            document.getElementById(
                "noteContent"
            );


        if (!container) {

            return;

        }


        container
            .querySelectorAll(
                "ul, ol"
            )
            .forEach(
                list => {

                    list.classList.add(
                        "academic-list"
                    );

                }
            );

    },


    decorateBlockquotes() {

        const container =
            document.getElementById(
                "noteContent"
            );


        if (!container) {

            return;

        }


        container
            .querySelectorAll(
                "blockquote"
            )
            .forEach(
                blockquote => {

                    blockquote.classList.add(
                        "academic-quote"
                    );

                }
            );

    },


    decorateHeadings() {

        const container =
            document.getElementById(
                "noteContent"
            );


        if (!container) {

            return;

        }


        container
            .querySelectorAll(
                "h3, h4"
            )
            .forEach(
                heading => {

                    heading.classList.add(
                        "lesson-subheading"
                    );

                }
            );

    },


    decorateRevisionBoxes() {

        const container =
            document.getElementById(
                "noteContent"
            );


        if (!container) {

            return;

        }


        container
            .querySelectorAll(
                ".revision-box"
            )
            .forEach(
                box => {

                    box.classList.add(
                        "academic-revision-box"
                    );

                }
            );

    },


    decorateConceptSections() {

        const container =
            document.getElementById(
                "noteContent"
            );


        if (!container) {

            return;

        }


        container
            .querySelectorAll(
                ".concept-card"
            )
            .forEach(
                card => {

                    card.classList.add(
                        "academic-concept-card"
                    );

                }
            );

    },


    /* =====================================================
       ERROR SCREEN
    ===================================================== */

    showError(
        title,
        message
    ) {

        const container =
            document.getElementById(
                "noteContent"
            );


        if (!container) {

            return;

        }


        container.innerHTML = `

            <section class="lesson-section">

                <h2>
                    ${this.escapeHTML(title)}
                </h2>

                <p>
                    ${this.escapeHTML(message)}
                </p>

                <p>

                    <a
                        href="courses.html"
                    >
                        Return to Courses
                    </a>

                </p>

            </section>

        `;

    },


    /* =====================================================
       ESCAPE HTML
    ===================================================== */

    escapeHTML(
        value
    ) {

        return String(
            value ?? ""
        )
            .replace(
                /&/g,
                "&amp;"
            )
            .replace(
                /</g,
                "&lt;"
            )
            .replace(
                />/g,
                "&gt;"
            )
            .replace(
                /"/g,
                "&quot;"
            )
            .replace(
                /'/g,
                "&#039;"
            );

    }

};


/* =========================================================
   START READER
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        Reader.init();

    }
);


/* =========================================================
   GLOBAL ACCESS
========================================================= */

window.BookwormReader =
    Reader;


/* =========================================================
   NOTE LIBRARY + READER READY
========================================================= */

console.log(
    "BOOKWORM: Course Reader ready."
);


/* =========================================================
   NOTE LIBRARY COMPLETE
========================================================= */

