/* ==========================================
   BOOKWORM CLUB — FEEDBACK
========================================== */

document.addEventListener("DOMContentLoaded", async () => {

    const supabase = window.supabaseClient;

    if (!supabase) {
        console.error("Supabase client not found.");
        return;
    }

    const form = document.getElementById("feedbackForm");
    const message = document.getElementById("feedbackMessage");

    if (!form) {
        console.error("Feedback form not found.");
        return;
    }

    /* ==========================================
       GET CURRENT USER
    ========================================== */

    const {
        data: { user },
        error: userError
    } = await supabase.auth.getUser();

    if (userError || !user) {
        message.textContent = "Please log in before submitting feedback.";
        message.style.color = "#ff6b6b";
        return;
    }

    /* ==========================================
       FORM SUBMISSION
    ========================================== */

    form.addEventListener("submit", async (event) => {

        event.preventDefault();

        message.textContent = "Submitting...";
        message.style.color = "";

        const ratingInput = document.querySelector(
            'input[name="rating"]:checked'
        );

        const rating = ratingInput
            ? Number(ratingInput.value)
            : null;

        const likedFeature =
            document.getElementById("likedFeature").value.trim();

        const improvement =
            document.getElementById("improvement").value.trim();

        const mostUsedFeature =
            document.getElementById("mostUsedFeature").value;

        const recommendation =
            document.getElementById("recommendation").value;

        const comment =
            document.getElementById("comment").value.trim();

        /* ==========================================
           VALIDATION
        ========================================== */

        if (!rating) {
            message.textContent = "Please select a rating.";
            message.style.color = "#ff6b6b";
            return;
        }

        /* ==========================================
           INSERT FEEDBACK
        ========================================== */

        const { error } = await supabase
            .from("feedback")
            .insert({
                user_id: user.id,
                rating: rating,
                liked_feature: likedFeature || null,
                improvement: improvement || null,
                most_used_feature: mostUsedFeature || null,
                recommendation: recommendation || null,
                comment: comment || null
            });

        /* ==========================================
           HANDLE ERROR
        ========================================== */

        if (error) {

            console.error("Feedback submission error:", error);

            message.textContent =
                "Unable to submit feedback. Please try again.";

            message.style.color = "#ff6b6b";

            return;
        }

        /* ==========================================
           SUCCESS
        ========================================== */

        message.textContent =
            "Thank you! Your feedback has been submitted.";

        message.style.color = "#b7ff3c";

        form.reset();

    });

});