/* =========================================================
BOOKWORM CLUB — PROFILE
Dynamic Multi-User Profile System
========================================================= */

document.addEventListener(
"DOMContentLoaded",
async function () {

    console.log(
        "Bookworm Club Profile loaded."
    );


    /* =====================================================
       SUPABASE
    ===================================================== */

    const supabaseClient =
        window.supabaseClient;


    if (!supabaseClient) {

        console.error(
            "Bookworm Club: Supabase client unavailable."
        );

        return;
    }


    /* =====================================================
       WAIT FOR AUTHENTICATION
    ===================================================== */

    if (
        window.BookwormAuth &&
        window.BookwormAuth.waitForAuth
    ) {

        const authenticated =
            await window.BookwormAuth.waitForAuth();


        if (!authenticated) {
            return;
        }

    }


    /* =====================================================
       GET CURRENT USER
    ===================================================== */

    const {
        data: {
            user
        },
        error: userError
    } =
        await supabaseClient.auth.getUser();


    if (userError) {

        console.error(
            "Bookworm Club: User error:",
            userError
        );

        return;
    }


    if (!user) {

        window.location.replace(
            "login.html"
        );

        return;
    }


    console.log(
        "Bookworm user:",
        user.id
    );


    /* =====================================================
       LOAD USER PROFILE
    ===================================================== */

    const {
        data: profile,
        error: profileError
    } =
        await supabaseClient
            .from("profiles")
            .select(
                "id, full_name, department, level, institution"
            )
            .eq(
                "id",
                user.id
            )
            .single();


    if (profileError) {

        console.error(
            "Bookworm Club: Profile load error:",
            profileError
        );

        return;
    }


    if (!profile) {

        console.warn(
            "Bookworm Club: No profile found for this user."
        );

        return;
    }


    console.log(
        "Bookworm profile loaded:",
        profile
    );


    /* =====================================================
       NORMALIZE PROFILE DATA
    ===================================================== */

    const fullName =
        profile.full_name ||
        user.email?.split("@")[0] ||
        "Student";


    const department =
        profile.department ||
        "Department not set";


    const level =
        profile.level ||
        "Level not set";


    const institution =
        profile.institution ||
        "Institution not set";


    /* =====================================================
       CREATE INITIALS
    ===================================================== */

    function getInitials(name) {

        if (!name) {
            return "?";
        }


        const parts =
            name
                .trim()
                .split(/\s+/)
                .filter(Boolean);


        if (parts.length === 1) {

            return parts[0]
                .charAt(0)
                .toUpperCase();

        }


        return (
            parts[0].charAt(0) +
            parts[parts.length - 1].charAt(0)
        ).toUpperCase();

    }


    const initials =
        getInitials(fullName);


    /* =====================================================
       GLOBAL BOOKWORM PROFILE
    ===================================================== */

    window.bookwormProfile = {

        id: profile.id,

        full_name: fullName,

        department: department,

        level: level,

        institution: institution,

        initials: initials,

        email: user.email || ""

    };


    /* =====================================================
       UPDATE USER NAMES
    ===================================================== */

    document
        .querySelectorAll(
            "[data-user-name]"
        )
        .forEach(
            function (element) {

                element.textContent =
                    fullName;

            }
        );


    /* =====================================================
       UPDATE INITIALS / AVATARS
    ===================================================== */

    document
        .querySelectorAll(
            "[data-user-initials]"
        )
        .forEach(
            function (element) {

                element.textContent =
                    initials;

            }
        );


    /* =====================================================
       UPDATE DEPARTMENT
    ===================================================== */

    document
        .querySelectorAll(
            "[data-user-department]"
        )
        .forEach(
            function (element) {

                element.textContent =
                    department;

            }
        );


    /* =====================================================
       UPDATE LEVEL
    ===================================================== */

    document
        .querySelectorAll(
            "[data-user-level]"
        )
        .forEach(
            function (element) {

                element.textContent =
                    level;

            }
        );


    /* =====================================================
       UPDATE INSTITUTION
    ===================================================== */

    document
        .querySelectorAll(
            "[data-user-institution]"
        )
        .forEach(
            function (element) {

                element.textContent =
                    institution;

            }
        );


    /* =====================================================
       EDIT PROFILE
    ===================================================== */

    const editProfileButton =
        document.getElementById(
            "editProfileButton"
        );


    if (editProfileButton) {

        editProfileButton.addEventListener(
            "click",
            async function () {

                const newName =
                    prompt(
                        "Enter your full name:",
                        fullName
                    );


                if (
                    newName === null ||
                    !newName.trim()
                ) {

                    return;

                }


                const cleanedName =
                    newName.trim();


                const {
                    error
                } =
                    await supabaseClient
                        .from("profiles")
                        .update({

                            full_name:
                                cleanedName

                        })
                        .eq(
                            "id",
                            user.id
                        );


                if (error) {

                    console.error(
                        "Bookworm Club: Profile update error:",
                        error
                    );


                    alert(
                        "Unable to update your profile."
                    );

                    return;
                }


                /* -----------------------------------------
                   Update global profile
                ----------------------------------------- */

                window.bookwormProfile.full_name =
                    cleanedName;


                window.bookwormProfile.initials =
                    getInitials(
                        cleanedName
                    );


                /* -----------------------------------------
                   Update interface immediately
                ----------------------------------------- */

                document
                    .querySelectorAll(
                        "[data-user-name]"
                    )
                    .forEach(
                        function (element) {

                            element.textContent =
                                cleanedName;

                        }
                    );


                document
                    .querySelectorAll(
                        "[data-user-initials]"
                    )
                    .forEach(
                        function (element) {

                            element.textContent =
                                window.bookwormProfile.initials;

                        }
                    );


                alert(
                    "Profile updated successfully."
                );

            }
        );

    }


    console.log(
        "Bookworm Club: Dynamic profile ready."
    );

}

);