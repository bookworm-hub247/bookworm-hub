// ==========================================
// BOOKWORM CLUB — ANNOUNCEMENTS
// ==========================================


// ------------------------------------------
// ANNOUNCEMENT DATA
// ------------------------------------------

const announcements = [
    {
        id: 1,
        title: "Welcome to the New Academic Session",
        category: "academic",
        date: "September 22, 2026",
        summary:
            "Welcome back, Bookworms. A new academic session has begun. Stay organized, attend your classes, and keep your academic goals in focus.",
        body:
            "Welcome to another academic session at Bookworm Club. This is a fresh opportunity to improve your academic performance, build meaningful connections, and develop yourself beyond the classroom. Keep track of your courses, assignments, resources, and important deadlines."
    },

    {
        id: 2,
        title: "200 Level Course Materials",
        category: "academic",
        date: "September 20, 2026",
        summary:
            "Course materials for first-semester 200-level courses will be added to the Resources section.",
        body:
            "Bookworm Club is organizing useful academic materials for 200-level students. Check the Resources section regularly for lecture notes, study guides, recommended materials, and other academic resources."
    },

    {
        id: 3,
        title: "Keep Track of Your Assignments",
        category: "deadline",
        date: "September 18, 2026",
        summary:
            "Use the Task Manager to record assignments, deadlines, projects and other academic responsibilities.",
        body:
            "Don't rely on memory alone. Add your academic responsibilities to the Bookworm Club Task Manager and update them as you make progress. Good organization can help you avoid missing important deadlines."
    },

    {
        id: 4,
        title: "Bookworm Club Marketplace Is Open",
        category: "club",
        date: "September 17, 2026",
        summary:
            "Students can now explore the Marketplace for academic books, notes and other useful student resources.",
        body:
            "The Bookworm Club Marketplace is now available. Students can browse listed academic materials and contact sellers about items they are interested in. The current version is a frontend prototype and will later be connected to a shared database."
    },

    {
        id: 5,
        title: "Bookworm Club Community Update",
        category: "club",
        date: "September 15, 2026",
        summary:
            "We are continuing to build Bookworm Club into a useful academic community for students.",
        body:
            "Bookworm Club is being developed step by step. Upcoming improvements will include better student profiles, shared announcements, improved resources, and eventually a system that allows students to access their information across devices."
    },

    {
        id: 6,
        title: "Academic Events and Opportunities",
        category: "event",
        date: "September 12, 2026",
        summary:
            "Keep an eye out for academic events, workshops, seminars and student opportunities.",
        body:
            "Important academic events and opportunities can provide valuable learning experiences outside regular lectures. Bookworm Club will use this section to highlight relevant events and opportunities for students."
    }
];


// ------------------------------------------
// DOM ELEMENTS
// ------------------------------------------

const announcementsList =
    document.getElementById("announcementsList");

const announcementSearch =
    document.getElementById("announcementSearch");

const announcementFilter =
    document.getElementById("announcementFilter");

const announcementCount =
    document.getElementById("announcementCount");

const announcementEmpty =
    document.getElementById("announcementEmpty");


// MODAL ELEMENTS

const announcementModal =
    document.getElementById("announcementModal");

const closeAnnouncementModal =
    document.getElementById("closeAnnouncementModal");

const modalAnnouncementCategory =
    document.getElementById("modalAnnouncementCategory");

const modalAnnouncementTitle =
    document.getElementById("modalAnnouncementTitle");

const modalAnnouncementDate =
    document.getElementById("modalAnnouncementDate");

const modalAnnouncementBody =
    document.getElementById("modalAnnouncementBody");


// ------------------------------------------
// CATEGORY LABELS
// ------------------------------------------

const categoryLabels = {
    academic: "Academic",
    event: "Event",
    deadline: "Deadline",
    club: "Bookworm Club"
};


// ------------------------------------------
// RENDER ANNOUNCEMENTS
// ------------------------------------------

function renderAnnouncements() {

    const searchTerm =
        announcementSearch.value
            .toLowerCase()
            .trim();

    const selectedCategory =
        announcementFilter.value;


    const filteredAnnouncements =
        announcements.filter((announcement) => {

            const matchesSearch =
                announcement.title
                    .toLowerCase()
                    .includes(searchTerm) ||

                announcement.summary
                    .toLowerCase()
                    .includes(searchTerm) ||

                announcement.body
                    .toLowerCase()
                    .includes(searchTerm);


            const matchesCategory =
                selectedCategory === "all" ||
                announcement.category === selectedCategory;


            return matchesSearch && matchesCategory;
        });


    // Clear existing announcements

    announcementsList.innerHTML = "";


    // Update count

    announcementCount.textContent =
        `${filteredAnnouncements.length} announcement${
            filteredAnnouncements.length === 1 ? "" : "s"
        }`;


    // Empty state

    if (filteredAnnouncements.length === 0) {

        announcementEmpty.hidden = false;

        return;

    }


    announcementEmpty.hidden = true;


    // Create announcement cards

    filteredAnnouncements.forEach((announcement) => {

        const card =
            document.createElement("article");

        card.className =
            "announcement-card";


        card.innerHTML = `

            <div class="announcement-card-top">

                <span class="announcement-category ${announcement.category}">
                    ${categoryLabels[announcement.category]}
                </span>

                <span class="announcement-date">
                    ${announcement.date}
                </span>

            </div>


            <h2>
                ${announcement.title}
            </h2>


            <p>
                ${announcement.summary}
            </p>


            <button
                class="read-announcement"
                data-id="${announcement.id}"
            >
                Read announcement →
            </button>

        `;


        announcementsList.appendChild(card);

    });


    // Add click events to buttons

    const readButtons =
        document.querySelectorAll(".read-announcement");


    readButtons.forEach((button) => {

        button.addEventListener("click", () => {

            const id =
                Number(button.dataset.id);

            openAnnouncement(id);

        });

    });

}


// ------------------------------------------
// OPEN ANNOUNCEMENT
// ------------------------------------------

function openAnnouncement(id) {

    const announcement =
        announcements.find(
            (item) => item.id === id
        );


    if (!announcement) {
        return;
    }


    modalAnnouncementCategory.textContent =
        categoryLabels[announcement.category];


    modalAnnouncementCategory.className =
        `announcement-modal-category ${announcement.category}`;


    modalAnnouncementTitle.textContent =
        announcement.title;


    modalAnnouncementDate.textContent =
        announcement.date;


    modalAnnouncementBody.textContent =
        announcement.body;


    announcementModal.classList.add("show");

    announcementModal.setAttribute(
        "aria-hidden",
        "false"
    );

}


// ------------------------------------------
// CLOSE MODAL
// ------------------------------------------

function closeModal() {

    announcementModal.classList.remove("show");

    announcementModal.setAttribute(
        "aria-hidden",
        "true"
    );

}


closeAnnouncementModal.addEventListener(
    "click",
    closeModal
);


// ------------------------------------------
// CLOSE WHEN CLICKING OUTSIDE MODAL
// ------------------------------------------

announcementModal.addEventListener(
    "click",
    (event) => {

        if (event.target === announcementModal) {

            closeModal();

        }

    }
);


// ------------------------------------------
// CLOSE WITH ESCAPE KEY
// ------------------------------------------

document.addEventListener(
    "keydown",
    (event) => {

        if (event.key === "Escape") {

            closeModal();

        }

    }
);


// ------------------------------------------
// SEARCH
// ------------------------------------------

announcementSearch.addEventListener(
    "input",
    renderAnnouncements
);


// ------------------------------------------
// FILTER
// ------------------------------------------

announcementFilter.addEventListener(
    "change",
    renderAnnouncements
);


// ------------------------------------------
// INITIAL LOAD
// ------------------------------------------

renderAnnouncements();