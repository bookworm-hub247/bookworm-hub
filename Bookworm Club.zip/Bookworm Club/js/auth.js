// =====================================================
// BOOKWORM CLUB — SHARED AUTHENTICATION ENGINE
// js/auth.js
// =====================================================
//
// RESPONSIBILITIES
// ----------------
// 1. Create the shared Supabase client
// 2. Keep authentication session persistent
// 3. Provide profile helper functions
// 4. Provide logout functionality
// 5. Handle global auth state
//
// IMPORTANT
// ---------
// Login is handled by:
//      js/login.js
//
// Signup is handled by:
//      js/signup.js
//
// Admin authorization is handled separately through:
//      public.admin_users
//
// profiles DOES NOT contain:
//      email
//      is_admin
//
// =====================================================


(function () {

    "use strict";


    // =================================================
    // SUPABASE CONFIGURATION
    // =================================================

    const SUPABASE_URL =
        "https://gqmabtcbrajhzvecfbcb.supabase.co";


    const SUPABASE_PUBLISHABLE_KEY =
        "sb_publishable_wSqG7Lpev5Gnvi_SAr-bhw_0K-W5RWC";


    // =================================================
    // CREATE SHARED SUPABASE CLIENT
    // =================================================
    //
    // We only create one client.
    //
    // Other Bookworm JavaScript files use:
    //
    //      window.supabaseClient
    //
    // =================================================

    if (
        !window.supabaseClient &&
        window.supabase
    ) {

        window.supabaseClient =
            window.supabase.createClient(
                SUPABASE_URL,
                SUPABASE_PUBLISHABLE_KEY,
                {
                    auth: {

                        persistSession: true,

                        autoRefreshToken: true,

                        detectSessionInUrl: true

                    }
                }
            );

    }


    // =================================================
    // CHECK SUPABASE
    // =================================================

    const supabaseClient =
        window.supabaseClient;


    if (!supabaseClient) {

        console.error(
            "BOOKWORM ERROR: Supabase client could not be created."
        );

        return;
    }


    console.log(
        "BOOKWORM: Shared Supabase client ready."
    );


    // =================================================
    // PROFILE HELPER
    // =================================================
    //
    // YOUR ACTUAL PROFILES TABLE:
    //
    // id
    // full_name
    // department
    // level
    // institution
    // created_at
    //
    // There is NO email column here.
    //
    // Email remains inside:
    //
    //      auth.users
    //
    // =================================================

    async function getCurrentProfile() {

        try {

            // -----------------------------------------
            // Get currently authenticated user
            // -----------------------------------------

            const {
                data: authData,
                error: authError
            } =
                await supabaseClient.auth.getUser();


            if (authError) {

                console.error(
                    "Bookworm auth user error:",
                    authError
                );

                return {
                    profile: null,
                    user: null,
                    error: authError
                };
            }


            const user =
                authData?.user;


            if (!user) {

                return {
                    profile: null,
                    user: null,
                    error: null
                };
            }


            // -----------------------------------------
            // Get Bookworm profile
            // -----------------------------------------

            const {
                data: profile,
                error: profileError
            } =
                await supabaseClient
                    .from("profiles")
                    .select(
                        "id, full_name, department, level, institution, created_at"
                    )
                    .eq(
                        "id",
                        user.id
                    )
                    .maybeSingle();


            if (profileError) {

                console.error(
                    "Bookworm profile error:",
                    profileError
                );

                return {
                    profile: null,
                    user: user,
                    error: profileError
                };
            }


            return {
                profile: profile,
                user: user,
                error: null
            };


        } catch (error) {

            console.error(
                "Unexpected profile lookup error:",
                error
            );

            return {
                profile: null,
                user: null,
                error: error
            };
        }
    }


    // =================================================
    // EXPOSE PROFILE HELPER
    // =================================================

    window.BookwormAuth =
        window.BookwormAuth || {};


    window.BookwormAuth.getCurrentProfile =
        getCurrentProfile;


    // =================================================
    // GET CURRENT USER
    // =================================================

    async function getCurrentUser() {

        try {

            const {
                data,
                error
            } =
                await supabaseClient.auth.getUser();


            if (error) {

                console.error(
                    "Could not get current user:",
                    error
                );

                return null;
            }


            return data?.user || null;


        } catch (error) {

            console.error(
                "Unexpected current-user error:",
                error
            );

            return null;
        }
    }


    window.BookwormAuth.getCurrentUser =
        getCurrentUser;


    // =================================================
    // GET CURRENT SESSION
    // =================================================

    async function getCurrentSession() {

        try {

            const {
                data,
                error
            } =
                await supabaseClient.auth.getSession();


            if (error) {

                console.error(
                    "Could not get Bookworm session:",
                    error
                );

                return null;
            }


            return data?.session || null;


        } catch (error) {

            console.error(
                "Unexpected session error:",
                error
            );

            return null;
        }
    }


    window.BookwormAuth.getCurrentSession =
        getCurrentSession;


    // =================================================
    // LOGOUT
    // =================================================

    async function logoutUser() {

        console.log(
            "BOOKWORM: Logging out..."
        );


        try {

            const {
                error
            } =
                await supabaseClient.auth.signOut();


            if (error) {

                console.error(
                    "Bookworm logout error:",
                    error
                );

                alert(
                    "Unable to log out: " +
                    error.message
                );

                return false;
            }


            // -----------------------------------------
            // Remove only local Bookworm indicators.
            //
            // Supabase manages the actual session.
            // -----------------------------------------

            localStorage.removeItem(
                "bookworm_logged_in"
            );

            localStorage.removeItem(
                "bookworm_user"
            );


            console.log(
                "BOOKWORM: Logout successful."
            );


            window.location.replace(
                "login.html"
            );


            return true;


        } catch (error) {

            console.error(
                "Unexpected logout error:",
                error
            );


            alert(
                "Logout failed. Please refresh the page and try again."
            );


            return false;
        }
    }


    // =================================================
    // EXPOSE LOGOUT
    // =================================================

    window.BookwormAuth.logout =
        logoutUser;


    window.logoutUser =
        logoutUser;


    // =================================================
    // CONNECT LOGOUT BUTTONS
    // =================================================
    //
    // Any element with:
    //
    //      data-logout
    //
    // automatically becomes a logout button.
    //
    // Example:
    //
    // <button data-logout>Logout</button>
    //
    // =================================================

    function connectLogoutButtons() {

        const logoutButtons =
            document.querySelectorAll(
                "[data-logout]"
            );


        logoutButtons.forEach(
            function (button) {

                // -------------------------------------
                // Prevent duplicate event listeners
                // -------------------------------------

                if (
                    button.dataset.bookwormLogoutReady ===
                    "true"
                ) {

                    return;
                }


                button.dataset.bookwormLogoutReady =
                    "true";


                button.addEventListener(
                    "click",
                    async function (event) {

                        event.preventDefault();

                        await logoutUser();

                    }
                );

            }
        );
    }


    // Run after DOM is ready.

    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            connectLogoutButtons
        );

    } else {

        connectLogoutButtons();

    }


    // =================================================
    // AUTH STATE LISTENER
    // =================================================
    //
    // This listens for Supabase authentication events.
    //
    // It DOES NOT automatically redirect users.
    //
    // Protected pages should use auth-guard.js.
    //
    // This prevents authentication redirects from
    // interfering with login/signup/recovery flows.
    // =================================================

    supabaseClient.auth.onAuthStateChange(
        function (
            event,
            session
        ) {

            console.log(
                "BOOKWORM AUTH EVENT:",
                event
            );


            // -----------------------------------------
            // SIGNED OUT
            // -----------------------------------------

            if (
                event ===
                "SIGNED_OUT"
            ) {

                localStorage.removeItem(
                    "bookworm_logged_in"
                );

                localStorage.removeItem(
                    "bookworm_user"
                );

            }


            // -----------------------------------------
            // SIGNED IN
            // -----------------------------------------

            if (
                event ===
                "SIGNED_IN"
            ) {

                localStorage.setItem(
                    "bookworm_logged_in",
                    "true"
                );

            }


            // -----------------------------------------
            // TOKEN REFRESH
            // -----------------------------------------

            if (
                event ===
                "TOKEN_REFRESHED"
            ) {

                console.log(
                    "BOOKWORM: Session token refreshed."
                );

            }

        }
    );


    // =================================================
    // GLOBAL AUTH OBJECT
    // =================================================

    window.BookwormAuth.client =
        supabaseClient;


    // =================================================
    // FINAL DEBUG MESSAGE
    // =================================================

    console.log(
        "BOOKWORM: Authentication engine loaded."
    );

})();