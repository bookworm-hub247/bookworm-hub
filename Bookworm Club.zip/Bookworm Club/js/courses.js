// ==========================================
// BOOKWORM CLUB — COURSES
// 200 LEVEL • FIRST SEMESTER
// ==========================================

"use strict";


// ==========================================
// COURSE DATABASE
// ==========================================

const courses = [

    {
        code: "GST 212",
        slug: "GST212",
        name: "Philosophy, Logic and Human Existence",
        department: "General Studies",
        units: 2,
        modules: [
            "Introduction to Philosophy",
            "Logic and Critical Thinking",
            "Human Existence",
            "Major Philosophical Questions"
        ]
    },

    {
        code: "ENT 211",
        slug: "ENT211",
        name: "Entrepreneurship and Innovation",
        department: "General Studies",
        units: 2,
        modules: [
            "Meaning and Nature of Entrepreneurship",
            "Innovation, Creativity and Opportunity Recognition",
            "Business Planning and Enterprise Development",
            "Entrepreneurial Skills, Ethics and Sustainability"
        ]
    },

    {
        code: "EDU 201",
        slug: "EDU201",
        name: "Curriculum, Curriculum Delivery and General Teaching Methods",
        department: "Education",
        units: 2,
        modules: [
            "Meaning, Nature and Scope of Curriculum",
            "Curriculum Development and Design",
            "Curriculum Delivery and Teaching Methods",
            "Lesson Planning, Classroom Management and Evaluation"
        ]
    },

    {
        code: "EDU 211",
        slug: "UNIBENEDU211",
        name: "Developmental Psychology",
        department: "Education",
        units: 2,
        modules: [
            "Introduction to Human Development",
            "Cognitive Development",
            "Social and Emotional Development",
            "Development and Classroom Practice"
        ]
    },

    {
        code: "EDU 212",
        slug: "UNIBENEDU212",
        name: "Philosophy of Education",
        department: "Education",
        units: 2,
        modules: [
            "Meaning, Nature and Scope of Philosophy of Education",
            "Knowledge, Values and Aims of Education",
            "Major Philosophies and Educational Implications",
            "Teacher, Learner, Society and Education"
        ]
    },

    {
        code: "ENG 201",
        slug: "ENG201",
        name: "An Introduction to Morphology and Syntax",
        department: "English",
        units: 2,
        modules: [
            "Introduction to Morphology",
            "Morpheme Classification and Word Formation",
            "Introduction to Syntax",
            "Sentence Structure and Syntactic Analysis"
        ]
    },

    {
        code: "ENG 203",
        slug: "ENG203",
        name: "Introduction to General Phonetics and Phonology I",
        department: "English",
        units: 2,
        modules: [
            "Foundations of Phonetics",
            "Consonants: Place, Manner and Voicing",
            "Vowels, Diphthongs and Syllable Structure",
            "Phonology, Phonemes and Phonetic Transcription"
        ]
    },

    {
        code: "ENG 205",
        slug: "ENG205",
        name: "Advanced English Composition I",
        department: "English",
        units: 2,
        modules: [
            "Language: Meaning, Nature and Functions",
            "Language Structure and Levels of Analysis",
            "English as a Global Language",
            "Language, Society and Communication"
        ]
    },

    {
        code: "ENL 210",
        slug: "UNIBENENL210",
        name: "A Survey of English Literature from Anglo-Saxon to the Elizabethan Period",
        department: "English / Literature",
        units: 2,
        modules: [
            "Introduction to English Literature",
            "Anglo-Saxon Literature",
            "Middle English Literature",
            "Elizabethan Literature"
        ]
    },

    {
        code: "LAS 244",
        slug: "LAS244",
        name: "Method I – Teaching Grammar, Lexis & Oracy Skills",
        department: "Language Education",
        units: 2,
        modules: [
            "Meaning, Types and Functions of Libraries",
            "Information Sources and Resources",
            "Information Literacy and Research Skills",
            "Digital Information, Library Services and Academic Success"
        ]
    }

];


// ==========================================
// RENDER COURSES
// ==========================================

function renderCourses(courseData) {

    const container = document.getElementById("allCourses");

    if (!container) {
        return;
    }

    container.innerHTML = "";

    if (courseData.length === 0) {

        container.innerHTML = `
            <div class="course-empty">
                <span>COURSE SEARCH</span>

                <h2>No courses found.</h2>

                <p>
                    Try another course code or keyword.
                </p>
            </div>
        `;

        return;
    }

    courseData.forEach(function(course) {

        const card = document.createElement("article");

        card.className = "course-card";

        const isPremium =
            window.BookwormPremium &&
            BookwormPremium.isPremiumCourse(course.slug);

        const isFree =
            window.BookwormPremium &&
            BookwormPremium.isFreeCourse(course.slug);

        const isUnlocked =
            window.BookwormPremium?.isPremium() &&
            isPremium;

        let accessLabel = "AVAILABLE";
        let accessClass = "course-access-free";

        if (isPremium && !isUnlocked) {

            accessLabel = "PREMIUM";
            accessClass = "course-access-premium";

        }

        if (isUnlocked) {

            accessLabel = "PREMIUM • UNLOCKED";
            accessClass = "course-access-unlocked";

        }

        if (isFree) {

            accessLabel = "FREE";
            accessClass = "course-access-free";

        }

        card.innerHTML = `
            <span class="course-card-code">
                ${escapeHTML(course.code)}
            </span>

            <div class="course-card-main">

                <h3 class="course-card-title">
                    ${escapeHTML(course.name)}
                </h3>

                <p class="course-card-meta">
                    ${escapeHTML(course.department)}
                    • ${course.units} Units
                </p>

            </div>

            <div class="course-card-content">

                <strong class="${accessClass}">
                    ${accessLabel}
                </strong>

                <span>
                    ${
                        isPremium && !isUnlocked
                            ? "First topic free • More topics locked"
                            : "Course content available"
                    }
                </span>

            </div>

            <a
                href="course.html?course=${encodeURIComponent(course.slug)}"
                class="course-card-action"
                aria-label="Open ${escapeHTML(course.code)}"
            >

                <span>
                    ${
                        isPremium && !isUnlocked
                            ? "Preview"
                            : "Open Course"
                    }
                </span>

                <span class="course-card-arrow">
                    →
                </span>

            </a>
        `;

        container.appendChild(card);

    });

}


// ==========================================
// COURSE SEARCH
// ==========================================

const searchInput = document.getElementById("courseSearch");

if (searchInput) {

    searchInput.addEventListener("input", function() {

        const searchTerm = searchInput.value
            .toLowerCase()
            .trim();

        const filteredCourses = courses.filter(function(course) {

            return (
                course.code.toLowerCase().includes(searchTerm) ||
                course.name.toLowerCase().includes(searchTerm) ||
                course.department.toLowerCase().includes(searchTerm) ||
                course.slug.toLowerCase().includes(searchTerm) ||
                course.modules.some(function(module) {
                    return module.toLowerCase().includes(searchTerm);
                })
            );

        });

        renderCourses(filteredCourses);

    });

}


// ==========================================
// INITIAL RENDER
// ==========================================

async function initializeCourses() {

    if (window.BookwormPremium?.ready) {
        await BookwormPremium.ready;
    }

    renderCourses(courses);

}

initializeCourses();


// ==========================================
// HTML ESCAPING
// ==========================================

function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


// ==========================================
// DEBUG
// ==========================================

console.log(
    "Bookworm Courses initialized:",
    courses.length,
    "courses"
);