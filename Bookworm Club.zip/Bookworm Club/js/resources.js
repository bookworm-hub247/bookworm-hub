// ==========================================
// BOOKWORM CLUB — RESOURCE LIBRARY
// COURSE-AWARE RESOURCE SYSTEM
// ==========================================

"use strict";


// ==========================================
// RESOURCE DATA
// ==========================================

const resources = [

    {
        title: "Introduction to Morphology",
        type: "course-note",
        typeName: "COURSE NOTE",
        course: "ENG 201",
        description:
            "Key concepts covering morphemes, word structure and morphological analysis."
    },

    {
        title: "General Phonetics Revision Guide",
        type: "revision-guide",
        typeName: "REVISION GUIDE",
        course: "ENG 203",
        description:
            "A structured revision guide covering important phonetics and phonology concepts."
    },

    {
        title: "Philosophy of Education",
        type: "study-guide",
        typeName: "STUDY GUIDE",
        course: "UNIBENEDU 212",
        description:
            "Study material covering major concepts in philosophy of education."
    },

    {
        title: "Developmental Psychology Notes",
        type: "course-note",
        typeName: "COURSE NOTE",
        course: "UNIBENEDU 211",
        description:
            "Introduction to developmental psychology and major stages of human development."
    },

    {
        title: "Entrepreneurship Revision Guide",
        type: "revision-guide",
        typeName: "REVISION GUIDE",
        course: "ENT 211",
        description:
            "Important concepts related to entrepreneurship, innovation and business development."
    },

    {
        title: "Logic and Human Existence",
        type: "study-guide",
        typeName: "STUDY GUIDE",
        course: "GST 212",
        description:
            "A study guide for philosophical reasoning, logic and questions of human existence."
    }

];


// ==========================================
// ELEMENTS
// ==========================================

const resourceLibrary =
    document.getElementById(
        "resourceLibrary"
    );


const resourceSearch =
    document.getElementById(
        "resourceSearch"
    );


const resourceFilter =
    document.getElementById(
        "resourceFilter"
    );


// ==========================================
// URL COURSE
// ==========================================

const resourceURLParams =
    new URLSearchParams(
        window.location.search
    );


const courseFromURL =
    resourceURLParams.get("course");


// ==========================================
// SELECTED COURSE
// ==========================================

let selectedCourse =
    courseFromURL || "all";


// ==========================================
// NORMALIZE COURSE CODE
// ==========================================
// Allows:
//
// ENG201
// ENG 201
//
// to match each other.

function normalizeCourseCode(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }

    return String(value)
        .trim()
        .toUpperCase()
        .replace(/\s+/g, "");

}


// ==========================================
// RENDER RESOURCES
// ==========================================

function renderResources(resourceData) {

    if (!resourceLibrary) {
        return;
    }


    resourceLibrary.innerHTML = "";


    if (
        resourceData.length === 0
    ) {

        resourceLibrary.innerHTML = `
            <div class="empty-state">

                <h3>
                    No resources found
                </h3>

                <p>
                    There are currently no resources
                    matching your selected filters.
                </p>

            </div>
        `;

        return;
    }


    resourceData.forEach(
        function(resource) {

            const card =
                document.createElement(
                    "article"
                );


            card.className =
                "resource-library-card";


            card.innerHTML = `

                <span class="resource-type">

                    ${escapeHTML(
                        resource.typeName
                    )}

                </span>


                <h3>

                    ${escapeHTML(
                        resource.title
                    )}

                </h3>


                <p class="resource-course">

                    ${escapeHTML(
                        resource.course
                    )}

                </p>


                <p class="resource-description">

                    ${escapeHTML(
                        resource.description
                    )}

                </p>


                <button
                    type="button"
                    class="resource-button"
                    disabled
                >
                    Coming Soon
                </button>

            `;


            resourceLibrary.appendChild(
                card
            );

        }
    );

}


// ==========================================
// FILTER RESOURCES
// ==========================================

function filterResources() {

    const searchTerm =
        resourceSearch
            ? resourceSearch.value
                .toLowerCase()
                .trim()
            : "";


    const selectedType =
        resourceFilter
            ? resourceFilter.value
            : "all";


    const normalizedSelectedCourse =
        normalizeCourseCode(
            selectedCourse
        );


    const filtered =
        resources.filter(
            function(resource) {

                const resourceTitle =
                    resource.title
                        .toLowerCase();


                const resourceCourse =
                    resource.course
                        .toLowerCase();


                const resourceDescription =
                    resource.description
                        .toLowerCase();


                const matchesSearch =
                    resourceTitle.includes(
                        searchTerm
                    )
                    ||
                    resourceCourse.includes(
                        searchTerm
                    )
                    ||
                    resourceDescription.includes(
                        searchTerm
                    );


                const matchesType =
                    selectedType === "all"
                    ||
                    resource.type ===
                        selectedType;


                const matchesCourse =
                    selectedCourse === "all"
                    ||
                    normalizeCourseCode(
                        resource.course
                    ) ===
                        normalizedSelectedCourse;


                return (
                    matchesSearch &&
                    matchesType &&
                    matchesCourse
                );

            }
        );


    renderResources(
        filtered
    );

}


// ==========================================
// SEARCH LISTENER
// ==========================================

if (resourceSearch) {

    resourceSearch.addEventListener(
        "input",
        filterResources
    );

}


// ==========================================
// TYPE FILTER LISTENER
// ==========================================

if (resourceFilter) {

    resourceFilter.addEventListener(
        "change",
        filterResources
    );

}


// ==========================================
// INITIALIZE COURSE
// ==========================================

function initializeCourseFilter() {

    if (!courseFromURL) {

        selectedCourse =
            "all";

        return;

    }


    selectedCourse =
        courseFromURL;

}


// ==========================================
// HTML SECURITY
// ==========================================

function escapeHTML(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }


    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// ==========================================
// START
// ==========================================

initializeCourseFilter();

filterResources();


console.log(
    "Bookworm Resource Library initialized."
);

console.log(
    "Selected course:",
    selectedCourse
);