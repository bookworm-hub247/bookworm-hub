/* =========================================================
   BOOKWORM CLUB — ADMIN PREMIUM ACCESS MANAGER
   Uses the actual profiles table structure:

   profiles
   ├── id
   ├── full_name
   ├── department
   ├── level
   ├── institution
   └── created_at

   premium_entitlements
   ├── id
   ├── user_id
   ├── product_code
   ├── amount_paid
   ├── approved_at
   ├── approved_by
   ├── created_at
   └── updated_at
========================================================= */

(function () {
    "use strict";

    let supabase = null;
    let currentAdmin = null;
    let students = [];
    let selectedStudent = null;

    const PRODUCT_CODE = "200L_FIRST_SEMESTER_PREMIUM";
    const PREMIUM_PRICE = 500;


    /* =====================================================
       WAIT FOR SUPABASE
    ===================================================== */

    function waitForSupabase() {

        if (!window.supabaseClient) {
            setTimeout(waitForSupabase, 100);
            return;
        }

        supabase = window.supabaseClient;

        initializeAdminPage();
    }


    /* =====================================================
       INITIALIZE
    ===================================================== */

    async function initializeAdminPage() {

        try {

            setStatus("Verifying administrator...", "loading");

            const {
                data: {
                    user
                },
                error: authError
            } = await supabase.auth.getUser();


            if (authError) {

                console.error("Authentication error:", authError);

                redirectToLogin();

                return;
            }


            if (!user) {

                redirectToLogin();

                return;
            }


            currentAdmin = user;


            /* ---------------------------------------------
               VERIFY ADMIN
            --------------------------------------------- */

            const {
                data: adminRecord,
                error: adminError
            } = await supabase
                .from("admin_users")
                .select("user_id")
                .eq("user_id", user.id)
                .maybeSingle();


            if (adminError) {

                console.error(
                    "Admin verification error:",
                    adminError
                );

                showError(
                    "Could not verify administrator access."
                );

                return;
            }


            if (!adminRecord) {

                alert(
                    "You do not have administrator access."
                );

                window.location.replace("dashboard.html");

                return;
            }


            console.log(
                "Bookworm Premium Admin verified:",
                user.id
            );


            setStatus(
                "Administrator verified",
                "success"
            );


            setupInterface();

            await loadStudents();

            await loadPremiumStudents();


        } catch (error) {

            console.error(
                "Premium admin initialization error:",
                error
            );

            showError(
                "Something went wrong while loading Premium Access."
            );
        }
    }


    /* =====================================================
       LOAD ALL STUDENTS
    ===================================================== */

    async function loadStudents() {

        setLoadingState(
            "Loading students..."
        );


        const {
            data,
            error
        } = await supabase
            .from("profiles")
            .select(`
                id,
                full_name,
                department,
                level,
                institution,
                created_at
            `)
            .order(
                "created_at",
                {
                    ascending: false
                }
            );


        if (error) {

            console.error(
                "Student loading error:",
                error
            );

            showStudentError(
                "Unable to load students."
            );

            return;
        }


        students = data || [];


        console.log(
            `Loaded ${students.length} students.`
        );


        updateStudentCount();

        renderStudents(students);
    }


    /* =====================================================
       LOAD PREMIUM STUDENTS
    ===================================================== */

    async function loadPremiumStudents() {

        const {
            data,
            error
        } = await supabase
            .from("premium_entitlements")
            .select(`
                id,
                user_id,
                product_code,
                amount_paid,
                approved_at,
                approved_by,
                created_at,
                updated_at
            `)
            .eq(
                "product_code",
                PRODUCT_CODE
            )
            .order(
                "created_at",
                {
                    ascending: false
                }
            );


        if (error) {

            console.error(
                "Premium entitlement loading error:",
                error
            );

            return;
        }


        const premiumStudents = data || [];


        updatePremiumCount(
            premiumStudents.length
        );


        renderPremiumStudents(
            premiumStudents
        );
    }


    /* =====================================================
       SETUP INTERFACE
    ===================================================== */

    function setupInterface() {

        const searchInput =
            document.getElementById(
                "studentSearch"
            );


        if (searchInput) {

            searchInput.addEventListener(
                "input",
                function () {

                    const search =
                        this.value
                            .trim()
                            .toLowerCase();


                    if (!search) {

                        renderStudents(
                            students
                        );

                        return;
                    }


                    const filtered =
                        students.filter(
                            function (student) {

                                return (

                                    String(
                                        student.full_name || ""
                                    )
                                    .toLowerCase()
                                    .includes(search)

                                    ||

                                    String(
                                        student.department || ""
                                    )
                                    .toLowerCase()
                                    .includes(search)

                                    ||

                                    String(
                                        student.level || ""
                                    )
                                    .toLowerCase()
                                    .includes(search)

                                    ||

                                    String(
                                        student.institution || ""
                                    )
                                    .toLowerCase()
                                    .includes(search)

                                );
                            }
                        );


                    renderStudents(
                        filtered
                    );
                }
            );
        }


        const refreshButton =
            document.getElementById(
                "refreshStudents"
            );


        if (refreshButton) {

            refreshButton.addEventListener(
                "click",
                async function () {

                    await loadStudents();

                    await loadPremiumStudents();
                }
            );
        }


        const grantButton =
            document.getElementById(
                "grantPremium"
            );


        if (grantButton) {

            grantButton.addEventListener(
                "click",
                grantPremium
            );
        }


        const cancelButton =
            document.getElementById(
                "cancelPremium"
            );


        if (cancelButton) {

            cancelButton.addEventListener(
                "click",
                clearSelectedStudent
            );
        }
    }


    /* =====================================================
       RENDER STUDENTS
    ===================================================== */

    function renderStudents(list) {

        const container =
            document.getElementById(
                "studentResults"
            );


        if (!container) return;


        container.innerHTML = "";


        if (!list || list.length === 0) {

            container.innerHTML = `
                <div class="premium-empty">
                    <div class="premium-empty-icon">
                        —
                    </div>

                    <h3>No students found</h3>

                    <p>
                        Try searching by the student's
                        name, department, level, or institution.
                    </p>
                </div>
            `;

            return;
        }


        list.forEach(
            function (student) {

                const card =
                    document.createElement("button");


                card.type = "button";

                card.className =
                    "premium-student-card";


                card.innerHTML = `

                    <div class="premium-student-avatar">
                        ${getInitials(student.full_name)}
                    </div>

                    <div class="premium-student-info">

                        <strong>
                            ${escapeHTML(student.full_name)}
                        </strong>

                        <span>
                            ${escapeHTML(student.department)}
                        </span>

                        <small>
                            ${escapeHTML(student.level)}
                            •
                            ${escapeHTML(student.institution)}
                        </small>

                    </div>

                    <div class="premium-student-arrow">
                        →
                    </div>
                `;


                card.addEventListener(
                    "click",
                    function () {

                        selectStudent(student);
                    }
                );


                container.appendChild(card);
            }
        );
    }


    /* =====================================================
       SELECT STUDENT
    ===================================================== */

    async function selectStudent(student) {

        selectedStudent = student;


        const panel =
            document.getElementById(
                "selectedStudent"
            );


        if (!panel) return;


        panel.innerHTML = `

            <div class="selected-student-header">

                <div class="premium-student-avatar large">
                    ${getInitials(student.full_name)}
                </div>

                <div>

                    <h3>
                        ${escapeHTML(student.full_name)}
                    </h3>

                    <p>
                        ${escapeHTML(student.department)}
                    </p>

                </div>

            </div>

            <div class="selected-student-details">

                <div>
                    <span>Level</span>
                    <strong>
                        ${escapeHTML(student.level)}
                    </strong>
                </div>

                <div>
                    <span>Institution</span>
                    <strong>
                        ${escapeHTML(student.institution)}
                    </strong>
                </div>

                <div>
                    <span>Student ID</span>
                    <strong>
                        ${escapeHTML(student.id)}
                    </strong>
                </div>

            </div>

            <div id="premiumStudentStatus">
                Checking premium status...
            </div>

            <div class="selected-student-actions">

                <button
                    type="button"
                    id="grantPremium"
                    class="premium-primary-button"
                >
                    Grant ₦500 Premium Access
                </button>

                <button
                    type="button"
                    id="cancelPremium"
                    class="premium-secondary-button"
                >
                    Cancel
                </button>

            </div>
        `;


        panel.classList.add(
            "active"
        );


        await checkStudentPremium(
            student.id
        );


        const grantButton =
            document.getElementById(
                "grantPremium"
            );


        const cancelButton =
            document.getElementById(
                "cancelPremium"
            );


        if (grantButton) {

            grantButton.addEventListener(
                "click",
                grantPremium
            );
        }


        if (cancelButton) {

            cancelButton.addEventListener(
                "click",
                clearSelectedStudent
            );
        }
    }


    /* =====================================================
       CHECK PREMIUM
    ===================================================== */

    async function checkStudentPremium(
        studentId
    ) {

        const status =
            document.getElementById(
                "premiumStudentStatus"
            );


        const {
            data,
            error
        } = await supabase
            .from("premium_entitlements")
            .select(`
                id,
                user_id,
                product_code,
                amount_paid,
                approved_at,
                approved_by,
                created_at
            `)
            .eq(
                "user_id",
                studentId
            )
            .eq(
                "product_code",
                PRODUCT_CODE
            )
            .maybeSingle();


        if (error) {

            console.error(
                "Premium status error:",
                error
            );


            if (status) {

                status.innerHTML = `
                    <div class="premium-status warning">
                        Unable to check premium status.
                    </div>
                `;
            }

            return;
        }


        if (data) {

            if (status) {

                status.innerHTML = `
                    <div class="premium-status active">
                        ✓ Premium access already granted
                    </div>
                `;
            }


            const grantButton =
                document.getElementById(
                    "grantPremium"
                );


            if (grantButton) {

                grantButton.disabled = true;

                grantButton.textContent =
                    "Premium Already Active";
            }


            return;
        }


        if (status) {

            status.innerHTML = `
                <div class="premium-status inactive">
                    Premium access has not been granted.
                </div>
            `;
        }
    }


    /* =====================================================
       GRANT PREMIUM
    ===================================================== */

    async function grantPremium() {

        if (!selectedStudent) {

            alert(
                "Please select a student first."
            );

            return;
        }


        const confirmed =
            confirm(
                `Grant ₦500 Premium Access to ${selectedStudent.full_name}?`
            );


        if (!confirmed) return;


        const button =
            document.getElementById(
                "grantPremium"
            );


        if (button) {

            button.disabled = true;

            button.textContent =
                "Granting access...";
        }


        try {

            /* ---------------------------------------------
               DOUBLE-CHECK EXISTING ENTITLEMENT
            --------------------------------------------- */

            const {
                data: existing,
                error: existingError
            } = await supabase
                .from("premium_entitlements")
                .select("id")
                .eq(
                    "user_id",
                    selectedStudent.id
                )
                .eq(
                    "product_code",
                    PRODUCT_CODE
                )
                .maybeSingle();


            if (existingError) {

                throw existingError;
            }


            if (existing) {

                alert(
                    "This student already has Premium Access."
                );

                await checkStudentPremium(
                    selectedStudent.id
                );

                return;
            }


            /* ---------------------------------------------
               CREATE ENTITLEMENT
            --------------------------------------------- */

            const {
                data,
                error
            } = await supabase
                .from("premium_entitlements")
                .insert({
                    user_id: selectedStudent.id,
                    product_code: PRODUCT_CODE,
                    amount_paid: PREMIUM_PRICE,
                    approved_at:
                        new Date().toISOString(),
                    approved_by:
                        currentAdmin.id
                })
                .select()
                .single();


            if (error) {

                console.error(
                    "Premium grant error:",
                    error
                );

                throw error;
            }


            console.log(
                "Premium entitlement created:",
                data
            );


            alert(
                `Premium Access successfully granted to ${selectedStudent.full_name}.`
            );


            await checkStudentPremium(
                selectedStudent.id
            );


            await loadPremiumStudents();


        } catch (error) {

            console.error(
                "Grant Premium failed:",
                error
            );


            alert(
                "Premium access could not be granted.\n\n" +
                "Error: " +
                (error.message || "Unknown error")
            );


            if (button) {

                button.disabled = false;

                button.textContent =
                    "Grant ₦500 Premium Access";
            }
        }
    }


    /* =====================================================
       CLEAR SELECTED STUDENT
    ===================================================== */

    function clearSelectedStudent() {

        selectedStudent = null;


        const panel =
            document.getElementById(
                "selectedStudent"
            );


        if (panel) {

            panel.classList.remove(
                "active"
            );

            panel.innerHTML = `
                <div class="premium-selection-empty">
                    <span>+</span>
                    <h3>Select a student</h3>
                    <p>
                        Choose a student from the list
                        to manage Premium Access.
                    </p>
                </div>
            `;
        }
    }


    /* =====================================================
       RENDER PREMIUM STUDENTS
    ===================================================== */

    function renderPremiumStudents(
        entitlements
    ) {

        const container =
            document.getElementById(
                "premiumStudents"
            );


        if (!container) return;


        container.innerHTML = "";


        if (
            !entitlements ||
            entitlements.length === 0
        ) {

            container.innerHTML = `
                <div class="premium-empty">
                    <h3>No Premium Students Yet</h3>

                    <p>
                        Students granted Premium Access
                        will appear here.
                    </p>
                </div>
            `;

            return;
        }


        entitlements.forEach(
            function (entitlement) {

                const student =
                    students.find(
                        function (item) {

                            return (
                                item.id ===
                                entitlement.user_id
                            );
                        }
                    );


                const card =
                    document.createElement("div");


                card.className =
                    "premium-active-card";


                card.innerHTML = `

                    <div class="premium-student-avatar">
                        ${
                            getInitials(
                                student
                                    ? student.full_name
                                    : "Student"
                            )
                        }
                    </div>

                    <div class="premium-active-info">

                        <strong>
                            ${
                                escapeHTML(
                                    student
                                        ? student.full_name
                                        : "Student"
                                )
                            }
                        </strong>

                        <span>
                            ${
                                escapeHTML(
                                    student
                                        ? student.department
                                        : "Unknown department"
                                )
                            }
                        </span>

                    </div>

                    <div class="premium-active-badge">
                        PREMIUM
                    </div>
                `;


                container.appendChild(
                    card
                );
            }
        );
    }


    /* =====================================================
       COUNTERS
    ===================================================== */

    function updateStudentCount() {

        const element =
            document.getElementById(
                "studentCount"
            );


        if (element) {

            element.textContent =
                students.length;
        }
    }


    function updatePremiumCount(
        count
    ) {

        const element =
            document.getElementById(
                "premiumCount"
            );


        if (element) {

            element.textContent =
                count;
        }
    }


    /* =====================================================
       STATUS
    ===================================================== */

    function setStatus(
        message,
        type
    ) {

        const element =
            document.getElementById(
                "adminVerification"
            );


        if (!element) return;


        element.textContent =
            message;


        element.className =
            `admin-verification ${type}`;
    }


    function setLoadingState(
        message
    ) {

        const container =
            document.getElementById(
                "studentResults"
            );


        if (!container) return;


        container.innerHTML = `
            <div class="premium-loading">
                <div class="premium-spinner"></div>

                <p>
                    ${escapeHTML(message)}
                </p>
            </div>
        `;
    }


    function showStudentError(
        message
    ) {

        const container =
            document.getElementById(
                "studentResults"
            );


        if (!container) return;


        container.innerHTML = `
            <div class="premium-empty error">
                <h3>
                    ${escapeHTML(message)}
                </h3>

                <p>
                    Check the browser console
                    for the Supabase error.
                </p>
            </div>
        `;
    }


    function showError(
        message
    ) {

        setStatus(
            message,
            "error"
        );
    }


    /* =====================================================
       HELPERS
    ===================================================== */

    function getInitials(
        name
    ) {

        const parts =
            String(name || "")
                .trim()
                .split(/\s+/)
                .filter(Boolean);


        if (!parts.length) {
            return "?";
        }


        if (parts.length === 1) {

            return parts[0]
                .substring(0, 2)
                .toUpperCase();
        }


        return (
            parts[0][0] +
            parts[parts.length - 1][0]
        ).toUpperCase();
    }


    function escapeHTML(
        value
    ) {

        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }


    function redirectToLogin() {

        window.location.replace(
            "login.html"
        );
    }


    /* =====================================================
       START
    ===================================================== */

    waitForSupabase();

})();