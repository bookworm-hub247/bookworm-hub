// =====================================================
// BOOKWORM CLUB — SIGNUP
// js/signup.js
// =====================================================
//
// Handles:
// 1. Student registration
// 2. Supabase Auth account creation
// 3. Passing profile information through metadata
// 4. Handling email confirmation
// 5. Preventing duplicate submissions
//
// ACTUAL profiles TABLE:
//
// id
// full_name
// department
// level
// institution
// created_at
//
// Email is handled by Supabase Auth.
// Email is NOT inserted into profiles.
//
// Admin access is separate through:
// admin_users.user_id
// =====================================================


(function () {

    "use strict";


    // =================================================
    // ELEMENTS
    // =================================================

    const signupForm =
        document.getElementById("signupForm");


    const nameInput =
        document.getElementById("signupName");


    const departmentInput =
        document.getElementById("signupDepartment");


    const levelInput =
        document.getElementById("signupLevel");


    const institutionInput =
        document.getElementById("signupInstitution");


    const emailInput =
        document.getElementById("signupEmail");


    const passwordInput =
        document.getElementById("signupPassword");


    const confirmPasswordInput =
        document.getElementById(
            "signupConfirmPassword"
        );


    const signupButton =
        document.getElementById("signupButton");


    const signupMessage =
        document.getElementById(
            "signupMessage"
        );


    // =================================================
    // SUPABASE CLIENT
    // =================================================

    const supabaseClient =
        window.supabaseClient;


    if (!supabaseClient) {

        console.error(
            "BOOKWORM ERROR: Supabase client is unavailable."
        );


        showMessage(
            "Authentication system could not load. Please refresh the page.",
            "error"
        );


        if (signupButton) {
            signupButton.disabled = true;
        }


        return;
    }


    // =================================================
    // MESSAGE
    // =================================================

    function showMessage(
        message,
        type = ""
    ) {

        if (!signupMessage) {
            return;
        }


        signupMessage.textContent =
            message;


        signupMessage.classList.remove(
            "success",
            "error"
        );


        if (type) {

            signupMessage.classList.add(
                type
            );

        }

    }


    // =================================================
    // LOADING STATE
    // =================================================

    function setLoading(
        loading
    ) {

        if (!signupButton) {
            return;
        }


        signupButton.disabled =
            loading;


        signupButton.textContent =
            loading
                ? "CREATING ACCOUNT..."
                : "CREATE ACCOUNT";

    }


    // =================================================
    // CLEAN TEXT
    // =================================================

    function cleanText(
        value
    ) {

        return String(
            value || ""
        )
            .trim()
            .replace(/\s+/g, " ");

    }


    // =================================================
    // EMAIL NORMALIZATION
    // =================================================

    function cleanEmail(
        value
    ) {

        return String(
            value || ""
        )
            .trim()
            .toLowerCase();

    }


    // =================================================
    // PASSWORD VALIDATION
    // =================================================

    function validatePassword(
        password
    ) {

        if (!password) {

            return {
                valid: false,
                message: "Please create a password."
            };

        }


        if (password.length < 8) {

            return {
                valid: false,
                message:
                    "Your password must contain at least 8 characters."
            };

        }


        if (password.length > 72) {

            return {
                valid: false,
                message:
                    "Your password is too long."
            };

        }


        return {
            valid: true,
            message: ""
        };

    }


    // =================================================
    // FORM VALIDATION
    // =================================================

    function validateForm() {

        const fullName =
            cleanText(
                nameInput?.value
            );


        const department =
            cleanText(
                departmentInput?.value
            );


        const level =
            cleanText(
                levelInput?.value
            );


        const institution =
            cleanText(
                institutionInput?.value
            );


        const email =
            cleanEmail(
                emailInput?.value
            );


        const password =
            passwordInput?.value || "";


        const confirmPassword =
            confirmPasswordInput?.value || "";


        // ---------------------------------------------
        // FULL NAME
        // ---------------------------------------------

        if (!fullName) {

            showMessage(
                "Please enter your full name.",
                "error"
            );


            nameInput?.focus();

            return null;
        }


        if (fullName.length < 2) {

            showMessage(
                "Please enter a valid full name.",
                "error"
            );


            nameInput?.focus();

            return null;
        }


        // ---------------------------------------------
        // DEPARTMENT
        // ---------------------------------------------

        if (!department) {

            showMessage(
                "Please enter your department.",
                "error"
            );


            departmentInput?.focus();

            return null;
        }


        // ---------------------------------------------
        // LEVEL
        // ---------------------------------------------

        if (!level) {

            showMessage(
                "Please select your level.",
                "error"
            );


            levelInput?.focus();

            return null;
        }


        // ---------------------------------------------
        // INSTITUTION
        // ---------------------------------------------

        if (!institution) {

            showMessage(
                "Please enter your institution.",
                "error"
            );


            institutionInput?.focus();

            return null;
        }


        // ---------------------------------------------
        // EMAIL
        // ---------------------------------------------

        if (!email) {

            showMessage(
                "Please enter your email address.",
                "error"
            );


            emailInput?.focus();

            return null;
        }


        // Basic email format check.

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        if (!emailPattern.test(email)) {

            showMessage(
                "Please enter a valid email address.",
                "error"
            );


            emailInput?.focus();

            return null;
        }


        // ---------------------------------------------
        // PASSWORD
        // ---------------------------------------------

        const passwordResult =
            validatePassword(
                password
            );


        if (!passwordResult.valid) {

            showMessage(
                passwordResult.message,
                "error"
            );


            passwordInput?.focus();

            return null;
        }


        // ---------------------------------------------
        // CONFIRM PASSWORD
        // ---------------------------------------------

        if (!confirmPassword) {

            showMessage(
                "Please confirm your password.",
                "error"
            );


            confirmPasswordInput?.focus();

            return null;
        }


        if (
            password !==
            confirmPassword
        ) {

            showMessage(
                "Your passwords do not match.",
                "error"
            );


            confirmPasswordInput?.focus();

            return null;
        }


        // ---------------------------------------------
        // RETURN CLEAN DATA
        // ---------------------------------------------

        return {

            fullName,
            department,
            level,
            institution,
            email,
            password

        };

    }


    // =================================================
    // CREATE ACCOUNT
    // =================================================

    async function createAccount() {

        const formData =
            validateForm();


        if (!formData) {
            return;
        }


        setLoading(true);


        showMessage(
            "Creating your Bookworm account..."
        );


        try {

            // =========================================
            // SUPABASE SIGNUP
            // =========================================
            //
            // IMPORTANT:
            //
            // Email/password go to Supabase Auth.
            //
            // Profile information goes into
            // user_metadata.
            //
            // Our database trigger can then create:
            //
            // profiles.id
            // profiles.full_name
            // profiles.department
            // profiles.level
            // profiles.institution
            //
            // =========================================

            const {
                data,
                error
            } =
                await supabaseClient.auth.signUp({

                    email:
                        formData.email,

                    password:
                        formData.password,

                    options: {

                        data: {

                            full_name:
                                formData.fullName,

                            department:
                                formData.department,

                            level:
                                formData.level,

                            institution:
                                formData.institution

                        }

                    }

                });


            // =========================================
            // SIGNUP ERROR
            // =========================================

            if (error) {

                console.error(
                    "BOOKWORM SIGNUP ERROR:",
                    error
                );


                let message =
                    error.message ||
                    "Unable to create your account.";


                const lowerMessage =
                    message.toLowerCase();


                if (
                    lowerMessage.includes(
                        "user already registered"
                    )
                ) {

                    message =
                        "An account with this email already exists. Please sign in instead.";

                }


                if (
                    lowerMessage.includes(
                        "password should be at least"
                    )
                ) {

                    message =
                        "Your password is too short.";

                }


                if (
                    lowerMessage.includes(
                        "invalid email"
                    )
                ) {

                    message =
                        "Please enter a valid email address.";

                }


                showMessage(
                    message,
                    "error"
                );


                setLoading(false);

                return;
            }


            // =========================================
            // USER CHECK
            // =========================================

            const user =
                data?.user;


            if (!user) {

                throw new Error(
                    "Account creation completed, but Supabase did not return a user."
                );

            }


            console.log(
                "BOOKWORM ACCOUNT CREATED:",
                user.id
            );


            // =========================================
            // SESSION CHECK
            // =========================================
            //
            // If email confirmation is disabled,
            // Supabase normally gives us a session
            // immediately.
            //
            // If email confirmation is enabled,
            // session may be null.
            //
            // Both situations are handled below.
            // =========================================

            const session =
                data?.session;


            // =========================================
            // CASE 1 — EMAIL CONFIRMATION REQUIRED
            // =========================================

            if (!session) {

                showMessage(
                    "Account created. Please check your email to confirm your account.",
                    "success"
                );


                setTimeout(
                    function () {

                        window.location.replace(
                            "login.html"
                        );

                    },
                    2500
                );


                return;
            }


            // =========================================
            // CASE 2 — SESSION CREATED
            // =========================================

            showMessage(
                "Account created successfully. Welcome to Bookworm Club!",
                "success"
            );


            // =========================================
            // SAVE NON-SENSITIVE INDICATOR
            // =========================================

            localStorage.setItem(
                "bookworm_logged_in",
                "true"
            );


            // =========================================
            // PROFILE CHECK
            // =========================================
            //
            // The database trigger should normally have
            // created the profile automatically.
            //
            // We wait briefly because the trigger and
            // client request may finish at slightly
            // different times.
            // =========================================

            await wait(
                500
            );


            const {
                data: profile,
                error: profileError
            } =
                await supabaseClient
                    .from("profiles")
                    .select(
                        "id, full_name, department, level, institution, created_at"
                    )
                    .eq(
                        "id",
                        user.id
                    )
                    .maybeSingle();


            if (profileError) {

                console.warn(
                    "BOOKWORM PROFILE CHECK:",
                    profileError
                );

            } else if (!profile) {

                // -------------------------------------
                // FALLBACK PROFILE CREATION
                // -------------------------------------
                //
                // If the trigger did not create the
                // profile, attempt to create it here.
                //
                // This uses ONLY columns that actually
                // exist in your profiles table.
                // -------------------------------------

                const {
                    error: insertError
                } =
                    await supabaseClient
                        .from("profiles")
                        .insert({

                            id:
                                user.id,

                            full_name:
                                formData.fullName,

                            department:
                                formData.department,

                            level:
                                formData.level,

                            institution:
                                formData.institution

                        });


                if (insertError) {

                    console.warn(
                        "BOOKWORM PROFILE FALLBACK FAILED:",
                        insertError
                    );

                } else {

                    console.log(
                        "BOOKWORM PROFILE CREATED."
                    );

                }

            } else {

                console.log(
                    "BOOKWORM PROFILE CREATED BY DATABASE TRIGGER."
                );

            }


            // =========================================
            // REDIRECT
            // =========================================

            setTimeout(
                function () {

                    window.location.replace(
                        "dashboard.html"
                    );

                },
                800
            );


        } catch (error) {

            console.error(
                "BOOKWORM SIGNUP FAILED:",
                error
            );


            showMessage(
                error?.message ||
                "Something went wrong while creating your account.",
                "error"
            );


            setLoading(false);
        }

    }


    // =================================================
    // SMALL WAIT HELPER
    // =================================================

    function wait(
        milliseconds
    ) {

        return new Promise(
            function (resolve) {

                setTimeout(
                    resolve,
                    milliseconds
                );

            }
        );

    }


    // =================================================
    // FORM SUBMIT
    // =================================================

    if (signupForm) {

        signupForm.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();

                createAccount();

            }
        );

    } else {

        console.error(
            "BOOKWORM ERROR: signupForm was not found."
        );

    }


    // =================================================
    // FINAL MESSAGE
    // =================================================

    console.log(
        "BOOKWORM: Signup system loaded."
    );


})();