// ==========================================
// BOOKWORM CLUB — ADMIN PAST QUESTIONS
// Secure upload / delete manager
// ==========================================

(function () {
    "use strict";

    let supabase = null;

    // ==========================================
    // WAIT FOR SUPABASE
    // ==========================================

    function waitForSupabase() {
        if (!window.supabaseClient) {
            setTimeout(waitForSupabase, 100);
            return;
        }

        supabase = window.supabaseClient;
        initializeAdminPage();
    }


    // ==========================================
    // INITIALIZE
    // ==========================================

    async function initializeAdminPage() {

        try {

            const {
                data: { user },
                error
            } = await supabase.auth.getUser();

            if (error || !user) {
                window.location.replace("login.html");
                return;
            }

            // Extra admin verification
            const {
                data: adminRecord,
                error: adminError
            } = await supabase
                .from("admin_users")
                .select("user_id")
                .eq("user_id", user.id)
                .maybeSingle();

            if (adminError || !adminRecord) {
                alert("You do not have administrator access.");
                window.location.replace("dashboard.html");
                return;
            }

            console.log("Admin Past Questions Manager ready.");

            setupForm();

            await loadPastQuestions();

        } catch (error) {

            console.error(
                "Admin initialization error:",
                error
            );

        }
    }


    // ==========================================
    // FORM SETUP
    // ==========================================

    function setupForm() {

        const form =
            document.getElementById("pastQuestionForm");

        if (!form) {
            console.warn(
                "Past question form not found."
            );
            return;
        }

        form.addEventListener(
            "submit",
            handleUpload
        );
    }


    // ==========================================
    // UPLOAD PAST QUESTION
    // ==========================================

    async function handleUpload(event) {

        event.preventDefault();

        const form = event.target;

        // --------------------------------------
        // Get form fields
        // --------------------------------------

        const courseCode =
            getValue(
                form,
                [
                    "courseCode",
                    "course-code",
                    "course_code"
                ]
            ).toUpperCase();

        const level =
            getValue(
                form,
                [
                    "level"
                ]
            );

        const academicSession =
            getValue(
                form,
                [
                    "academicSession",
                    "academic-session",
                    "academic_session"
                ]
            );

        const examType =
            getValue(
                form,
                [
                    "examType",
                    "exam-type",
                    "exam_type"
                ]
            );

        const paperTitle =
            getValue(
                form,
                [
                    "paperTitle",
                    "paper-title",
                    "paper_title",
                    "title"
                ]
            );

        const fileInput =
            form.querySelector(
                'input[type="file"]'
            );

        const file =
            fileInput?.files?.[0];


        // --------------------------------------
        // Validation
        // --------------------------------------

        if (!courseCode) {
            alert("Please select a course.");
            return;
        }

        if (!level) {
            alert("Please select a level.");
            return;
        }

        if (!academicSession) {
            alert("Please select an academic session.");
            return;
        }

        if (!examType) {
            alert("Please select the exam type.");
            return;
        }

        if (!paperTitle) {
            alert("Please enter a paper title.");
            return;
        }

        if (!file) {
            alert("Please select a PDF file.");
            return;
        }


        // --------------------------------------
        // PDF validation
        // --------------------------------------

        if (
            file.type !== "application/pdf" &&
            !file.name.toLowerCase().endsWith(".pdf")
        ) {
            alert("Only PDF files are allowed.");
            return;
        }


        // --------------------------------------
        // 15MB maximum
        // --------------------------------------

        const maxSize =
            15 * 1024 * 1024;

        if (file.size > maxSize) {

            alert(
                "The PDF is too large. Maximum size is 15MB."
            );

            return;
        }


        // --------------------------------------
        // Get course title
        // --------------------------------------

        const courseTitle =
            getCourseTitle(courseCode);


        // --------------------------------------
        // Disable form
        // --------------------------------------

        const submitButton =
            form.querySelector(
                'button[type="submit"]'
            );

        const originalButtonText =
            submitButton
                ? submitButton.textContent
                : "";

        if (submitButton) {
            submitButton.disabled = true;
            submitButton.textContent =
                "Uploading...";
        }


        let uploadedFilePath = null;


        try {

            // ----------------------------------
            // Sanitize filename
            // ----------------------------------

            const safeFileName =
                file.name
                    .replace(
                        /[^a-zA-Z0-9._-]/g,
                        "_"
                    );


            // ----------------------------------
            // Unique filename
            // ----------------------------------

            const uniqueFileName =
                `${Date.now()}-${crypto.randomUUID()}-${safeFileName}`;


            // ----------------------------------
            // Storage path
            // ----------------------------------

            uploadedFilePath =
                `${courseCode}/${uniqueFileName}`;


            console.log(
                "Uploading:",
                uploadedFilePath
            );


            // ----------------------------------
            // Upload PDF
            // ----------------------------------

            const {
                error: storageError
            } = await supabase
                .storage
                .from("past-questions")
                .upload(
                    uploadedFilePath,
                    file,
                    {
                        cacheControl: "3600",
                        upsert: false,
                        contentType: "application/pdf"
                    }
                );


            if (storageError) {

                console.error(
                    "Storage upload error:",
                    storageError
                );

                throw new Error(
                    storageError.message ||
                    "PDF upload failed."
                );
            }


            // ----------------------------------
            // IMPORTANT:
            // Store PATH, not public URL
            // ----------------------------------

            const insertData = {

                course_code:
                    courseCode,

                course_title:
                    courseTitle,

                level:
                    level,

                academic_session:
                    academicSession,

                exam_type:
                    examType,

                title:
                    paperTitle,

                file_url:
                    uploadedFilePath
            };


            // ----------------------------------
            // Insert database record
            // ----------------------------------

            const {
                data,
                error: databaseError
            } = await supabase
                .from("past_questions")
                .insert(insertData)
                .select()
                .single();


            if (databaseError) {

                console.error(
                    "Database insert error:",
                    databaseError
                );


                // If database insert fails,
                // remove uploaded file so we
                // don't leave orphaned files.

                await supabase
                    .storage
                    .from("past-questions")
                    .remove([
                        uploadedFilePath
                    ]);


                throw new Error(
                    databaseError.message ||
                    "Could not save past question."
                );
            }


            console.log(
                "Past question created:",
                data
            );


            alert(
                "Past question added successfully."
            );


            // ----------------------------------
            // Reset form
            // ----------------------------------

            form.reset();


            // ----------------------------------
            // Refresh list
            // ----------------------------------

            await loadPastQuestions();


        } catch (error) {

            console.error(
                "Upload error:",
                error
            );

            alert(
                error.message ||
                "Something went wrong while uploading."
            );


        } finally {

            if (submitButton) {

                submitButton.disabled = false;

                submitButton.textContent =
                    originalButtonText ||
                    "Upload Past Question";
            }
        }
    }


    // ==========================================
    // LOAD PAST QUESTIONS
    // ==========================================

    async function loadPastQuestions() {

        const list =
            findElement([
                "pastQuestionList",
                "questionList",
                "adminQuestionList"
            ]);

        if (!list) {
            return;
        }

        list.innerHTML =
            "<p>Loading past questions...</p>";


        try {

            const {
                data,
                error
            } = await supabase
                .from("past_questions")
                .select(`
                    id,
                    course_code,
                    course_title,
                    level,
                    academic_session,
                    exam_type,
                    title,
                    file_url,
                    created_at
                `)
                .order(
                    "created_at",
                    {
                        ascending: false
                    }
                );


            if (error) {

                console.error(
                    "Load error:",
                    error
                );

                list.innerHTML =
                    "<p>Unable to load past questions.</p>";

                return;
            }


            if (!data || data.length === 0) {

                list.innerHTML =
                    "<p>No past questions uploaded yet.</p>";

                return;
            }


            list.innerHTML = "";


            data.forEach(question => {

                const card =
                    createAdminCard(question);

                list.appendChild(card);

            });


        } catch (error) {

            console.error(
                "Unexpected load error:",
                error
            );

            list.innerHTML =
                "<p>Something went wrong.</p>";
        }
    }


    // ==========================================
    // CREATE ADMIN CARD
    // ==========================================

    function createAdminCard(question) {

        const card =
            document.createElement("div");

        card.className =
            "past-question-card admin-question-card";


        const title =
            document.createElement("h3");

        title.textContent =
            question.title ||
            "Untitled Paper";


        const details =
            document.createElement("p");

        details.textContent =
            `${question.course_code} • ` +
            `${question.level} • ` +
            `${question.academic_session} • ` +
            `${question.exam_type}`;


        const actions =
            document.createElement("div");

        actions.className =
            "question-actions";


        // --------------------------------------
        // View button
        // --------------------------------------

        const viewButton =
            document.createElement("button");

        viewButton.type =
            "button";

        viewButton.className =
            "question-button";

        viewButton.textContent =
            "View Paper";


        viewButton.addEventListener(
            "click",
            () => openPastQuestion(
                question.file_url
            )
        );


        // --------------------------------------
        // Delete button
        // --------------------------------------

        const deleteButton =
            document.createElement("button");

        deleteButton.type =
            "button";

        deleteButton.className =
            "question-button delete-button";

        deleteButton.textContent =
            "Delete";


        deleteButton.addEventListener(
            "click",
            () => deletePastQuestion(
                question.id,
                question.file_url
            )
        );


        actions.appendChild(
            viewButton
        );

        actions.appendChild(
            deleteButton
        );


        card.appendChild(title);
        card.appendChild(details);
        card.appendChild(actions);


        return card;
    }


    // ==========================================
    // OPEN PAST QUESTION
    // ==========================================

    async function openPastQuestion(
        storedPath
    ) {

        const path =
            extractStoragePath(
                storedPath
            );

        if (!path) {

            alert(
                "This past question does not have a valid file."
            );

            return;
        }


        try {

            const {
                data,
                error
            } = await supabase
                .storage
                .from("past-questions")
                .createSignedUrl(
                    path,
                    60 * 60
                );


            if (error) {

                console.error(
                    "Signed URL error:",
                    error
                );

                alert(
                    "Unable to open this PDF."
                );

                return;
            }


            if (!data?.signedUrl) {

                alert(
                    "No secure PDF link was generated."
                );

                return;
            }


            window.open(
                data.signedUrl,
                "_blank",
                "noopener,noreferrer"
            );


        } catch (error) {

            console.error(
                "Open PDF error:",
                error
            );

            alert(
                "Unable to open this PDF."
            );
        }
    }


    // ==========================================
    // DELETE PAST QUESTION
    // ==========================================

    async function deletePastQuestion(
        id,
        storedPath
    ) {

        const confirmed =
            window.confirm(
                "Are you sure you want to delete this past question?"
            );


        if (!confirmed) {
            return;
        }


        try {

            // ----------------------------------
            // Delete database record
            // ----------------------------------

            const {
                error: databaseError
            } = await supabase
                .from("past_questions")
                .delete()
                .eq("id", id);


            if (databaseError) {

                console.error(
                    "Database delete error:",
                    databaseError
                );

                alert(
                    "Could not delete the database record."
                );

                return;
            }


            // ----------------------------------
            // Delete storage file
            // ----------------------------------

            const path =
                extractStoragePath(
                    storedPath
                );


            if (path) {

                const {
                    error: storageError
                } = await supabase
                    .storage
                    .from("past-questions")
                    .remove([
                        path
                    ]);


                if (storageError) {

                    console.error(
                        "Storage delete error:",
                        storageError
                    );

                    alert(
                        "Database record deleted, but the PDF file could not be removed."
                    );

                    await loadPastQuestions();

                    return;
                }
            }


            alert(
                "Past question deleted successfully."
            );


            await loadPastQuestions();


        } catch (error) {

            console.error(
                "Delete error:",
                error
            );

            alert(
                "Something went wrong while deleting."
            );
        }
    }


    // ==========================================
    // EXTRACT STORAGE PATH
    //
    // Supports:
    // 1. New stored paths
    // 2. Old public URLs
    // ==========================================

    function extractStoragePath(value) {

        if (!value) {
            return null;
        }


        // Already a storage path
        if (
            !value.startsWith("http://") &&
            !value.startsWith("https://")
        ) {
            return value;
        }


        // Old public URL
        const marker =
            "/storage/v1/object/public/past-questions/";


        const markerIndex =
            value.indexOf(marker);


        if (markerIndex !== -1) {

            return decodeURIComponent(
                value.substring(
                    markerIndex +
                    marker.length
                )
            );
        }


        // Signed URL compatibility
        const signedMarker =
            "/storage/v1/object/sign/past-questions/";


        const signedIndex =
            value.indexOf(signedMarker);


        if (signedIndex !== -1) {

            return decodeURIComponent(
                value.substring(
                    signedIndex +
                    signedMarker.length
                ).split("?")[0]
            );
        }


        return null;
    }


    // ==========================================
    // COURSE TITLES
    // ==========================================

    function getCourseTitle(courseCode) {

        const courses = {

            GST212:
                "Philosophy, Logic and Human Existence",

            GST211:
                "Entrepreneurship and Innovation",

            EDU201:
                "Curriculum, Curriculum Delivery and General Teaching Methods",

            EDU211:
                "Developmental Psychology",

            UNIBENEDU212:
                "Philosophy of Education",

            ENG201:
                "Introduction to Morphology and Syntax",

            ENG203:
                "Introduction to General Phonetics and Phonology"
        };


        return (
            courses[courseCode] ||
            courseCode
        );
    }


    // ==========================================
    // GET FORM VALUE
    // ==========================================

    function getValue(
        form,
        possibleIds
    ) {

        for (const id of possibleIds) {

            const element =
                form.querySelector(
                    `#${CSS.escape(id)}`
                );

            if (element) {
                return element.value.trim();
            }
        }


        return "";
    }


    // ==========================================
    // FIND ELEMENT
    // ==========================================

    function findElement(ids) {

        for (const id of ids) {

            const element =
                document.getElementById(id);

            if (element) {
                return element;
            }
        }

        return null;
    }


    // ==========================================
    // START
    // ==========================================

    waitForSupabase();

})();