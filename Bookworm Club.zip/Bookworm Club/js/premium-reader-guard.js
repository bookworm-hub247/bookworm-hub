/* =========================================================
   BOOKWORM CLUB — PREMIUM READER GUARD
========================================================= */

"use strict";


document.addEventListener(
    "DOMContentLoaded",
    async function() {

        if (
            !window.BookwormPremium
        ) {

            return;

        }


        /* -----------------------------------------
           WAIT FOR DATABASE PREMIUM CHECK
        ----------------------------------------- */

        if (
            BookwormPremium.ready
        ) {

            await BookwormPremium.ready;

        }


        /* -----------------------------------------
           GET URL PARAMETERS
        ----------------------------------------- */

        const params =
            new URLSearchParams(
                window.location.search
            );


        const course =
            params.get("course") || "";


        const moduleNumber =
            parseInt(
                params.get("module"),
                10
            ) || 1;


        /* -----------------------------------------
           CHECK MODULE ACCESS
        ----------------------------------------- */

        const allowed =
            BookwormPremium.canAccessModule(
                course,
                moduleNumber
            );


        if (allowed) {

            document.documentElement
                .classList
                .add("bookworm-access-granted");

            return;

        }


        /* -----------------------------------------
           PREMIUM LOCK
        ----------------------------------------- */

        document.documentElement
            .classList
            .add("bookworm-premium-locked");


        const reader =
            document.querySelector(
                "[data-premium-content]"
            );


        if (reader) {

            reader.innerHTML = `

                <div class="premium-lock-screen">

                    <div class="premium-lock-icon">
                        🔒
                    </div>

                    <span class="premium-eyebrow">
                        PREMIUM CONTENT
                    </span>

                    <h2>
                        Unlock this module
                    </h2>

                    <p>
                        This module is part of
                        Bookworm Club Premium.
                    </p>

                    <button
                        type="button"
                        onclick="window.location.href='courses.html'"
                    >
                        View Premium Access
                    </button>

                </div>

            `;

        }

    }
);