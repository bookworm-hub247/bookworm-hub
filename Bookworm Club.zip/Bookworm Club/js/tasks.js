// ==========================================
// BOOKWORM CLUB — TASK MANAGER
// ==========================================

document.addEventListener("DOMContentLoaded", function () {

    const taskForm = document.getElementById("taskForm");
    const taskTitle = document.getElementById("taskTitle");
    const taskCourse = document.getElementById("taskCourse");
    const taskDue = document.getElementById("taskDue");
    const taskList = document.getElementById("taskManagerList");
    const taskTotal = document.getElementById("taskTotal");

    // Check that all required elements exist
    if (
        !taskForm ||
        !taskTitle ||
        !taskCourse ||
        !taskDue ||
        !taskList ||
        !taskTotal
    ) {
        console.error("BOOKWORM TASK MANAGER: Required element missing.");
        return;
    }

    // ==========================================
    // LOAD SAVED TASKS
    // ==========================================

    let tasks = [];

    try {
        const savedTasks =
            localStorage.getItem("bookwormTasks");

        if (savedTasks) {
            tasks = JSON.parse(savedTasks);
        }
    } catch (error) {
        console.error(
            "Could not load saved tasks:",
            error
        );

        tasks = [];
    }

    // ==========================================
    // SAVE TASKS
    // ==========================================

    function saveTasks() {

        try {

            localStorage.setItem(
                "bookwormTasks",
                JSON.stringify(tasks)
            );

            console.log("Tasks saved successfully.");

        } catch (error) {

            console.error(
                "Could not save tasks:",
                error
            );

        }

    }

    // ==========================================
    // DISPLAY TASKS
    // ==========================================

    function renderTasks() {

        taskList.innerHTML = "";

        taskTotal.textContent =
            tasks.length +
            (tasks.length === 1 ? " task" : " tasks");

        if (tasks.length === 0) {

            taskList.innerHTML = `
                <p class="empty-state">
                    No tasks yet. Add your first academic task above.
                </p>
            `;

            return;
        }

        tasks.forEach(function (task) {

            const item =
                document.createElement("div");

            item.className =
                "task-manager-item";

            if (task.completed) {
                item.classList.add("completed");
            }

            item.innerHTML = `
                <div class="task-check">
                    <input
                        type="checkbox"
                        ${task.completed ? "checked" : ""}
                        data-id="${task.id}"
                    >
                </div>

                <div class="task-manager-info">

                    <h3>${task.title}</h3>

                    <p>
                        ${task.course}
                        • Due ${task.due}
                    </p>

                </div>

                <button
                    class="delete-task"
                    data-id="${task.id}">
                    Delete
                </button>
            `;

            taskList.appendChild(item);

        });

    }

    // ==========================================
    // ADD TASK
    // ==========================================

    taskForm.addEventListener(
        "submit",
        function (event) {

            event.preventDefault();

            const title =
                taskTitle.value.trim();

            const course =
                taskCourse.value.trim();

            const due =
                taskDue.value;

            if (!title || !course || !due) {

                alert(
                    "Please complete all fields."
                );

                return;
            }

            const newTask = {

                id: Date.now(),

                title: title,

                course: course,

                due: due,

                completed: false

            };

            tasks.push(newTask);

            saveTasks();

            renderTasks();

            taskForm.reset();

            console.log(
                "New task added:",
                newTask
            );

        }
    );

    // ==========================================
    // DELETE TASK
    // ==========================================

    taskList.addEventListener(
        "click",
        function (event) {

            if (
                !event.target.classList.contains(
                    "delete-task"
                )
            ) {
                return;
            }

            const id =
                Number(event.target.dataset.id);

            tasks = tasks.filter(
                function (task) {

                    return task.id !== id;

                }
            );

            saveTasks();

            renderTasks();

        }
    );

    // ==========================================
    // COMPLETE TASK
    // ==========================================

    taskList.addEventListener(
        "change",
        function (event) {

            if (
                event.target.type !== "checkbox"
            ) {
                return;
            }

            const id =
                Number(event.target.dataset.id);

            const task =
                tasks.find(
                    function (task) {

                        return task.id === id;

                    }
                );

            if (task) {

                task.completed =
                    event.target.checked;

                saveTasks();

                renderTasks();

            }

        }
    );

    // ==========================================
    // INITIALIZE
    // ==========================================

    renderTasks();

    console.log(
        "BOOKWORM TASK MANAGER READY."
    );

});