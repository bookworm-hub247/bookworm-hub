/* =========================================================
   BOOKWORM CLUB
   PAST QUESTIONS — STUDENT
   SUPABASE CONNECTED
   COURSE-AWARE FILTERING
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    async function () {

        /* =================================================
           SUPABASE
        ================================================= */

        const supabase =
            window.supabaseClient;


        if (!supabase) {

            console.error(
                "Bookworm Club: Supabase client not found."
            );

            showError(
                "The academic library could not connect to Supabase."
            );

            return;

        }


        /* =================================================
           ELEMENTS
        ================================================= */

        const questionList =
            document.getElementById(
                "questionList"
            );


        const loadingState =
            document.getElementById(
                "loadingState"
            );


        const emptyState =
            document.getElementById(
                "emptyState"
            );


        const errorState =
            document.getElementById(
                "errorState"
            );


        const errorMessage =
            document.getElementById(
                "errorMessage"
            );


        const retryButton =
            document.getElementById(
                "retryButton"
            );


        const emptyClearButton =
            document.getElementById(
                "emptyClearButton"
            );


        const searchInput =
            document.getElementById(
                "questionSearch"
            );


        const levelFilter =
            document.getElementById(
                "levelFilter"
            );


        const sessionFilter =
            document.getElementById(
                "sessionFilter"
            );


        const clearFilters =
            document.getElementById(
                "clearFilters"
            );


        const questionCount =
            document.getElementById(
                "questionCount"
            );


        const totalQuestionCount =
            document.getElementById(
                "totalQuestionCount"
            );


        const courseButtons =
            document.querySelectorAll(
                ".course-filter"
            );


        const drawerUserName =
            document.getElementById(
                "drawerUserName"
            );


        /* =================================================
           URL COURSE
        ================================================= */

        const urlParams =
            new URLSearchParams(
                window.location.search
            );


        const courseFromURL =
            urlParams.get("course");


        /* =================================================
           STATE
        ================================================= */

        let allQuestions = [];

        let selectedCourse =
            courseFromURL ||
            "all";


        /* =================================================
           NORMALIZE COURSE CODE
           Makes ENG201 and ENG 201 match.
        ================================================= */

        function normalizeCourseCode(
            value
        ) {

            if (
                value === null ||
                value === undefined
            ) {

                return "";

            }


            return String(value)
                .trim()
                .toUpperCase()
                .replace(/\s+/g, "");

        }


        /* =================================================
           LOAD USER
        ================================================= */

        async function loadUser() {

            try {

                const {
                    data,
                    error
                } =
                    await supabase.auth.getUser();


                if (
                    error ||
                    !data ||
                    !data.user
                ) {

                    return;

                }


                const user =
                    data.user;


                const name =
                    user.user_metadata?.full_name ||
                    user.user_metadata?.name ||
                    user.email?.split("@")[0] ||
                    "Student";


                if (drawerUserName) {

                    drawerUserName.textContent =
                        name;

                }

            } catch (error) {

                console.warn(
                    "Bookworm Club: Could not load student name.",
                    error
                );

            }

        }


        /* =================================================
           LOAD QUESTIONS
        ================================================= */

        async function loadQuestions() {

            showLoading();


            try {

                const {
                    data,
                    error
                } =
                    await supabase
                        .from("past_questions")
                        .select(`
                            id,
                            course_code,
                            course_title,
                            level,
                            academic_session,
                            exam_type,
                            paper_title,
                            file_url,
                            created_at
                        `)
                        .order(
                            "created_at",
                            {
                                ascending:
                                    false
                            }
                        );


                if (error) {

                    console.error(
                        "Bookworm Club: Past Questions error:",
                        error
                    );

                    showError(
                        error.message ||
                        "We could not load the past questions."
                    );

                    return;

                }


                allQuestions =
                    data || [];


                if (totalQuestionCount) {

                    totalQuestionCount.textContent =
                        allQuestions.length;

                }


                /*
                 * After the questions have loaded,
                 * activate the course supplied
                 * through the URL.
                 */
                activateURLCourse();


                renderQuestions();


            } catch (error) {

                console.error(
                    "Bookworm Club: Unexpected Past Questions error:",
                    error
                );

                showError(
                    "Something went wrong while loading the academic library."
                );

            }

        }


        /* =================================================
           ACTIVATE COURSE FROM URL
        ================================================= */

        function activateURLCourse() {

            if (
                !courseFromURL ||
                courseFromURL === "all"
            ) {

                activateAllCourseButton();

                return;

            }


            const normalizedURLCourse =
                normalizeCourseCode(
                    courseFromURL
                );


            let matchingButton =
                null;


            courseButtons.forEach(
                function (button) {

                    const buttonCourse =
                        button.dataset.course ||
                        "all";


                    if (
                        normalizeCourseCode(
                            buttonCourse
                        ) ===
                        normalizedURLCourse
                    ) {

                        matchingButton =
                            button;

                    }

                }
            );


            /*
             * If the course exists in the
             * Past Questions course buttons,
             * activate it.
             */
            if (matchingButton) {

                courseButtons.forEach(
                    function (button) {

                        button.classList.remove(
                            "active"
                        );

                    }
                );


                matchingButton.classList.add(
                    "active"
                );


                selectedCourse =
                    matchingButton.dataset.course ||
                    courseFromURL;


                return;

            }


            /*
             * If no matching button exists,
             * still keep the URL course as
             * the selected course.
             */
            selectedCourse =
                courseFromURL;

        }


        /* =================================================
           ACTIVATE ALL COURSE BUTTON
        ================================================= */

        function activateAllCourseButton() {

            courseButtons.forEach(
                function (button) {

                    button.classList.remove(
                        "active"
                    );

                }
            );


            const allButton =
                document.querySelector(
                    '[data-course="all"]'
                );


            if (allButton) {

                allButton.classList.add(
                    "active"
                );

            }

        }


        /* =================================================
           FILTER QUESTIONS
        ================================================= */

        function getFilteredQuestions() {

            const searchTerm =
                searchInput
                    ? searchInput.value
                        .trim()
                        .toLowerCase()
                    : "";


            const selectedLevel =
                levelFilter
                    ? levelFilter.value
                    : "all";


            const selectedSession =
                sessionFilter
                    ? sessionFilter.value
                    : "all";


            return allQuestions.filter(
                function (question) {


                    const paperTitle =
                        question.paper_title ||
                        "";


                    const searchableText = `

                        ${paperTitle}

                        ${question.course_code || ""}

                        ${question.course_title || ""}

                        ${question.academic_session || ""}

                        ${question.exam_type || ""}

                        ${question.level || ""}

                    `
                    .toLowerCase();


                    const matchesSearch =
                        searchableText.includes(
                            searchTerm
                        );


                    /*
                     * Normalize both sides so:
                     *
                     * ENG201
                     * ENG 201
                     *
                     * are treated as the same course.
                     */
                    const questionCourse =
                        normalizeCourseCode(
                            question.course_code
                        );


                    const selectedCourseCode =
                        normalizeCourseCode(
                            selectedCourse
                        );


                    const matchesCourse =
                        selectedCourse === "all" ||
                        questionCourse ===
                            selectedCourseCode;


                    const matchesLevel =
                        selectedLevel === "all" ||
                        String(
                            question.level || ""
                        ) ===
                            String(
                                selectedLevel
                            );


                    const matchesSession =
                        selectedSession === "all" ||
                        question.academic_session ===
                            selectedSession;


                    return (
                        matchesSearch &&
                        matchesCourse &&
                        matchesLevel &&
                        matchesSession
                    );

                }
            );

        }


        /* =================================================
           RENDER QUESTIONS
        ================================================= */

        function renderQuestions() {

            if (!questionList) {

                return;

            }


            hideAllStates();


            const filteredQuestions =
                getFilteredQuestions();


            questionList.innerHTML =
                "";


            if (questionCount) {

                questionCount.textContent =
                    `${filteredQuestions.length} ${
                        filteredQuestions.length === 1
                            ? "paper"
                            : "papers"
                    }`;

            }


            if (
                filteredQuestions.length === 0
            ) {

                if (emptyState) {

                    emptyState.hidden =
                        false;

                }

                return;

            }


            filteredQuestions.forEach(
                function (question) {

                    questionList.appendChild(
                        createQuestionCard(
                            question
                        )
                    );

                }
            );

        }


        /* =================================================
           CREATE QUESTION CARD
        ================================================= */

        function createQuestionCard(
            question
        ) {

            const card =
                document.createElement(
                    "article"
                );


            card.className =
                "question-card";


            const courseCode =
                question.course_code ||
                "COURSE";


            const courseTitle =
                question.course_title ||
                "Past Examination Question";


            const paperTitle =
                question.paper_title ||
                `${courseCode} Past Question`;


            const examType =
                question.exam_type ||
                "Examination";


            const level =
                question.level ||
                "Level";


            const session =
                question.academic_session ||
                "Session";


            const fileUrl =
                question.file_url ||
                "";


            card.innerHTML = `

                <div class="question-card-top">

                    <span class="question-code">

                        ${escapeHTML(
                            courseCode
                        )}

                    </span>


                    <span class="question-type">

                        ${escapeHTML(
                            examType
                        )}

                    </span>

                </div>


                <h3>

                    ${escapeHTML(
                        paperTitle
                    )}

                </h3>


                <p class="question-description">

                    ${escapeHTML(
                        courseTitle
                    )}

                </p>


                <div class="question-meta">

                    <span>

                        ${escapeHTML(
                            level
                        )}

                    </span>


                    <span>

                        ${escapeHTML(
                            session
                        )}

                    </span>

                </div>


                <div class="question-actions">

                    ${
                        fileUrl

                            ? `

                                <a
                                    href="${escapeAttribute(
                                        fileUrl
                                    )}"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    class="question-button"
                                >
                                    View Paper
                                </a>

                            `

                            : `

                                <button
                                    type="button"
                                    class="question-button disabled"
                                    disabled
                                >
                                    Paper Unavailable
                                </button>

                            `
                    }

                </div>

            `;


            return card;

        }


        /* =================================================
           COURSE FILTER BUTTONS
        ================================================= */

        courseButtons.forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function () {


                        courseButtons.forEach(
                            function (item) {

                                item.classList.remove(
                                    "active"
                                );

                            }
                        );


                        button.classList.add(
                            "active"
                        );


                        selectedCourse =
                            button.dataset.course ||
                            "all";


                        renderQuestions();

                    }
                );

            }
        );


        /* =================================================
           SEARCH
        ================================================= */

        if (searchInput) {

            searchInput.addEventListener(
                "input",
                renderQuestions
            );

        }


        /* =================================================
           LEVEL
        ================================================= */

        if (levelFilter) {

            levelFilter.addEventListener(
                "change",
                renderQuestions
            );

        }


        /* =================================================
           SESSION
        ================================================= */

        if (sessionFilter) {

            sessionFilter.addEventListener(
                "change",
                renderQuestions
            );

        }


        /* =================================================
           CLEAR FILTERS
        ================================================= */

        function clearAllFilters() {


            if (searchInput) {

                searchInput.value =
                    "";

            }


            if (levelFilter) {

                levelFilter.value =
                    "all";

            }


            if (sessionFilter) {

                sessionFilter.value =
                    "all";

            }


            selectedCourse =
                "all";


            courseButtons.forEach(
                function (button) {

                    button.classList.remove(
                        "active"
                    );

                }
            );


            const allButton =
                document.querySelector(
                    '[data-course="all"]'
                );


            if (allButton) {

                allButton.classList.add(
                    "active"
                );

            }


            renderQuestions();

        }


        if (clearFilters) {

            clearFilters.addEventListener(
                "click",
                clearAllFilters
            );

        }


        if (emptyClearButton) {

            emptyClearButton.addEventListener(
                "click",
                clearAllFilters
            );

        }


        /* =================================================
           RETRY
        ================================================= */

        if (retryButton) {

            retryButton.addEventListener(
                "click",
                loadQuestions
            );

        }


        /* =================================================
           LOADING
        ================================================= */

        function showLoading() {


            if (loadingState) {

                loadingState.hidden =
                    false;

            }


            if (emptyState) {

                emptyState.hidden =
                    true;

            }


            if (errorState) {

                errorState.hidden =
                    true;

            }


            if (questionList) {

                questionList.innerHTML =
                    "";

            }

        }


        /* =================================================
           ERROR
        ================================================= */

        function showError(
            message
        ) {


            if (loadingState) {

                loadingState.hidden =
                    true;

            }


            if (emptyState) {

                emptyState.hidden =
                    true;

            }


            if (errorState) {

                errorState.hidden =
                    false;

            }


            if (questionList) {

                questionList.innerHTML =
                    "";

            }


            if (errorMessage) {

                errorMessage.textContent =
                    message;

            }

        }


        /* =================================================
           HIDE STATES
        ================================================= */

        function hideAllStates() {


            if (loadingState) {

                loadingState.hidden =
                    true;

            }


            if (emptyState) {

                emptyState.hidden =
                    true;

            }


            if (errorState) {

                errorState.hidden =
                    true;

            }

        }


        /* =================================================
           SECURITY
        ================================================= */

        function escapeHTML(
            value
        ) {

            if (
                value === null ||
                value === undefined
            ) {

                return "";

            }


            return String(value)

                .replace(
                    /&/g,
                    "&amp;"
                )

                .replace(
                    /</g,
                    "&lt;"
                )

                .replace(
                    />/g,
                    "&gt;"
                )

                .replace(
                    /"/g,
                    "&quot;"
                )

                .replace(
                    /'/g,
                    "&#039;"
                );

        }


        function escapeAttribute(
            value
        ) {

            if (!value) {

                return "#";

            }


            return String(value)

                .replace(
                    /&/g,
                    "&amp;"
                )

                .replace(
                    /"/g,
                    "&quot;"
                )

                .replace(
                    /'/g,
                    "&#039;"
                )

                .replace(
                    /</g,
                    "%3C"
                )

                .replace(
                    />/g,
                    "%3E"
                );

        }


        /* =================================================
           START
        ================================================= */

        await loadUser();

        await loadQuestions();


        console.log(
            "Bookworm Club: Past Questions ready."
        );

    }
);