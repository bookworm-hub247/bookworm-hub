/* =========================================================
   VERIFY ADMIN
========================================================= */

async function verifyAdmin() {

    const {
        data: {
            user
        },
        error
    } =
        await adminSupabase
            .auth
            .getUser();


    /* -----------------------------------------
       AUTHENTICATION ERROR
    ----------------------------------------- */

    if (error) {

        throw error;

    }


    /* -----------------------------------------
       NOT LOGGED IN
    ----------------------------------------- */

    if (!user) {

        window.location.replace(
            "login.html"
        );

        return;

    }


    currentAdmin =
        user;


    /* -----------------------------------------
       VERIFY ADMIN AUTHORIZATION
       
       IMPORTANT:
       Admin status comes from admin_users,
       NOT profiles.is_admin.
    ----------------------------------------- */

    const {
        data: adminRecord,
        error: adminError
    } =
        await adminSupabase

            .from("admin_users")

            .select("user_id")

            .eq(
                "user_id",
                user.id
            )

            .maybeSingle();


    if (adminError) {

        throw adminError;

    }


    /* -----------------------------------------
       NOT AN ADMIN
    ----------------------------------------- */

    if (!adminRecord) {

        window.location.replace(
            "dashboard.html"
        );

        return;

    }


    /* -----------------------------------------
       LOAD ADMIN PROFILE
    ----------------------------------------- */

    const {
        data: profile,
        error: profileError
    } =
        await adminSupabase

            .from("profiles")

            .select(`
                id,
                full_name,
                department,
                level,
                institution
            `)

            .eq(
                "id",
                user.id
            )

            .maybeSingle();


    if (profileError) {

        throw profileError;

    }


    /* -----------------------------------------
       STORE ADMIN STATE
    ----------------------------------------- */

    window.bookwormIsAdmin =
        true;


    window.bookwormAdminProfile =
        profile || null;

}