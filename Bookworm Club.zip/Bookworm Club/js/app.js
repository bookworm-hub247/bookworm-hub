/* =========================================================
   BOOKWORM CLUB
   GLOBAL APPLICATION JAVASCRIPT
========================================================= */

document.addEventListener("DOMContentLoaded", async function () {

    /* =====================================================
       NAVIGATION DRAWER
    ===================================================== */

    const menuToggle =
        document.getElementById("menuToggle");

    const navDrawer =
        document.getElementById("navDrawer");

    const drawerOverlay =
        document.getElementById("drawerOverlay");

    const drawerClose =
        document.getElementById("drawerClose");


    /* =====================================================
       OPEN DRAWER
    ===================================================== */

    function openDrawer() {

        if (!navDrawer || !drawerOverlay) {
            return;
        }

        navDrawer.classList.add("active");

        drawerOverlay.classList.add("active");

        document.body.classList.add("drawer-open");

        if (menuToggle) {

            menuToggle.setAttribute(
                "aria-expanded",
                "true"
            );

        }

    }


    /* =====================================================
       CLOSE DRAWER
    ===================================================== */

    function closeDrawer() {

        if (!navDrawer || !drawerOverlay) {
            return;
        }

        navDrawer.classList.remove("active");

        drawerOverlay.classList.remove("active");

        document.body.classList.remove("drawer-open");

        if (menuToggle) {

            menuToggle.setAttribute(
                "aria-expanded",
                "false"
            );

        }

    }


    /* =====================================================
       MENU BUTTON
    ===================================================== */

    if (menuToggle) {

        menuToggle.addEventListener(
            "click",
            function () {

                if (
                    navDrawer &&
                    navDrawer.classList.contains("active")
                ) {

                    closeDrawer();

                } else {

                    openDrawer();

                }

            }
        );

    }


    /* =====================================================
       CLOSE BUTTON
    ===================================================== */

    if (drawerClose) {

        drawerClose.addEventListener(
            "click",
            closeDrawer
        );

    }


    /* =====================================================
       CLICK OUTSIDE DRAWER
    ===================================================== */

    if (drawerOverlay) {

        drawerOverlay.addEventListener(
            "click",
            closeDrawer
        );

    }


    /* =====================================================
       ESCAPE KEY
    ===================================================== */

    document.addEventListener(
        "keydown",
        function (event) {

            if (event.key === "Escape") {

                closeDrawer();

            }

        }
    );


    /* =====================================================
       ADMIN NAVIGATION
    ===================================================== */

    await loadAdminNavigation();


    /* =====================================================
       DRAWER LINKS
    ===================================================== */

    const drawerLinks =
        document.querySelectorAll(
            ".drawer-link"
        );


    drawerLinks.forEach(
        function (link) {

            link.addEventListener(
                "click",
                function () {

                    /*
                     * Logout is handled by auth.js.
                     */

                    if (
                        !link.classList.contains(
                            "logout-link"
                        )
                    ) {

                        closeDrawer();

                    }

                }
            );

        }
    );


    /* =====================================================
       ACTIVE PAGE
    ===================================================== */

    const currentPage =
        window.location.pathname
            .split("/")
            .pop() ||
        "index.html";


    drawerLinks.forEach(
        function (link) {

            const linkPage =
                link.getAttribute("href");


            if (
                linkPage &&
                linkPage === currentPage
            ) {

                link.classList.add("active");

            }

        }
    );


    /* =====================================================
       GLOBAL READY MESSAGE
    ===================================================== */

    console.log(
        "Bookworm Club loaded successfully."
    );

});


/* =========================================================
   ADMIN NAVIGATION
========================================================= */

async function loadAdminNavigation() {

    const adminNavigation =
        document.getElementById(
            "adminNavigation"
        );


    /*
     * If this page does not contain the
     * Admin navigation, stop here.
     */

    if (!adminNavigation) {
        return;
    }


    /*
     * Make sure the shared Supabase
     * client created by auth.js exists.
     */

    if (
        !window.supabaseClient
    ) {

        console.warn(
            "Bookworm Club: Supabase client unavailable."
        );

        return;
    }


    try {

        /*
         * Get the currently authenticated user.
         */

        const {
            data: {
                user
            },
            error: userError
        } =
            await window.supabaseClient.auth.getUser();


        if (
            userError ||
            !user
        ) {

            console.log(
                "No authenticated user. Admin navigation hidden."
            );

            return;
        }


        /*
         * Use the SAME admin verification
         * function already used by your
         * Admin Dashboard.
         */

        const {
            data,
            error
        } =
            await window.supabaseClient.rpc(
                "is_admin"
            );


        if (error) {

            console.error(
                "Admin navigation verification failed:",
                error
            );

            return;
        }


        /*
         * Show Admin navigation only when
         * Supabase confirms the user is an admin.
         */

        if (data === true) {

            adminNavigation.hidden = false;

            console.log(
                "Bookworm Club: Admin navigation enabled."
            );

        } else {

            adminNavigation.hidden = true;

            console.log(
                "Bookworm Club: Student account detected."
            );

        }


    } catch (error) {

        console.error(
            "Admin navigation error:",
            error
        );

    }

}

/* ==========================================
   BOOKWORM CLUB — SERVICE WORKER
   AUTOMATIC UPDATE SYSTEM
========================================== */

if ("serviceWorker" in navigator) {

    window.addEventListener("load", async () => {

        try {

            /*
             * Register the service worker.
             *
             * updateViaCache: "none" tells the browser
             * to check the service-worker file itself
             * for a fresh version.
             */

            const registration =
                await navigator.serviceWorker.register(
                    "./service-worker.js",
                    {
                        updateViaCache: "none"
                    }
                );


            console.log(
                "Bookworm Club: Service Worker registered successfully.",
                registration
            );


            /*
             * Immediately check Netlify for
             * a newer service worker.
             */

            await registration.update();


            /*
             * A new service worker has been found.
             */

            registration.addEventListener(
                "updatefound",
                () => {

                    const newWorker =
                        registration.installing;


                    if (!newWorker) {
                        return;
                    }


                    console.log(
                        "Bookworm Club: New version found."
                    );


                    newWorker.addEventListener(
                        "statechange",
                        () => {

                            /*
                             * The new worker has finished
                             * installing and is waiting.
                             */

                            if (
                                newWorker.state ===
                                "installed"
                            ) {

                                /*
                                 * If a controller already
                                 * exists, this is an update.
                                 */

                                if (
                                    navigator
                                        .serviceWorker
                                        .controller
                                ) {

                                    showBookwormUpdate(
                                        registration
                                    );

                                }

                            }

                        }
                    );

                }
            );


            /*
             * Check again whenever the user
             * returns to Bookworm.
             */

            document.addEventListener(
                "visibilitychange",
                () => {

                    if (
                        document.visibilityState ===
                        "visible"
                    ) {

                        registration.update();

                    }

                }
            );


            /*
             * When the new service worker takes
             * control, reload Bookworm once.
             */

            let refreshing = false;


            navigator.serviceWorker.addEventListener(
                "controllerchange",
                () => {

                    if (refreshing) {
                        return;
                    }

                    refreshing = true;

                    console.log(
                        "Bookworm Club: Loading new version..."
                    );

                    window.location.reload();

                }
            );


        } catch (error) {

            console.error(
                "Bookworm Club: Service Worker error:",
                error
            );

        }

    });

}


/* ==========================================
   SHOW UPDATE NOTIFICATION
========================================== */

function showBookwormUpdate(registration) {

    /*
     * Don't show duplicate notifications.
     */

    if (
        document.getElementById(
            "bookwormUpdateNotice"
        )
    ) {

        return;

    }


    const notice =
        document.createElement("div");


    notice.id =
        "bookwormUpdateNotice";


    notice.innerHTML = `

        <div class="bookworm-update-content">

            <div class="bookworm-update-text">

                <strong>
                    New Bookworm version available
                </strong>

                <span>
                    Refresh to get the latest updates.
                </span>

            </div>


            <button
                id="bookwormRefreshButton"
                type="button"
            >
                Refresh
            </button>

        </div>

    `;


    document.body.appendChild(notice);


    /*
     * Refresh button
     */

    const refreshButton =
        document.getElementById(
            "bookwormRefreshButton"
        );


    refreshButton.addEventListener(
        "click",
        () => {

            /*
             * Tell the waiting service worker
             * to become active.
             */

            if (
                registration.waiting
            ) {

                registration.waiting.postMessage({
                    type: "SKIP_WAITING"
                });

            }

        }
    );

}