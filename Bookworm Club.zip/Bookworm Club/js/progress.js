/* =========================================================
   BOOKWORM CLUB
   STUDY PROGRESS ENGINE
   Progress System v2
========================================================= */

"use strict";


/* =========================================================
   CONFIGURATION
========================================================= */

const BOOKWORM_PROGRESS_CONFIG = {

    completionThreshold: 90,

    tableName: "study_progress"

};


/* =========================================================
   NORMALIZE COURSE CODE
========================================================= */

function normalizeProgressCourseCode(courseCode) {

    if (!courseCode) {
        return "";
    }

    return String(courseCode)
        .trim()
        .replace(/\s+/g, "")
        .toUpperCase();

}


/* =========================================================
   NORMALIZE MODULE NUMBER
========================================================= */

function normalizeModuleNumber(moduleNumber) {

    const number =
        parseInt(moduleNumber, 10);

    if (
        Number.isNaN(number) ||
        number < 1
    ) {

        return null;

    }

    return number;

}


/* =========================================================
   CLAMP PROGRESS
========================================================= */

function clampProgress(value) {

    const number =
        Number(value);

    if (Number.isNaN(number)) {
        return 0;
    }

    return Math.min(
        100,
        Math.max(
            0,
            Math.round(number)
        )
    );

}


/* =========================================================
   GET SUPABASE CLIENT
========================================================= */

function getProgressSupabaseClient() {

    if (!window.supabaseClient) {

        console.error(
            "BOOKWORM PROGRESS: window.supabaseClient is unavailable."
        );

        return null;

    }

    return window.supabaseClient;

}


/* =========================================================
   GET CURRENT USER
========================================================= */

async function getProgressCurrentUser() {

    const supabase =
        getProgressSupabaseClient();

    if (!supabase) {
        return null;
    }


    try {

        /*
         * getSession() is used first because it
         * immediately reads the persisted login.
         */

        const {
            data: sessionData,
            error: sessionError
        } =
            await supabase.auth.getSession();


        if (sessionError) {

            console.error(
                "BOOKWORM PROGRESS: Session lookup failed.",
                sessionError
            );

        }


        const sessionUser =
            sessionData?.session?.user;


        if (sessionUser) {

            return sessionUser;

        }


        /*
         * Fallback to getUser().
         */

        const {
            data: userData,
            error: userError
        } =
            await supabase.auth.getUser();


        if (userError) {

            console.error(
                "BOOKWORM PROGRESS: User lookup failed.",
                userError
            );

            return null;

        }


        return userData?.user || null;

    } catch (error) {

        console.error(
            "BOOKWORM PROGRESS: Authentication lookup crashed.",
            error
        );

        return null;

    }

}


/* =========================================================
   GET ONE MODULE
========================================================= */

async function getModuleProgress(
    courseCode,
    moduleNumber
) {

    const supabase =
        getProgressSupabaseClient();

    if (!supabase) {
        return null;
    }


    const normalizedCourse =
        normalizeProgressCourseCode(
            courseCode
        );


    const normalizedModule =
        normalizeModuleNumber(
            moduleNumber
        );


    if (
        !normalizedCourse ||
        !normalizedModule
    ) {

        console.warn(
            "BOOKWORM PROGRESS: Invalid module request.",
            {
                courseCode,
                moduleNumber
            }
        );

        return null;

    }


    const user =
        await getProgressCurrentUser();


    if (!user) {

        console.warn(
            "BOOKWORM PROGRESS: No authenticated user."
        );

        return null;

    }


    try {

        const {
            data,
            error
        } =
            await supabase
                .from(
                    BOOKWORM_PROGRESS_CONFIG.tableName
                )
                .select(`
                    id,
                    user_id,
                    course_code,
                    module_number,
                    progress_percent,
                    is_completed,
                    last_studied_at,
                    completed_at,
                    created_at,
                    updated_at
                `)
                .eq(
                    "user_id",
                    user.id
                )
                .eq(
                    "course_code",
                    normalizedCourse
                )
                .eq(
                    "module_number",
                    normalizedModule
                )
                .maybeSingle();


        if (error) {

            console.error(
                "BOOKWORM PROGRESS: Module query failed.",
                {
                    message: error.message,
                    details: error.details,
                    hint: error.hint,
                    code: error.code
                }
            );

            return null;

        }


        return data || null;

    } catch (error) {

        console.error(
            "BOOKWORM PROGRESS: Module query crashed.",
            error
        );

        return null;

    }

}


/* =========================================================
   SAVE MODULE PROGRESS
========================================================= */

async function saveModuleProgress(
    courseCode,
    moduleNumber,
    progressPercent
) {

    const supabase =
        getProgressSupabaseClient();

    if (!supabase) {
        return null;
    }


    const normalizedCourse =
        normalizeProgressCourseCode(
            courseCode
        );


    const normalizedModule =
        normalizeModuleNumber(
            moduleNumber
        );


    const incomingProgress =
        clampProgress(
            progressPercent
        );


    if (
        !normalizedCourse ||
        !normalizedModule
    ) {

        console.warn(
            "BOOKWORM PROGRESS: Invalid save request.",
            {
                courseCode,
                moduleNumber,
                progressPercent
            }
        );

        return null;

    }


    const user =
        await getProgressCurrentUser();


    if (!user) {

        console.warn(
            "BOOKWORM PROGRESS: Cannot save because no user is authenticated."
        );

        return null;

    }


    try {

        /*
         * Read existing progress.
         */

        const existing =
            await getModuleProgress(
                normalizedCourse,
                normalizedModule
            );


        const existingProgress =
            clampProgress(
                existing?.progress_percent || 0
            );


        const alreadyCompleted =
            existing?.is_completed === true;


        /*
         * Progress never decreases.
         */

        const finalProgress =
            Math.max(
                existingProgress,
                incomingProgress
            );


        const shouldComplete =
            alreadyCompleted ||
            finalProgress >=
                BOOKWORM_PROGRESS_CONFIG
                    .completionThreshold;


        const savedProgress =
            shouldComplete
                ? 100
                : finalProgress;


        const completedAt =
            shouldComplete
                ? (
                    existing?.completed_at ||
                    new Date().toISOString()
                )
                : null;


        const payload = {

            user_id:
                user.id,

            course_code:
                normalizedCourse,

            module_number:
                normalizedModule,

            progress_percent:
                savedProgress,

            is_completed:
                shouldComplete,

            last_studied_at:
                new Date().toISOString(),

            completed_at:
                completedAt

        };


        console.log(
            "BOOKWORM PROGRESS: Saving module progress.",
            payload
        );


        const {
            data,
            error
        } =
            await supabase
                .from(
                    BOOKWORM_PROGRESS_CONFIG.tableName
                )
                .upsert(
                    payload,
                    {
                        onConflict:
                            "user_id,course_code,module_number"
                    }
                )
                .select()
                .single();


        if (error) {

            console.error(
                "BOOKWORM PROGRESS: SAVE FAILED.",
                {
                    message: error.message,
                    details: error.details,
                    hint: error.hint,
                    code: error.code,
                    payload
                }
            );

            return null;

        }


        console.log(
            "BOOKWORM PROGRESS: SAVE SUCCESS.",
            data
        );


        return data || null;

    } catch (error) {

        console.error(
            "BOOKWORM PROGRESS: Save operation crashed.",
            error
        );

        return null;

    }

}


/* =========================================================
   GET ALL USER PROGRESS
========================================================= */

async function getAllProgress() {

    const supabase =
        getProgressSupabaseClient();

    if (!supabase) {

        console.error(
            "BOOKWORM PROGRESS: Cannot load data because Supabase is unavailable."
        );

        return [];

    }


    const user =
        await getProgressCurrentUser();


    if (!user) {

        console.error(
            "BOOKWORM PROGRESS: Cannot load data because no authenticated user exists."
        );

        return [];

    }


    try {

        console.log(
            "BOOKWORM PROGRESS: Loading rows for user:",
            user.id
        );


        const {
            data,
            error
        } =
            await supabase
                .from(
                    BOOKWORM_PROGRESS_CONFIG.tableName
                )
                .select(`
                    id,
                    user_id,
                    course_code,
                    module_number,
                    progress_percent,
                    is_completed,
                    last_studied_at,
                    completed_at,
                    created_at,
                    updated_at
                `)
                .eq(
                    "user_id",
                    user.id
                )
                .order(
                    "last_studied_at",
                    {
                        ascending: false,
                        nullsFirst: false
                    }
                );


        if (error) {

            console.error(
                "BOOKWORM PROGRESS: LOAD FAILED.",
                {
                    message: error.message,
                    details: error.details,
                    hint: error.hint,
                    code: error.code
                }
            );

            return [];

        }


        console.log(
            "BOOKWORM PROGRESS: LOAD SUCCESS.",
            data
        );


        return data || [];

    } catch (error) {

        console.error(
            "BOOKWORM PROGRESS: Retrieval crashed.",
            error
        );

        return [];

    }

}


/* =========================================================
   GET COURSE PROGRESS
========================================================= */

async function getCourseProgress(
    courseCode,
    totalModules
) {

    const normalizedCourse =
        normalizeProgressCourseCode(
            courseCode
        );


    const total =
        Math.max(
            0,
            parseInt(
                totalModules,
                10
            ) || 0
        );


    if (
        !normalizedCourse ||
        total === 0
    ) {

        return {

            courseCode:
                normalizedCourse,

            totalModules:
                total,

            completedModules:
                0,

            progressPercent:
                0

        };

    }


    const progressRows =
        await getAllProgress();


    const courseRows =
        progressRows.filter(
            row =>
                normalizeProgressCourseCode(
                    row.course_code
                ) === normalizedCourse
        );


    const completedModules =
        courseRows.filter(
            row =>
                row.is_completed === true
        ).length;


    const progressPercent =
        Math.round(
            (
                Math.min(
                    completedModules,
                    total
                ) /
                total
            ) * 100
        );


    return {

        courseCode:
            normalizedCourse,

        totalModules:
            total,

        completedModules:
            Math.min(
                completedModules,
                total
            ),

        progressPercent

    };

}


/* =========================================================
   GET OVERALL PROGRESS
========================================================= */

async function getOverallProgress(
    courses
) {

    if (
        !Array.isArray(courses) ||
        courses.length === 0
    ) {

        return {

            totalModules: 0,
            completedModules: 0,
            progressPercent: 0

        };

    }


    const progressRows =
        await getAllProgress();


    let totalModules = 0;

    let completedModules = 0;


    courses.forEach(
        course => {

            const courseTotal =
                Array.isArray(
                    course.modules
                )
                    ? course.modules.length
                    : 0;


            totalModules +=
                courseTotal;


            const courseCode =
                normalizeProgressCourseCode(
                    course.slug ||
                    course.code ||
                    course.id
                );


            if (!courseCode) {
                return;
            }


            completedModules +=
                progressRows.filter(
                    row =>
                        normalizeProgressCourseCode(
                            row.course_code
                        ) === courseCode &&
                        row.is_completed === true
                ).length;

        }
    );


    const progressPercent =
        totalModules === 0
            ? 0
            : Math.round(
                (
                    Math.min(
                        completedModules,
                        totalModules
                    ) /
                    totalModules
                ) * 100
            );


    return {

        totalModules,

        completedModules:
            Math.min(
                completedModules,
                totalModules
            ),

        progressPercent

    };

}


/* =========================================================
   GET RECENTLY STUDIED
========================================================= */

async function getRecentlyStudied(
    limit = 5
) {

    const rows =
        await getAllProgress();


    return rows
        .filter(
            row =>
                row.last_studied_at
        )
        .slice(
            0,
            Math.max(
                1,
                Number(limit) || 5
            )
        );

}


/* =========================================================
   CHECK MODULE COMPLETION
========================================================= */

async function isModuleCompleted(
    courseCode,
    moduleNumber
) {

    const progress =
        await getModuleProgress(
            courseCode,
            moduleNumber
        );


    return (
        progress?.is_completed === true
    );

}


/* =========================================================
   PUBLIC API
========================================================= */

window.BookwormProgress = {

    config:
        BOOKWORM_PROGRESS_CONFIG,

    getCurrentUser:
        getProgressCurrentUser,

    getModuleProgress,

    saveModuleProgress,

    getAllProgress,

    getCourseProgress,

    getOverallProgress,

    getRecentlyStudied,

    isModuleCompleted

};


console.log(
    "BOOKWORM: Progress engine v2 ready."
);