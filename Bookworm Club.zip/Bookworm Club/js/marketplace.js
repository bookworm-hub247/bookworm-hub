/* =========================================================
   BOOKWORM CLUB — MARKETPLACE
   Marketplace + Seller Details + Purchase Preparation
   ========================================================= */


/* =========================================================
   1. SUPABASE CLIENT
   ========================================================= */

/*
   auth-guard.js creates the shared client:

   window.supabaseClient

   We use that same client here.
*/

const marketplaceSupabase =
    window.supabaseClient;


/* =========================================================
   2. GLOBAL STATE
   ========================================================= */

let currentUser = null;

let marketplaceListings = [];

let filteredListings = [];

let sellerProfiles = {};

let selectedListing = null;


/* =========================================================
   3. PAGE ELEMENTS
   ========================================================= */

const listingsContainer =
    document.getElementById(
        "marketplaceListings"
    );

const listingCount =
    document.getElementById(
        "listingCount"
    );

const marketplaceStatus =
    document.getElementById(
        "marketplaceStatus"
    );

const marketplaceSearch =
    document.getElementById(
        "marketplaceSearch"
    );

const marketplaceFilter =
    document.getElementById(
        "marketplaceFilter"
    );


/* Listing modal */

const listingModal =
    document.getElementById(
        "listingModal"
    );

const closeListingModal =
    document.getElementById(
        "closeListingModal"
    );

const listingModalOverlay =
    document.getElementById(
        "listingModalOverlay"
    );


/* Seller modal */

const sellerModal =
    document.getElementById(
        "sellerModal"
    );

const closeSellerModal =
    document.getElementById(
        "closeSellerModal"
    );

const sellerModalOverlay =
    document.getElementById(
        "sellerModalOverlay"
    );


/* Listing modal fields */

const modalListingCategory =
    document.getElementById(
        "modalListingCategory"
    );

const modalListingTitle =
    document.getElementById(
        "modalListingTitle"
    );

const modalListingPrice =
    document.getElementById(
        "modalListingPrice"
    );

const modalListingCourse =
    document.getElementById(
        "modalListingCourse"
    );

const modalSellerName =
    document.getElementById(
        "modalSellerName"
    );

const modalSellerInstitution =
    document.getElementById(
        "modalSellerInstitution"
    );

const modalListingDescription =
    document.getElementById(
        "modalListingDescription"
    );


/* Seller modal fields */

const sellerAvatar =
    document.getElementById(
        "sellerAvatar"
    );

const sellerModalName =
    document.getElementById(
        "sellerModalName"
    );

const sellerModalBio =
    document.getElementById(
        "sellerModalBio"
    );

const sellerModalInstitution =
    document.getElementById(
        "sellerModalInstitution"
    );

const sellerModalDepartment =
    document.getElementById(
        "sellerModalDepartment"
    );

const sellerModalLevel =
    document.getElementById(
        "sellerModalLevel"
    );


/* Buttons */

const contactSellerButton =
    document.getElementById(
        "contactSellerButton"
    );

const purchaseButton =
    document.getElementById(
        "purchaseButton"
    );


/* User display */

const userNameElement =
    document.getElementById(
        "userName"
    );

const userAvatarElement =
    document.getElementById(
        "userAvatar"
    );


/* Empty/error controls */

const emptyState =
    document.getElementById(
        "emptyState"
    );

const clearFiltersButton =
    document.getElementById(
        "clearFiltersButton"
    );

const errorState =
    document.getElementById(
        "errorState"
    );

const errorMessage =
    document.getElementById(
        "errorMessage"
    );

const retryButton =
    document.getElementById(
        "retryButton"
    );


/* =========================================================
   4. INITIALIZATION
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    initializeMarketplace
);


async function initializeMarketplace() {

    console.log(
        "Bookworm Marketplace initializing..."
    );


    if (!marketplaceSupabase) {

        showError(
            "Supabase could not be initialized."
        );

        return;
    }


    try {

        await getCurrentUser();

        updateUserDisplay();

        await loadMarketplace();

        setupSearchAndFilter();

        setupMarketplaceButtons();

        console.log(
            "Bookworm Marketplace initialized successfully."
        );

    } catch (error) {

        console.error(
            "Marketplace initialization failed:",
            error
        );

        showError(
            error.message ||
            "Could not initialize marketplace."
        );
    }
}


/* =========================================================
   5. CURRENT USER
   ========================================================= */

async function getCurrentUser() {

    const {
        data,
        error
    } =
        await marketplaceSupabase.auth.getUser();


    if (error) {

        console.error(
            "Could not get current user:",
            error
        );

        return;
    }


    currentUser =
        data?.user || null;


    if (currentUser) {

        console.log(
            "Marketplace user:",
            currentUser.id
        );

    } else {

        console.warn(
            "No authenticated user found."
        );
    }
}


/* =========================================================
   6. USER DISPLAY
   ========================================================= */

function updateUserDisplay() {

    if (!currentUser) {
        return;
    }


    const metadata =
        currentUser.user_metadata || {};


    const name =
        metadata.full_name ||
        currentUser.email ||
        "Student";


    if (userNameElement) {

        userNameElement.textContent =
            name;
    }


    if (userAvatarElement) {

        userAvatarElement.textContent =
            getInitial(name);
    }
}


/* =========================================================
   7. LOAD MARKETPLACE
   ========================================================= */

async function loadMarketplace() {

    showLoading();


    const {
        data,
        error
    } =
        await marketplaceSupabase
            .from("marketplace_listings")
            .select("*")
            .eq(
                "status",
                "approved"
            )
            .order(
                "created_at",
                {
                    ascending: false
                }
            );


    if (error) {

        console.error(
            "Marketplace listings error:",
            error
        );

        showError(
            error.message ||
            "Could not load marketplace."
        );

        return;
    }


    marketplaceListings =
        data || [];


    await loadSellerProfiles();


    filteredListings =
        [...marketplaceListings];


    setupCategories();

    renderListings();
}


/* =========================================================
   8. LOAD SELLER PROFILES
   ========================================================= */

async function loadSellerProfiles() {

    sellerProfiles = {};


    const sellerIds =
        [
            ...new Set(
                marketplaceListings
                    .map(
                        listing =>
                            listing.seller_id
                    )
                    .filter(Boolean)
            )
        ];


    if (!sellerIds.length) {
        return;
    }


    const {
        data,
        error
    } =
        await marketplaceSupabase
            .from("marketplace_sellers")
            .select("*")
            .in(
                "id",
                sellerIds
            );


    if (error) {

        console.error(
            "Seller profile error:",
            error
        );

        return;
    }


    (data || []).forEach(
        seller => {

            sellerProfiles[
                seller.id
            ] = seller;
        }
    );
}


/* =========================================================
   9. CATEGORY FILTER
   ========================================================= */

function setupCategories() {

    if (!marketplaceFilter) {
        return;
    }


    const categories =
        [
            ...new Set(
                marketplaceListings
                    .map(
                        listing =>
                            listing.category
                    )
                    .filter(Boolean)
            )
        ];


    marketplaceFilter.innerHTML = `
        <option value="">
            All categories
        </option>
    `;


    categories.forEach(
        category => {

            const option =
                document.createElement(
                    "option"
                );


            option.value =
                category;


            option.textContent =
                formatCategory(
                    category
                );


            marketplaceFilter.appendChild(
                option
            );
        }
    );
}


/* =========================================================
   10. SEARCH + FILTER
   ========================================================= */

function setupSearchAndFilter() {

    marketplaceSearch?.addEventListener(
        "input",
        filterMarketplace
    );


    marketplaceFilter?.addEventListener(
        "change",
        filterMarketplace
    );


    clearFiltersButton?.addEventListener(
        "click",
        clearFilters
    );


    retryButton?.addEventListener(
        "click",
        loadMarketplace
    );
}


function filterMarketplace() {

    const search =
        (
            marketplaceSearch?.value ||
            ""
        )
            .toLowerCase()
            .trim();


    const category =
        marketplaceFilter?.value ||
        "";


    filteredListings =
        marketplaceListings.filter(
            listing => {

                const seller =
                    sellerProfiles[
                        listing.seller_id
                    ] || {};


                const sellerName =
                    seller.display_name ||
                    "";


                const searchableText =
                    [
                        listing.title,
                        listing.description,
                        listing.category,
                        listing.course_code,
                        sellerName
                    ]
                        .filter(Boolean)
                        .join(" ")
                        .toLowerCase();


                const matchesSearch =
                    !search ||
                    searchableText.includes(
                        search
                    );


                const matchesCategory =
                    !category ||
                    listing.category ===
                        category;


                return (
                    matchesSearch &&
                    matchesCategory
                );
            }
        );


    renderListings();
}


/* =========================================================
   11. CLEAR FILTERS
   ========================================================= */

function clearFilters() {

    if (marketplaceSearch) {

        marketplaceSearch.value =
            "";
    }


    if (marketplaceFilter) {

        marketplaceFilter.value =
            "";
    }


    filteredListings =
        [...marketplaceListings];


    renderListings();
}


/* =========================================================
   12. RENDER LISTINGS
   ========================================================= */

function renderListings() {

    if (!listingsContainer) {
        return;
    }


    hideEmptyAndError();


    updateListingCount(
        filteredListings.length
    );


    if (!filteredListings.length) {

        listingsContainer.innerHTML =
            "";


        if (emptyState) {

            emptyState.classList.remove(
                "hidden"
            );
        }


        return;
    }


    listingsContainer.innerHTML =
        filteredListings
            .map(
                createListingCard
            )
            .join("");
}


/* =========================================================
   13. LISTING CARD
   ========================================================= */

function createListingCard(
    listing
) {

    const seller =
        sellerProfiles[
            listing.seller_id
        ] || {};


    const sellerName =
        seller.display_name ||
        "Bookworm Seller";


    const initial =
        getInitial(
            sellerName
        );


    return `
        <article
            class="listing-card marketplace-card"
            data-listing-id="${escapeAttribute(
                listing.id
            )}"
        >

            <div class="listing-top">

                <span class="listing-category">

                    ${escapeHTML(
                        formatCategory(
                            listing.category
                        )
                    )}

                </span>


                <span class="listing-price">

                    ${formatPrice(
                        listing.price
                    )}

                </span>

            </div>


            <h3>
                ${escapeHTML(
                    listing.title
                )}
            </h3>


            <div class="listing-course">

                ${escapeHTML(
                    listing.course_code ||
                    "Academic Resource"
                )}

            </div>


            <p class="listing-description">

                ${escapeHTML(
                    listing.description ||
                    "Academic resource."
                )}

            </p>


            <div class="listing-footer">

                <div class="seller-info-small">

                    <div class="seller-mini-avatar">

                        ${escapeHTML(
                            initial
                        )}

                    </div>


                    <div class="seller-text">

                        <strong>

                            ${escapeHTML(
                                sellerName
                            )}

                        </strong>


                        <span>

                            ${
                                seller.is_verified
                                    ? "Verified seller"
                                    : "Bookworm seller"
                            }

                        </span>

                    </div>

                </div>


                <button
                    type="button"
                    class="view-listing-button"
                    data-view-listing="${escapeAttribute(
                        listing.id
                    )}"
                >
                    View
                </button>

            </div>

        </article>
    `;
}


/* =========================================================
   14. MARKETPLACE BUTTONS
   ========================================================= */

function setupMarketplaceButtons() {

    listingsContainer?.addEventListener(
        "click",
        handleListingClick
    );


    closeListingModal?.addEventListener(
        "click",
        () =>
            closeModal(
                listingModal
            )
    );


    listingModalOverlay?.addEventListener(
        "click",
        () =>
            closeModal(
                listingModal
            )
    );


    closeSellerModal?.addEventListener(
        "click",
        () =>
            closeModal(
                sellerModal
            )
    );


    sellerModalOverlay?.addEventListener(
        "click",
        () =>
            closeModal(
                sellerModal
            )
    );


    contactSellerButton?.addEventListener(
        "click",
        openSelectedSeller
    );


    purchaseButton?.addEventListener(
        "click",
        preparePurchase
    );


    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key ===
                "Escape"
            ) {

                closeModal(
                    listingModal
                );

                closeModal(
                    sellerModal
                );
            }
        }
    );
}


/* =========================================================
   15. LISTING CLICK
   ========================================================= */

function handleListingClick(
    event
) {

    const button =
        event.target.closest(
            "[data-view-listing]"
        );


    if (!button) {
        return;
    }


    const listingId =
        button.dataset.viewListing;


    viewListing(
        listingId
    );
}


/* =========================================================
   16. VIEW LISTING
   ========================================================= */

function viewListing(
    listingId
) {

    selectedListing =
        marketplaceListings.find(
            listing =>
                listing.id ===
                listingId
        );


    if (!selectedListing) {
        return;
    }


    const seller =
        sellerProfiles[
            selectedListing.seller_id
        ] || {};


    setText(
        modalListingCategory,
        formatCategory(
            selectedListing.category
        )
    );


    setText(
        modalListingTitle,
        selectedListing.title
    );


    setText(
        modalListingPrice,
        formatPrice(
            selectedListing.price
        )
    );


    setText(
        modalListingCourse,
        selectedListing.course_code ||
            "Academic Resource"
    );


    setText(
        modalSellerName,
        seller.display_name ||
            "Bookworm Seller"
    );


    setText(
        modalSellerInstitution,
        seller.institution ||
            "Not provided"
    );


    setText(
        modalListingDescription,
        selectedListing.description ||
            "No description provided."
    );


    /*
       Purchase button state.
    */

    if (purchaseButton) {

        if (
            Number(
                selectedListing.price
            ) === 0
        ) {

            purchaseButton.textContent =
                "Get Resource";

        } else {

            purchaseButton.textContent =
                `Purchase — ${formatPrice(
                    selectedListing.price
                )}`;
        }


        purchaseButton.disabled =
            false;
    }


    openModal(
        listingModal
    );
}


/* =========================================================
   17. VIEW SELLER
   ========================================================= */

function openSelectedSeller() {

    if (!selectedListing) {
        return;
    }


    const seller =
        sellerProfiles[
            selectedListing.seller_id
        ] || {};


    const name =
        seller.display_name ||
        "Bookworm Seller";


    setText(
        sellerModalName,
        name
    );


    setText(
        sellerModalBio,
        seller.bio ||
            "No seller bio available."
    );


    setText(
        sellerModalInstitution,
        seller.institution ||
            "Not provided"
    );


    setText(
        sellerModalDepartment,
        seller.department ||
            "Not provided"
    );


    setText(
        sellerModalLevel,
        seller.level ||
            "Not provided"
    );


    if (sellerAvatar) {

        sellerAvatar.textContent =
            getInitial(name);
    }


    closeModal(
        listingModal
    );


    openModal(
        sellerModal
    );
}


/* =========================================================
   18. PURCHASE PREPARATION
   ========================================================= */

async function preparePurchase() {

    if (!selectedListing) {

        return;
    }


    if (!currentUser) {

        alert(
            "Please log in before purchasing a resource."
        );

        return;
    }


    const price =
        Number(
            selectedListing.price
        );


    /*
       Free resources do not need Paystack.
    */

    if (price === 0) {

        alert(
            "This resource is free. Secure resource access will be connected in the next step."
        );

        return;
    }


    /*
       Check whether the student has
       already purchased this resource.

       We only READ purchase records here.

       We do NOT create a paid purchase
       from the browser.
    */

    try {

        const {
            data,
            error
        } =
            await marketplaceSupabase
                .from(
                    "marketplace_purchases"
                )
                .select(
                    "id, payment_status"
                )
                .eq(
                    "buyer_id",
                    currentUser.id
                )
                .eq(
                    "listing_id",
                    selectedListing.id
                )
                .maybeSingle();


        if (error) {

            console.error(
                "Purchase lookup error:",
                error
            );


            /*
               If RLS prevents the query,
               we stop instead of making
               assumptions about payment.
            */

            alert(
                "We could not check your purchase status. Please try again."
            );

            return;
        }


        if (
            data?.payment_status ===
            "paid"
        ) {

            alert(
                "You have already purchased this resource. Secure access will be connected next."
            );

            return;
        }


        /*
           Paystack will be connected here
           in the next payment phase.
        */

        alert(
            `Purchase selected.\n\n` +
            `Resource: ${selectedListing.title}\n` +
            `Amount: ${formatPrice(price)}\n\n` +
            `Secure Paystack checkout will be connected next.`
        );


    } catch (error) {

        console.error(
            "Purchase preparation failed:",
            error
        );


        alert(
            "Something went wrong while preparing the purchase."
        );
    }
}


/* =========================================================
   19. MODAL HELPERS
   ========================================================= */

function openModal(
    modal
) {

    if (!modal) {
        return;
    }


    modal.classList.remove(
        "hidden"
    );


    modal.setAttribute(
        "aria-hidden",
        "false"
    );


    document.body.style.overflow =
        "hidden";
}


function closeModal(
    modal
) {

    if (!modal) {
        return;
    }


    modal.classList.add(
        "hidden"
    );


    modal.setAttribute(
        "aria-hidden",
        "true"
    );


    document.body.style.overflow =
        "";
}


/* =========================================================
   20. LOADING
   ========================================================= */

function showLoading() {

    if (!listingsContainer) {
        return;
    }


    hideEmptyAndError();


    listingsContainer.innerHTML = `
        <div class="loading-card">

            <div class="loading-spinner"></div>

            <span>
                Loading marketplace...
            </span>

        </div>
    `;


    if (marketplaceStatus) {

        marketplaceStatus.textContent =
            "Loading marketplace...";
    }
}


/* =========================================================
   21. ERROR
   ========================================================= */

function showError(
    message
) {

    if (listingsContainer) {

        listingsContainer.innerHTML =
            "";
    }


    if (errorState) {

        errorState.classList.remove(
            "hidden"
        );
    }


    if (errorMessage) {

        errorMessage.textContent =
            message;
    }


    if (marketplaceStatus) {

        marketplaceStatus.textContent =
            "Marketplace unavailable";
    }
}


/* =========================================================
   22. HIDE STATES
   ========================================================= */

function hideEmptyAndError() {

    emptyState?.classList.add(
        "hidden"
    );

    errorState?.classList.add(
        "hidden"
    );
}


/* =========================================================
   23. TEXT HELPER
   ========================================================= */

function setText(
    element,
    value
) {

    if (!element) {
        return;
    }


    element.textContent =
        value ?? "";
}


/* =========================================================
   24. PRICE FORMAT
   ========================================================= */

function formatPrice(
    price
) {

    const amount =
        Number(price);


    if (
        !Number.isFinite(
            amount
        )
    ) {

        return "Price unavailable";
    }


    if (amount === 0) {

        return "Free";
    }


    return new Intl.NumberFormat(
        "en-NG",
        {
            style: "currency",
            currency: "NGN",
            maximumFractionDigits: 0
        }
    ).format(amount);
}


/* =========================================================
   25. CATEGORY FORMAT
   ========================================================= */

function formatCategory(
    category
) {

    if (!category) {

        return "Academic Resource";
    }


    return String(category)
        .replace(
            /[-_]/g,
            " "
        )
        .replace(
            /\b\w/g,
            letter =>
                letter.toUpperCase()
        );
}


/* =========================================================
   26. INITIAL
   ========================================================= */

function getInitial(
    value
) {

    const text =
        String(
            value || "S"
        ).trim();


    return (
        text.charAt(0)
            .toUpperCase() ||
        "S"
    );
}


/* =========================================================
   27. LISTING COUNT
   ========================================================= */

function updateListingCount(
    count
) {

    if (!listingCount) {
        return;
    }


    listingCount.textContent =
        `${count} ${
            count === 1
                ? "listing"
                : "listings"
        }`;
}


/* =========================================================
   28. SECURITY HELPERS
   ========================================================= */

function escapeHTML(
    value
) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}


function escapeAttribute(
    value
) {

    return escapeHTML(
        value
    );
}


/* =========================================================
   29. DEBUG ACCESS
   ========================================================= */

window.BookwormMarketplace = {

    reload:
        loadMarketplace,

    getUser:
        () =>
            currentUser,

    getListings:
        () =>
            marketplaceListings,

    getSelectedListing:
        () =>
            selectedListing

};


console.log(
    "Bookworm Marketplace ready."
);