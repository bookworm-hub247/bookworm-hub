/* =========================================================
   BOOKWORM CLUB — SELL RESOURCE
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    initializeSellResource
);


/* =========================================================
   GLOBAL STATE
========================================================= */

let currentSeller = null;


/* =========================================================
   SUPABASE
========================================================= */

const sellResourceSupabase =
    window.supabaseClient;


if (!sellResourceSupabase) {

    console.error(
        "Bookworm Club: Supabase client unavailable."
    );

}


/* =========================================================
   ELEMENTS
========================================================= */

const resourceForm =
    document.getElementById(
        "resourceForm"
    );

const resourceFile =
    document.getElementById(
        "resourceFile"
    );

const selectedFile =
    document.getElementById(
        "selectedFile"
    );

const submitResource =
    document.getElementById(
        "submitResource"
    );

const uploadStatus =
    document.getElementById(
        "uploadStatus"
    );


/* =========================================================
   INITIALIZE
========================================================= */

async function initializeSellResource() {

    if (!sellResourceSupabase) {

        showStatus(
            "Supabase is not connected.",
            "error"
        );

        return;
    }


    try {

        const {
            data: {
                user
            },
            error
        } =
            await sellResourceSupabase
                .auth
                .getUser();


        if (error) {

            throw error;

        }


        if (!user) {

            window.location.href =
                "login.html";

            return;
        }


        currentSeller =
            user;


        console.log(
            "Sell Resource: authenticated."
        );


    } catch (error) {

        console.error(
            "Seller authentication error:",
            error
        );


        showStatus(
            "Unable to verify your account.",
            "error"
        );

    }

}


/* =========================================================
   FILE SELECTION
========================================================= */

if (resourceFile) {

    resourceFile.addEventListener(
        "change",
        function () {

            const file =
                resourceFile.files[0];


            if (!file) {

                if (selectedFile) {

                    selectedFile.textContent =
                        "No file selected";

                }

                return;
            }


            /* =============================================
               PDF CHECK
            ============================================== */

            if (
                file.type !==
                "application/pdf"
            ) {

                if (selectedFile) {

                    selectedFile.textContent =
                        "Invalid file. Please select a PDF.";

                }

                resourceFile.value = "";

                return;
            }


            /* =============================================
               SIZE CHECK
            ============================================== */

            const maxSize =
                20 * 1024 * 1024;


            if (
                file.size >
                maxSize
            ) {

                if (selectedFile) {

                    selectedFile.textContent =
                        "File is too large. Maximum size is 20MB.";

                }

                resourceFile.value = "";

                return;
            }


            /* =============================================
               DISPLAY FILE
            ============================================== */

            const sizeMB =
                (
                    file.size /
                    (1024 * 1024)
                ).toFixed(2);


            if (selectedFile) {

                selectedFile.textContent =
                    `${file.name} • ${sizeMB} MB`;

            }

        }
    );

}


/* =========================================================
   STATUS MESSAGE
========================================================= */

function showStatus(
    message,
    type = ""
) {

    if (!uploadStatus) {

        console.log(
            message
        );

        return;
    }


    uploadStatus.hidden =
        false;


    uploadStatus.textContent =
        message;


    uploadStatus.className =
        `upload-status ${type}`;

}


/* =========================================================
   GET FORM VALUE
========================================================= */

function getValue(
    id
) {

    const element =
        document.getElementById(
            id
        );


    if (!element) {

        return "";

    }


    return element.value.trim();

}


/* =========================================================
   SUBMIT RESOURCE
========================================================= */

if (resourceForm) {

    resourceForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            /* =============================================
               SUPABASE CHECK
            ============================================== */

            if (!sellResourceSupabase) {

                showStatus(
                    "Supabase is not connected.",
                    "error"
                );

                return;

            }


            let createdListingId =
                null;

            let uploadedFilePath =
                null;


            try {

                /* =========================================
                   VERIFY USER
                ========================================== */

                if (!currentSeller) {

                    const {
                        data: {
                            user
                        },
                        error
                    } =
                        await sellResourceSupabase
                            .auth
                            .getUser();


                    if (error) {

                        throw error;

                    }


                    if (!user) {

                        window.location.href =
                            "login.html";

                        return;

                    }


                    currentSeller =
                        user;

                }


                /* =========================================
                   FORM DATA
                ========================================== */

                const title =
                    getValue(
                        "resourceTitle"
                    );


                const category =
                    getValue(
                        "resourceCategory"
                    );


                const courseCode =
                    getValue(
                        "courseCode"
                    ).toUpperCase();


                const description =
                    getValue(
                        "resourceDescription"
                    );


                const priceInput =
                    document.getElementById(
                        "resourcePrice"
                    );


                const price =
                    Number(
                        priceInput
                            ? priceInput.value
                            : 0
                    );


                const file =
                    resourceFile
                        ? resourceFile.files[0]
                        : null;


                /* =========================================
                   VALIDATION
                ========================================== */

                if (!title) {

                    throw new Error(
                        "Please enter a resource title."
                    );

                }


                if (!file) {

                    throw new Error(
                        "Please select a PDF resource."
                    );

                }


                if (
                    file.type !==
                    "application/pdf"
                ) {

                    throw new Error(
                        "Only PDF files are allowed."
                    );

                }


                if (
                    file.size >
                    20 * 1024 * 1024
                ) {

                    throw new Error(
                        "The PDF must be 20MB or smaller."
                    );

                }


                if (
                    Number.isNaN(price) ||
                    price < 0
                ) {

                    throw new Error(
                        "Please enter a valid price."
                    );

                }


                /* =========================================
                   DISABLE BUTTON
                ========================================== */

                if (submitResource) {

                    submitResource.disabled =
                        true;

                    submitResource.textContent =
                        "Creating listing...";

                }


                showStatus(
                    "Creating marketplace listing...",
                    "loading"
                );


                /* =========================================
                   CREATE DATABASE RECORD
                ========================================== */

                const {
                    data: listing,
                    error: listingError
                } =
                    await sellResourceSupabase
                        .from(
                            "marketplace_listings"
                        )
                        .insert({

                            seller_id:
                                currentSeller.id,

                            title:
                                title,

                            description:
                                description,

                            category:
                                category,

                            course_code:
                                courseCode ||
                                null,

                            price:
                                price,

                            status:
                                "pending"

                        })
                        .select()
                        .single();


                if (listingError) {

                    throw listingError;

                }


                createdListingId =
                    listing.id;


                /* =========================================
                   UPLOAD PDF
                ========================================== */

                if (submitResource) {

                    submitResource.textContent =
                        "Uploading PDF...";

                }


                showStatus(
                    "Uploading PDF...",
                    "loading"
                );


                const safeFileName =
                    file.name
                        .replace(
                            /[^a-zA-Z0-9._-]/g,
                            "-"
                        );


                const filePath =
                    `${currentSeller.id}/${Date.now()}-${safeFileName}`;


                uploadedFilePath =
                    filePath;


                const {
                    error: uploadError
                } =
                    await sellResourceSupabase
                        .storage
                        .from(
                            "marketplace-resources"
                        )
                        .upload(
                            filePath,
                            file,
                            {
                                contentType:
                                    "application/pdf",

                                upsert:
                                    false
                            }
                        );


                if (uploadError) {

                    throw new Error(
                        `PDF upload failed: ${uploadError.message}`
                    );

                }


                /* =========================================
                   GET PUBLIC URL
                ========================================== */

                const {
                    data:
                        publicUrlData
                } =
                    sellResourceSupabase
                        .storage
                        .from(
                            "marketplace-resources"
                        )
                        .getPublicUrl(
                            filePath
                        );


                const fileUrl =
                    publicUrlData?.publicUrl ||
                    "";


                if (!fileUrl) {

                    throw new Error(
                        "The PDF uploaded, but its public URL could not be created."
                    );

                }


                /* =========================================
                   UPDATE DATABASE RECORD
                ========================================== */

                showStatus(
                    "Finalizing resource listing...",
                    "loading"
                );


                const {
                    error:
                        updateError
                } =
                    await sellResourceSupabase
                        .from(
                            "marketplace_listings"
                        )
                        .update({

                            file_url:
                                fileUrl

                        })
                        .eq(
                            "id",
                            createdListingId
                        );


                if (updateError) {

                    throw updateError;

                }


                /* =========================================
                   SUCCESS
                ========================================== */

                showStatus(
                    "Resource submitted successfully. It is now awaiting approval.",
                    "success"
                );


                resourceForm.reset();


                if (selectedFile) {

                    selectedFile.textContent =
                        "No file selected";

                }


            } catch (error) {

                console.error(
                    "Sell resource error:",
                    error
                );


                /* =========================================
                   CLEAN UP FAILED UPLOAD
                ========================================== */

                if (uploadedFilePath) {

                    const {
                        error:
                            storageCleanupError
                    } =
                        await sellResourceSupabase
                            .storage
                            .from(
                                "marketplace-resources"
                            )
                            .remove([
                                uploadedFilePath
                            ]);


                    if (storageCleanupError) {

                        console.error(
                            "Storage cleanup error:",
                            storageCleanupError
                        );

                    }

                }


                /* =========================================
                   CLEAN UP DATABASE RECORD
                ========================================== */

                if (createdListingId) {

                    const {
                        error:
                            databaseCleanupError
                    } =
                        await sellResourceSupabase
                            .from(
                                "marketplace_listings"
                            )
                            .delete()
                            .eq(
                                "id",
                                createdListingId
                            );


                    if (databaseCleanupError) {

                        console.error(
                            "Database cleanup error:",
                            databaseCleanupError
                        );

                    }

                }


                showStatus(
                    error.message ||
                    "Something went wrong while submitting the resource.",
                    "error"
                );


            } finally {

                if (submitResource) {

                    submitResource.disabled =
                        false;

                    submitResource.textContent =
                        "Submit Resource";

                }

            }

        }
    );

}