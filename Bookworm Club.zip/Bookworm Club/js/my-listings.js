/* =========================================================
   BOOKWORM CLUB — MY LISTINGS
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    initializeMyListings
);


let currentSeller = null;
let myListings = [];


/* =========================================================
   INITIALIZE
========================================================= */

async function initializeMyListings() {

    console.log("Bookworm My Listings loading...");


    const supabaseClient =
        window.supabaseClient;


    if (!supabaseClient) {

        console.error(
            "Supabase client unavailable."
        );

        return;
    }


    /* =====================================================
       GET CURRENT USER
    ===================================================== */

    const {
        data: {
            user
        },
        error
    } =
        await supabaseClient.auth.getUser();


    if (error) {

        console.error(
            "Authentication error:",
            error
        );

        return;
    }


    if (!user) {

        window.location.href =
            "login.html";

        return;
    }


    currentSeller = user;


    await loadMyListings(
        supabaseClient
    );

}


/* =========================================================
   LOAD MY LISTINGS
========================================================= */

async function loadMyListings(
    supabaseClient
) {

    const container =
        document.getElementById(
            "myListings"
        );


    if (!container) {

        console.error(
            "#myListings was not found."
        );

        return;
    }


    container.innerHTML =
        "<p>Loading your listings...</p>";


    const {
        data,
        error
    } =
        await supabaseClient
            .from("marketplace_listings")
            .select("*")
            .eq(
                "seller_id",
                currentSeller.id
            )
            .order(
                "created_at",
                {
                    ascending: false
                }
            );


    if (error) {

        console.error(
            "My listings error:",
            error
        );

        container.innerHTML = `
            <div class="empty-state">

                <h3>
                    Unable to load listings
                </h3>

                <p>
                    ${escapeHTML(error.message)}
                </p>

            </div>
        `;

        return;
    }


    myListings =
        data || [];


    renderListings(
        container
    );

}


/* =========================================================
   RENDER LISTINGS
========================================================= */

function renderListings(
    container
) {

    if (
        !myListings.length
    ) {

        container.innerHTML = `
            <div class="empty-state">

                <h3>
                    No listings yet
                </h3>

                <p>
                    Resources you list for sale
                    will appear here.
                </p>

                <a
                    href="sell-resource.html"
                    class="primary-button"
                >
                    Sell a Resource
                </a>

            </div>
        `;

        return;
    }


    container.innerHTML =
        myListings
            .map(
                function (listing) {

                    return `
                        <article class="listing-card">

                            <div class="listing-content">

                                <span class="listing-category">
                                    ${escapeHTML(
                                        listing.category ||
                                        "Resource"
                                    )}
                                </span>

                                <h3>
                                    ${escapeHTML(
                                        listing.title ||
                                        "Untitled Resource"
                                    )}
                                </h3>

                                <p>
                                    ${escapeHTML(
                                        listing.description ||
                                        "No description provided."
                                    )}
                                </p>

                                <strong>
                                    ₦${formatPrice(
                                        listing.price
                                    )}
                                </strong>

                                <small>
                                    Status:
                                    ${escapeHTML(
                                        listing.status ||
                                        "pending"
                                    )}
                                </small>

                            </div>

                        </article>
                    `;

                }
            )
            .join("");

}


/* =========================================================
   FORMAT PRICE
========================================================= */

function formatPrice(
    value
) {

    const number =
        Number(value);


    if (
        Number.isNaN(number)
    ) {

        return "0";

    }


    return number.toLocaleString(
        "en-NG"
    );

}


/* =========================================================
   SECURITY — ESCAPE HTML
========================================================= */

function escapeHTML(
    value
) {

    return String(value ?? "")
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}