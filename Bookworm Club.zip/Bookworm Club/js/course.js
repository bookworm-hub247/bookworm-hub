/* =========================================================
   BOOKWORM CLUB — COURSE SYSTEM
   200 LEVEL • FIRST SEMESTER
========================================================= */

"use strict";


/* =========================================================
   COURSE DATABASE
========================================================= */

const courses = {

    GST212: {

        code: "GST 212",

        name:
            "Philosophy, Logic and Human Existence",

        department:
            "General Studies",

        units: 2,

        modules: [

            "Introduction to Philosophy",

            "Logic and Critical Thinking",

            "Human Existence",

            "Major Philosophical Questions"

        ]

    },


    ENT211: {

        code: "ENT 211",

        name:
            "Entrepreneurship and Innovation",

        department:
            "General Studies",

        units: 2,

        modules: [

            "Introduction to Entrepreneurship",

            "Entrepreneurial Skills and Characteristics",

            "Innovation and Creativity",

            "Business Opportunities and Idea Development"

        ]

    },


    EDU201: {

        code: "EDU 201",

        name:
            "Curriculum, Curriculum Delivery and General Teaching Methods",

        department:
            "Education",

        units: 2,

        modules: [

            "Introduction to Curriculum",

            "Curriculum Development",

            "Curriculum Delivery",

            "General Teaching Methods"

        ]

    },


    UNIBENEDU211: {

        code: "EDU 211",

        name:
            "Developmental Psychology",

        department:
            "Education",

        units: 2,

        modules: [

            "Introduction to Developmental Psychology",

            "Theories of Human Development",

            "Physical and Cognitive Development",

            "Social and Emotional Development"

        ]

    },


    UNIBENEDU212: {

        code: "EDU 212",

        name:
            "Philosophy of Education",

        department:
            "Education",

        units: 2,

        modules: [

            "Introduction to Philosophy of Education",

            "Major Schools of Educational Philosophy",

            "Education and Society",

            "Aims and Values of Education"

        ]

    },


    ENG201: {

        code: "ENG 201",

        name:
            "An Introduction to Morphology and Syntax",

        department:
            "English",

        units: 2,

        modules: [

            "Introduction to Morphology",

            "Morphemes and Word Formation",

            "Introduction to Syntax",

            "Phrases, Clauses and Sentences"

        ]

    },


    ENG203: {

        code: "ENG 203",

        name:
            "Introduction to General Phonetics and Phonology I",

        department:
            "English",

        units: 2,

        modules: [

            "Introduction to Phonetics",

            "Speech Organs and Articulation",

            "English Vowels",

            "English Consonants"

        ]

    },


    ENG205: {

        code: "ENG 205",

        name:
            "Advanced English Composition I",

        department:
            "English",

        units: 2,

        modules: [

            "Principles of Effective Writing",

            "Paragraph Development",

            "Essay Structure and Organisation",

            "Academic Writing"

        ]

    },


    UNIBENENL210: {

        code: "ENL 210",

        name:
            "A Survey of English Literature from Anglo-Saxon to the Elizabethan Period",

        department:
            "English / Literature",

        units: 2,

        modules: [

            "Introduction to English Literature",

            "Anglo-Saxon Literature",

            "Middle English Literature",

            "Elizabethan Literature"

        ]

    },


    LAS244: {

        code: "LAS 244",

        name:
            "Method I – Teaching Grammar, Lexis & Oracy Skills",

        department:
            "Language Education",

        units: 2,

        modules: [

            "Introduction to Language Teaching",

            "Teaching Grammar",

            "Teaching Lexis",

            "Teaching Oracy Skills"

        ]

    }

};


/* =========================================================
   PUBLISHED LESSONS
========================================================= */

const publishedLessons = {

    GST212: [
        "01",
        "02",
        "03",
        "04"
    ],

    ENG201: [
        "01",
        "02",
        "03",
        "04"
    ],

    ENT211: [
        "01",
        "02",
        "03",
        "04"
    ],

    EDU201: [
        "01",
        "02",
        "03",
        "04"
    ]

};


/* =========================================================
   URL
========================================================= */

const urlParams =
    new URLSearchParams(
        window.location.search
    );


const rawCourseSlug =
    urlParams.get("course") || "";


/* =========================================================
   NORMALISE SLUG
========================================================= */

function normalizeCourseSlug(value) {

    return String(value)

        .trim()

        .toUpperCase()

        .replace(
            /\s+/g,
            ""
        );

}


const normalizedSlug =
    normalizeCourseSlug(
        rawCourseSlug
    );


/* =========================================================
   SELECTED COURSE
========================================================= */

const course =
    courses[normalizedSlug];


/* =========================================================
   INITIALISE
========================================================= */


document.addEventListener(
    "DOMContentLoaded",
    async () => {

        if (!course) {

            return;

        }


        /* -----------------------------------------
           WAIT FOR PREMIUM DATABASE CHECK
        ----------------------------------------- */

        if (
            window.BookwormPremium?.ready
        ) {

            await BookwormPremium.ready;

        }


        renderCourse();

    }
);


/* =========================================================
   RENDER COURSE
========================================================= */

function renderCourse() {

    const courseCode =
        document.getElementById(
            "courseCode"
        );


    const courseTitle =
        document.getElementById(
            "courseTitle"
        );


    const courseDepartment =
        document.getElementById(
            "courseDepartment"
        );


    const courseDescription =
        document.getElementById(
            "courseDescription"
        );


    const courseModules =
        document.getElementById(
            "courseModules"
        );


    if (courseCode) {

        courseCode.textContent =
            course.code;

    }


    if (courseTitle) {

        courseTitle.textContent =
            course.name;

    }


    if (courseDepartment) {

        courseDepartment.textContent =
            `${course.department} • ${course.units} Units`;

    }


    if (courseDescription) {

        courseDescription.textContent =
            `Study ${course.name} through structured topics, lesson notes, academic resources and past-question practice.`;

    }


    document.title =
        `${course.code} | Bookworm Club`;


    renderPremiumCourseHeader();


    renderModules(
        courseModules
    );


    renderLearningSummary();

}


/* =========================================================
   PREMIUM COURSE HEADER
========================================================= */

function renderPremiumCourseHeader() {

    if (
        !window.BookwormPremium
    ) {

        return;

    }


    const isPremium =
        BookwormPremium.isPremiumCourse(
            normalizedSlug
        );


    if (!isPremium) {

        return;

    }


    const header =
        document.querySelector(
            ".course-detail-header"
        );


    if (!header) {

        return;

    }


    const alreadyExists =
        document.getElementById(
            "premiumCourseBadge"
        );


    if (alreadyExists) {

        return;

    }


    const badge =
        document.createElement(
            "div"
        );


    badge.id =
        "premiumCourseBadge";


    badge.className =
        "premium-course-banner";


    const unlocked =
        BookwormPremium.isPremium();


    if (unlocked) {

        badge.innerHTML = `

            <div class="premium-banner-icon">
                ✓
            </div>

            <div>

                <strong>
                    Premium Access Active
                </strong>

                <span>
                    You have full access to this course.
                </span>

            </div>

        `;

    } else {

        badge.innerHTML = `

            <div class="premium-banner-icon">
                ◆
            </div>

            <div>

                <strong>
                    Premium Course
                </strong>

                <span>
                    Topic 01 is free. Unlock all 200L
                    first-semester premium courses for ₦500.
                </span>

            </div>

        `;

    }


    header.appendChild(
        badge
    );

}


/* =========================================================
   LEARNING SUMMARY
========================================================= */

function renderLearningSummary() {

    const published =
        publishedLessons[
            normalizedSlug
        ] || [];


    const totalModules =
        course.modules.length;


    const availableModules =
        published.length;


    const progressElement =
        document.getElementById(
            "courseProgress"
        );


    const progressFill =
        document.getElementById(
            "progressFill"
        );


    if (
        !progressElement ||
        !progressFill
    ) {

        return;

    }


    const availability =
        totalModules === 0

            ? 0

            : Math.round(
                (
                    availableModules /
                    totalModules
                ) * 100
            );


    progressElement.textContent =
        `${availability}%`;


    progressFill.style.width =
        `${availability}%`;

}


/* =========================================================
   RENDER MODULES
========================================================= */

function renderModules(
    container
) {

    if (!container) {

        return;

    }


    container.innerHTML =
        "";


    const published =
        publishedLessons[
            normalizedSlug
        ] || [];


    course.modules.forEach(
        function(
            moduleTitle,
            index
        ) {

            const moduleNumber =
                index + 1;


            const moduleString =
                String(
                    moduleNumber
                ).padStart(
                    2,
                    "0"
                );


            const isPublished =
                published.includes(
                    moduleString
                );


            const isPremium =
                window.BookwormPremium &&
                BookwormPremium.isPremiumCourse(
                    normalizedSlug
                );


            const hasModuleAccess =
                window.BookwormPremium

                    ? BookwormPremium.canAccessModule(
                        normalizedSlug,
                        moduleNumber
                    )

                    : true;


            const moduleCard =
                document.createElement(
                    "article"
                );


            moduleCard.className =
                "course-module";


            /* -----------------------------------------
               UPCOMING
            ----------------------------------------- */

            if (!isPublished) {

                moduleCard.dataset.status =
                    "upcoming";


                moduleCard.innerHTML = `

                    <div class="module-number">
                        ${moduleString}
                    </div>

                    <div class="module-content">

                        <span class="module-status">
                            COMING SOON
                        </span>

                        <h3>
                            ${escapeHTML(
                                moduleTitle
                            )}
                        </h3>

                        <p>
                            This learning module is being
                            prepared for the Bookworm library.
                        </p>

                    </div>

                    <span
                        class="module-button module-button-disabled"
                    >
                        Coming Soon
                    </span>

                `;


                container.appendChild(
                    moduleCard
                );


                return;

            }


            /* -----------------------------------------
               PUBLISHED + ACCESSIBLE
            ----------------------------------------- */

            if (hasModuleAccess) {

                moduleCard.dataset.status =
                    "available";


                const isPreview =
                    isPremium &&
                    !BookwormPremium.isPremium() &&
                    moduleNumber === 1;


                moduleCard.innerHTML = `

                    <div class="module-number">
                        ${moduleString}
                    </div>

                    <div class="module-content">

                        <span class="module-status">
                            ${
                                isPreview
                                    ? "FREE PREVIEW"
                                    : "AVAILABLE"
                            }
                        </span>

                        <h3>
                            ${escapeHTML(
                                moduleTitle
                            )}
                        </h3>

                        <p>
                            ${
                                isPreview

                                    ? "Preview the first topic before unlocking Premium."

                                    : "Structured lesson available for study in the Bookworm reader."
                            }
                        </p>

                    </div>

                    <a
                        href="course-note.html?course=${encodeURIComponent(
                            normalizedSlug
                        )}&module=${encodeURIComponent(
                            moduleString
                        )}"
                        class="module-button"
                    >
                        ${
                            isPreview
                                ? "Preview"
                                : "Study"
                        }

                        <span>
                            →
                        </span>

                    </a>

                `;


                container.appendChild(
                    moduleCard
                );


                return;

            }


            /* -----------------------------------------
               PREMIUM LOCKED
            ----------------------------------------- */

            moduleCard.dataset.status =
                "premium-locked";


            moduleCard.innerHTML = `

                <div class="module-number">
                    ${moduleString}
                </div>

                <div class="module-content">

                    <span class="module-status">
                        PREMIUM
                    </span>

                    <h3>
                        ${escapeHTML(
                            moduleTitle
                        )}
                    </h3>

                    <p>
                        Unlock Premium to access
                        this learning module.
                    </p>

                </div>

                <button
                    type="button"
                    class="module-button premium-lock-button"
                    data-course="${escapeHTML(
                        normalizedSlug
                    )}"
                >
                    🔒 Unlock
                </button>

            `;


            container.appendChild(
                moduleCard
            );

        }
    );


    bindPremiumButtons();

}


/* =========================================================
   PREMIUM BUTTONS
========================================================= */

function bindPremiumButtons() {

    const buttons =
        document.querySelectorAll(
            ".premium-lock-button"
        );


    buttons.forEach(
        function(button) {

            button.addEventListener(
                "click",
                function() {

                    showPremiumUnlockPanel();

                }
            );

        }
    );

}


/* =========================================================
   PREMIUM UNLOCK PANEL
========================================================= */

function showPremiumUnlockPanel() {

    const existing =
        document.getElementById(
            "premiumUnlockOverlay"
        );


    if (existing) {

        existing.remove();

    }


    const payment =
        BookwormPremium.getPaymentInfo();


    const overlay =
        document.createElement(
            "div"
        );


    overlay.id =
        "premiumUnlockOverlay";


    overlay.className =
        "premium-overlay";


    overlay.innerHTML = `

        <div
            class="premium-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="premiumModalTitle"
        >

            <button
                type="button"
                class="premium-modal-close"
                id="premiumModalClose"
                aria-label="Close"
            >
                ×
            </button>


            <span class="premium-modal-label">
                BOOKWORM PREMIUM
            </span>


            <h2 id="premiumModalTitle">
                Unlock all premium courses
            </h2>


            <p class="premium-modal-description">
                Pay ₦500 once to unlock:
            </p>


            <div class="premium-course-list">

                <span>ENG 201</span>
                <span>ENG 203</span>
                <span>ENL 210</span>
                <span>EDU 211</span>

            </div>


            <div class="premium-price">
                ₦500
            </div>


            <div class="premium-payment-box">

                <div>

                    <small>
                        OPAY
                    </small>

                    <strong>
                        ${escapeHTML(
                            payment.opayName
                        )}
                    </strong>

                    <span>
                        ${escapeHTML(
                            payment.opayNumber
                        )}
                    </span>

                </div>


                <div>

                    <small>
                        WHATSAPP
                    </small>

                    <strong>
                        ${escapeHTML(
                            payment.whatsapp
                        )}
                    </strong>

                    <span>
                        Send your payment proof here
                    </span>

                </div>

            </div>


            <p class="premium-payment-note">

                After payment, send your proof of payment
                through WhatsApp. Your Premium access will
                be activated manually after verification.

            </p>


            <div class="premium-modal-actions">

                <a
                    href="#"
                    class="premium-primary-button"
                    id="premiumWhatsAppButton"
                    target="_blank"
                    rel="noopener"
                >
                    Contact Bookworm
                </a>


                <button
                    type="button"
                    class="premium-secondary-button"
                    id="premiumModalDone"
                >
                    I've seen the instructions
                </button>

            </div>

        </div>

    `;


    document.body.appendChild(
        overlay
    );


    const closeButton =
        document.getElementById(
            "premiumModalClose"
        );


    const doneButton =
        document.getElementById(
            "premiumModalDone"
        );


    const whatsappButton =
        document.getElementById(
            "premiumWhatsAppButton"
        );


    function closeModal() {

        overlay.remove();

    }


    closeButton.addEventListener(
        "click",
        closeModal
    );


    doneButton.addEventListener(
        "click",
        closeModal
    );


    overlay.addEventListener(
        "click",
        function(event) {

            if (
                event.target === overlay
            ) {

                closeModal();

            }

        }
    );


    if (
        payment.whatsapp &&
        payment.whatsapp !==
        "YOUR_WHATSAPP_NUMBER"
    ) {

        const cleanNumber =
            payment.whatsapp
                .replace(
                    /[^0-9+]/g,
                    ""
                );


        whatsappButton.href =
            `https://wa.me/${cleanNumber.replace(
                "+",
                ""
            )}`;

    } else {

        whatsappButton.href =
            "#";


        whatsappButton.addEventListener(
            "click",
            function(event) {

                event.preventDefault();

                alert(
                    "Add your WhatsApp number in js/premium-access.js first."
                );

            }
        );

    }

}


/* =========================================================
   COURSE ERROR
========================================================= */

function showCourseError() {

    const courseModules =
        document.getElementById(
            "courseModules"
        );


    if (!courseModules) {

        return;

    }


    courseModules.innerHTML = `

        <div class="course-error">

            <div class="reader-error-icon">
                !
            </div>

            <h2>
                Course Not Found
            </h2>

            <p>
                The course you are trying to access
                could not be found in the Bookworm
                course database.
            </p>

            <a
                href="courses.html"
                class="module-button"
            >
                Back to Courses
            </a>

        </div>

    `;


    document.title =
        "Course Not Found | Bookworm Club";

}


/* =========================================================
   HTML ESCAPING
========================================================= */

function escapeHTML(value) {

    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}