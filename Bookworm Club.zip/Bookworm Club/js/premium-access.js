/* =========================================================
   BOOKWORM CLUB — PREMIUM ACCESS ENGINE
   200 LEVEL • FIRST SEMESTER
========================================================= */

"use strict";


/* =========================================================
   BOOKWORM PREMIUM CONFIGURATION
========================================================= */

const BOOKWORM_PREMIUM = {

    /* -----------------------------------------
       PRODUCT
    ----------------------------------------- */

    productName:
        "200L First Semester Premium Access",

    productCode:
        "200L_FIRST_SEMESTER_PREMIUM",

    price: 500,

    currency:
        "₦",


    /* -----------------------------------------
       FREE COURSES
    ----------------------------------------- */

    freeCourses: [

        "GST212",
        "ENT211",
        "EDU201",
        "UNIBENEDU212",
        "ENG205",
        "LAS244"

    ],


    /* -----------------------------------------
       PREMIUM COURSES
    ----------------------------------------- */

    premiumCourses: [

        "ENG201",
        "ENG203",
        "UNIBENEDU211",
        "UNIBENENL210"

    ],


    /* -----------------------------------------
       PREMIUM PREVIEW

       Module 01 is free.
       Module 02+ requires Premium.
    ----------------------------------------- */

    freePreviewModules:
        1,


    /* -----------------------------------------
       PAYMENT INFORMATION

       REPLACE THESE VALUES WITH YOUR
       REAL PAYMENT DETAILS.
    ----------------------------------------- */

    payment: {

        whatsapp:
            "2347072500449",

        opayName:
            "OKPOKPA JUSTICE OSIVUE",

        opayNumber:
            "7072500449"

    }

};


/* =========================================================
   NORMALISE COURSE SLUG
========================================================= */

function normalizeBookwormCourseSlug(value) {

    return String(value || "")
        .trim()
        .toUpperCase()
        .replace(/\s+/g, "");

}


/* =========================================================
   IS COURSE FREE?
========================================================= */

function isFreeCourse(courseSlug) {

    const slug =
        normalizeBookwormCourseSlug(courseSlug);

    return BOOKWORM_PREMIUM.freeCourses
        .includes(slug);

}


/* =========================================================
   IS COURSE PREMIUM?
========================================================= */

function isPremiumCourse(courseSlug) {

    const slug =
        normalizeBookwormCourseSlug(courseSlug);

    return BOOKWORM_PREMIUM.premiumCourses
        .includes(slug);

}


/* =========================================================
   PREMIUM STATE
========================================================= */

let bookwormPremiumState = {

    loaded: false,

    active: false,

    userId: null

};


/* =========================================================
   DATABASE-BACKED PREMIUM STATUS

   Premium access is determined by the authenticated
   user's approved entitlement in Supabase.

   Browser storage is NOT trusted for authorization.
========================================================= */

async function refreshBookwormPremiumStatus() {

    bookwormPremiumState = {

        loaded: false,

        active: false,

        userId: null

    };

    try {

        const supabase =
            window.supabaseClient;


        /* -----------------------------------------
           SUPABASE CLIENT CHECK
        ----------------------------------------- */

        if (!supabase) {

            console.error(
                "Bookworm Premium: Supabase client unavailable."
            );

            bookwormPremiumState.loaded = true;

            return false;

        }


        /* -----------------------------------------
           CURRENT USER
        ----------------------------------------- */

        const {
            data: authData,
            error: authError
        } =
            await supabase.auth.getUser();


        if (authError) {

            throw authError;

        }


        const user =
            authData?.user;


        /* -----------------------------------------
           NO AUTHENTICATED USER
        ----------------------------------------- */

        if (!user) {

            bookwormPremiumState.loaded = true;

            return false;

        }


        bookwormPremiumState.userId =
            user.id;


        /* -----------------------------------------
           CHECK PREMIUM ENTITLEMENT
        ----------------------------------------- */

        const {
            data: entitlements,
            error: entitlementError
        } =
            await supabase

                .from("premium_entitlements")

                .select("id")

                .eq(
                    "user_id",
                    user.id
                )

                .eq(
                    "product_code",
                    BOOKWORM_PREMIUM.productCode
                )

                .not(
                    "approved_at",
                    "is",
                    null
                )

                .limit(1);


        if (entitlementError) {

            throw entitlementError;

        }


        /* -----------------------------------------
           PREMIUM ACTIVE?
        ----------------------------------------- */

        bookwormPremiumState.active =
            Array.isArray(entitlements) &&
            entitlements.length > 0;


        bookwormPremiumState.loaded =
            true;


        return bookwormPremiumState.active;


    } catch (error) {

        console.error(
            "Bookworm Premium status check failed:",
            error
        );


        /*
         * FAIL CLOSED
         *
         * If the database check fails,
         * Premium access remains locked.
         */

        bookwormPremiumState.loaded =
            true;

        bookwormPremiumState.active =
            false;


        return false;

    }

}


/* =========================================================
   INITIAL PREMIUM CHECK
========================================================= */

const bookwormPremiumReady =
    refreshBookwormPremiumStatus();


/* =========================================================
   GET PREMIUM STATUS
========================================================= */

function isBookwormPremium() {

    return (

        bookwormPremiumState.loaded &&

        bookwormPremiumState.active

    );

}


/* =========================================================
   REFRESH PREMIUM STATUS
========================================================= */

async function refreshBookwormPremium() {

    return refreshBookwormPremiumStatus();

}


/* =========================================================
   COURSE ACCESS
========================================================= */

function canAccessBookwormCourse(courseSlug) {

    const slug =
        normalizeBookwormCourseSlug(courseSlug);


    /* -----------------------------------------
       FREE COURSE
    ----------------------------------------- */

    if (isFreeCourse(slug)) {

        return true;

    }


    /* -----------------------------------------
       PREMIUM COURSE
    ----------------------------------------- */

    if (isPremiumCourse(slug)) {

        return isBookwormPremium();

    }


    /* -----------------------------------------
       UNKNOWN COURSE
    ----------------------------------------- */

    return false;

}


/* =========================================================
   MODULE ACCESS
========================================================= */

function canAccessBookwormModule(
    courseSlug,
    moduleNumber
) {

    const slug =
        normalizeBookwormCourseSlug(courseSlug);

    const module =
        parseInt(moduleNumber, 10) || 1;


    /* -----------------------------------------
       FREE COURSE
    ----------------------------------------- */

    if (isFreeCourse(slug)) {

        return true;

    }


    /* -----------------------------------------
       PREMIUM COURSE
    ----------------------------------------- */

    if (isPremiumCourse(slug)) {


        /* Premium student */

        if (isBookwormPremium()) {

            return true;

        }


        /* First module is free preview */

        return (

            module <=
            BOOKWORM_PREMIUM.freePreviewModules

        );

    }


    /* -----------------------------------------
       UNKNOWN COURSE
    ----------------------------------------- */

    return false;

}


/* =========================================================
   COURSE ACCESS LABEL
========================================================= */

function getBookwormCourseAccessLabel(
    courseSlug
) {

    const slug =
        normalizeBookwormCourseSlug(courseSlug);


    if (isFreeCourse(slug)) {

        return "FREE";

    }


    if (isPremiumCourse(slug)) {

        if (isBookwormPremium()) {

            return "PREMIUM • UNLOCKED";

        }

        return "PREMIUM";

    }


    return "UNAVAILABLE";

}


/* =========================================================
   MODULE ACCESS LABEL
========================================================= */

function getBookwormModuleAccessLabel(
    courseSlug,
    moduleNumber
) {

    if (
        canAccessBookwormModule(
            courseSlug,
            moduleNumber
        )
    ) {

        if (

            isPremiumCourse(courseSlug) &&

            !isBookwormPremium()

        ) {

            return "FREE PREVIEW";

        }

        return "AVAILABLE";

    }

    return "PREMIUM";

}


/* =========================================================
   PAYMENT INFORMATION
========================================================= */

function getBookwormPaymentInfo() {

    return {

        product:
            BOOKWORM_PREMIUM.productName,

        amount:
            `${BOOKWORM_PREMIUM.currency}${BOOKWORM_PREMIUM.price}`,

        whatsapp:
            BOOKWORM_PREMIUM.payment.whatsapp,

        opayName:
            BOOKWORM_PREMIUM.payment.opayName,

        opayNumber:
            BOOKWORM_PREMIUM.payment.opayNumber

    };

}


/* =========================================================
   PREMIUM COURSE COUNT
========================================================= */

function getBookwormPremiumCourseCount() {

    return BOOKWORM_PREMIUM
        .premiumCourses
        .length;

}


/* =========================================================
   FREE COURSE COUNT
========================================================= */

function getBookwormFreeCourseCount() {

    return BOOKWORM_PREMIUM
        .freeCourses
        .length;

}


/* =========================================================
   GLOBAL API
========================================================= */

window.BookwormPremium = {

    config:
        BOOKWORM_PREMIUM,

    normalizeCourseSlug:
        normalizeBookwormCourseSlug,

    isFreeCourse:
        isFreeCourse,

    isPremiumCourse:
        isPremiumCourse,

    isPremium:
        isBookwormPremium,

    ready:
        bookwormPremiumReady,

    refresh:
        refreshBookwormPremium,

    canAccessCourse:
        canAccessBookwormCourse,

    canAccessModule:
        canAccessBookwormModule,

    getCourseAccessLabel:
        getBookwormCourseAccessLabel,

    getModuleAccessLabel:
        getBookwormModuleAccessLabel,

    getPaymentInfo:
        getBookwormPaymentInfo,

    getPremiumCourseCount:
        getBookwormPremiumCourseCount,

    getFreeCourseCount:
        getBookwormFreeCourseCount

};


/* =========================================================
   DEBUG
========================================================= */

console.log(
    "Bookworm Premium Engine initialized.",
    {

        premium:
            isBookwormPremium(),

        freeCourses:
            getBookwormFreeCourseCount(),

        premiumCourses:
            getBookwormPremiumCourseCount(),

        price:
            `${BOOKWORM_PREMIUM.currency}${BOOKWORM_PREMIUM.price}`

    }
);