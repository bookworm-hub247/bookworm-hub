// =====================================================
// BOOKWORM CLUB — LOGIN
// js/login.js
// =====================================================
//
// This file handles:
// 1. Login with Supabase Auth
// 2. Existing-session detection
// 3. Basic profile verification
// 4. Redirect to dashboard
//
// ADMIN STATUS IS NOT CHECKED HERE.
// Admin access is controlled separately through:
// public.admin_users.user_id
// =====================================================


(function () {

    "use strict";


    // =================================================
    // ELEMENTS
    // =================================================

    const loginForm =
        document.getElementById("loginForm");

    const emailInput =
        document.getElementById("email");

    const passwordInput =
        document.getElementById("password");

    const loginButton =
        document.getElementById("loginButton");

    const authMessage =
        document.getElementById("authMessage");


    // =================================================
    // SUPABASE CHECK
    // =================================================

    const supabaseClient =
        window.supabaseClient;


    if (!supabaseClient) {

        console.error(
            "BOOKWORM ERROR: Supabase client was not found."
        );

        showMessage(
            "Authentication system could not load. Please refresh the page.",
            "error"
        );

        if (loginButton) {
            loginButton.disabled = true;
        }

        return;
    }


    // =================================================
    // MESSAGE FUNCTION
    // =================================================

    function showMessage(message, type = "") {

        if (!authMessage) {
            return;
        }

        authMessage.textContent = message;

        authMessage.classList.remove(
            "success",
            "error"
        );

        if (type) {
            authMessage.classList.add(type);
        }
    }


    // =================================================
    // BUTTON STATE
    // =================================================

    function setLoading(isLoading) {

        if (!loginButton) {
            return;
        }

        loginButton.disabled = isLoading;

        loginButton.textContent =
            isLoading
                ? "SIGNING IN..."
                : "SIGN IN";
    }


    // =================================================
    // VALIDATE FORM
    // =================================================

    function validateLogin(email, password) {

        if (!email) {

            showMessage(
                "Please enter your email address.",
                "error"
            );

            emailInput?.focus();

            return false;
        }


        if (!password) {

            showMessage(
                "Please enter your password.",
                "error"
            );

            passwordInput?.focus();

            return false;
        }


        return true;
    }


    // =================================================
    // CHECK EXISTING SESSION
    // =================================================
    //
    // If a user is already logged in and opens
    // login.html again, don't make them log in twice.
    // =================================================

    async function checkExistingSession() {

        try {

            const {
                data,
                error
            } =
                await supabaseClient.auth.getSession();


            if (error) {

                console.warn(
                    "Could not check existing session:",
                    error
                );

                return;
            }


            if (
                data &&
                data.session &&
                data.session.user
            ) {

                console.log(
                    "Existing Bookworm session detected."
                );


                // User is already authenticated.
                window.location.replace(
                    "dashboard.html"
                );
            }

        } catch (error) {

            console.error(
                "Session check failed:",
                error
            );
        }
    }


    // =================================================
    // VERIFY / REPAIR PROFILE
    // =================================================
    //
    // IMPORTANT:
    //
    // profiles does NOT contain email.
    //
    // We therefore only use:
    //
    // id
    // full_name
    // department
    // level
    // institution
    //
    // Supabase Auth remains responsible for email.
    // =================================================

    async function ensureProfile(user) {

        if (!user) {
            return;
        }


        try {

            // -----------------------------------------
            // First try to find the profile.
            // -----------------------------------------

            const {
                data: existingProfile,
                error: fetchError
            } =
                await supabaseClient
                    .from("profiles")
                    .select(
                        "id, full_name, department, level, institution, created_at"
                    )
                    .eq("id", user.id)
                    .maybeSingle();


            if (fetchError) {

                console.warn(
                    "Profile lookup failed:",
                    fetchError
                );

                // Don't prevent login because the
                // authentication itself succeeded.
                return;
            }


            // -----------------------------------------
            // Profile already exists.
            // -----------------------------------------

            if (existingProfile) {

                console.log(
                    "Bookworm profile found:",
                    existingProfile
                );

                return existingProfile;
            }


            // -----------------------------------------
            // Profile doesn't exist.
            //
            // This can happen with an older account
            // or if a previous profile creation failed.
            // -----------------------------------------

            const metadata =
                user.user_metadata || {};


            const profileData = {

                id: user.id,

                full_name:
                    metadata.full_name ||
                    user.email?.split("@")[0] ||
                    "Student",

                department:
                    metadata.department || "",

                level:
                    metadata.level || "",

                institution:
                    metadata.institution || ""
            };


            const {
                data: newProfile,
                error: insertError
            } =
                await supabaseClient
                    .from("profiles")
                    .insert(profileData)
                    .select(
                        "id, full_name, department, level, institution, created_at"
                    )
                    .single();


            if (insertError) {

                console.warn(
                    "Profile could not be created:",
                    insertError
                );

                return;
            }


            console.log(
                "Bookworm profile repaired:",
                newProfile
            );


            return newProfile;

        } catch (error) {

            console.warn(
                "Unexpected profile error:",
                error
            );
        }
    }


    // =================================================
    // LOGIN
    // =================================================

    async function loginUser() {

        const email =
            emailInput
                ?.value
                .trim()
                .toLowerCase() || "";


        const password =
            passwordInput
                ?.value || "";


        // ---------------------------------------------
        // Validate
        // ---------------------------------------------

        if (
            !validateLogin(
                email,
                password
            )
        ) {
            return;
        }


        setLoading(true);

        showMessage(
            "Signing you in..."
        );


        try {

            // =========================================
            // SUPABASE LOGIN
            // =========================================

            const {
                data,
                error
            } =
                await supabaseClient.auth
                    .signInWithPassword({

                        email: email,

                        password: password

                    });


            // =========================================
            // LOGIN ERROR
            // =========================================

            if (error) {

                console.error(
                    "Bookworm login error:",
                    error
                );


                let message =
                    error.message ||
                    "Unable to sign in.";


                // Make common Supabase errors
                // easier for the student to understand.

                if (
                    error.message
                        ?.toLowerCase()
                        .includes("email not confirmed")
                ) {

                    message =
                        "Please confirm your email address before signing in.";
                }


                if (
                    error.message
                        ?.toLowerCase()
                        .includes("invalid login credentials")
                ) {

                    message =
                        "Incorrect email or password.";
                }


                showMessage(
                    message,
                    "error"
                );

                setLoading(false);

                return;
            }


            // =========================================
            // VERIFY USER
            // =========================================

            const user =
                data?.user;


            if (!user) {

                throw new Error(
                    "Authentication succeeded but no user was returned."
                );
            }


            // =========================================
            // SESSION CHECK
            // =========================================

            const session =
                data?.session;


            if (!session) {

                throw new Error(
                    "No active session was created."
                );
            }


            console.log(
                "Bookworm user authenticated:",
                user.id
            );


            // =========================================
            // PROFILE
            // =========================================

            await ensureProfile(user);


            // =========================================
            // SAVE NON-SENSITIVE SESSION INDICATOR
            // =========================================
            //
            // We DO NOT store passwords or tokens here.
            //
            // Supabase manages the real authentication
            // session.
            // =========================================

            localStorage.setItem(
                "bookworm_logged_in",
                "true"
            );


            // =========================================
            // SUCCESS
            // =========================================

            showMessage(
                "Login successful. Opening Bookworm...",
                "success"
            );


            // Small delay so the student can see
            // the successful login message.

            setTimeout(
                function () {

                    window.location.replace(
                        "dashboard.html"
                    );

                },
                500
            );


        } catch (error) {

            console.error(
                "Bookworm login failed:",
                error
            );


            showMessage(
                error?.message ||
                "Something went wrong while signing in.",
                "error"
            );


            setLoading(false);
        }
    }


    // =================================================
    // FORM SUBMIT
    // =================================================

    if (loginForm) {

        loginForm.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();

                loginUser();

            }
        );
    }


    // =================================================
    // ENTER KEY
    // =================================================
    //
    // Normal form submission already handles this,
    // so no separate Enter listener is necessary.
    // =================================================


    // =================================================
    // SUPABASE AUTH STATE
    // =================================================

    supabaseClient.auth.onAuthStateChange(
        function (event, session) {

            console.log(
                "Bookworm auth state:",
                event
            );


            // We intentionally don't redirect on
            // every auth event here.
            //
            // loginUser() handles successful login.
            // auth-guard.js handles protected pages.
        }
    );


    // =================================================
    // START
    // =================================================

    checkExistingSession();


})();