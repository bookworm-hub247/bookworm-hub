// ==========================================
// BOOKWORM CLUB — DASHBOARD
// ==========================================
// Dashboard data + rendering
// Current academic session:
// 200 Level — First Semester
// ==========================================

"use strict";


// ==========================================
// COURSE DATA
// ==========================================
// IMPORTANT:
// Keep this list synchronized with courses.js
// ==========================================

const courses = [
    {
        code: "GST 212",
        slug: "GST212",
        title: "Philosophy, Logic and Human Existence",
        department: "General Studies",
        units: 2
    },

    {
        code: "ENT 211",
        slug: "ENT211",
        title: "Entrepreneurship and Innovation",
        department: "General Studies",
        units: 2
    },

    {
        code: "EDU 201",
        slug: "EDU201",
        title: "Curriculum, Curriculum Delivery and General Teaching Methods",
        department: "Education",
        units: 2
    },

    {
        code: "UNIBENEDU 211",
        slug: "UNIBENEDU211",
        title: "Developmental Psychology",
        department: "Education",
        units: 2
    },

    {
        code: "UNIBENEDU 212",
        slug: "UNIBENEDU212",
        title: "Philosophy of Education",
        department: "Education",
        units: 2
    },

    {
        code: "ENG 201",
        slug: "ENG201",
        title: "An Introduction to Morphology and Syntax",
        department: "English",
        units: 2
    },

    {
        code: "ENG 203",
        slug: "ENG203",
        title: "Introduction to General Phonetics and Phonology I",
        department: "English",
        units: 2
    },

    {
        code: "ENG 205",
        slug: "ENG205",
        title: "Advance English Composition I",
        department: "English",
        units: 2
    },

    {
        code: "UNIBENENL 210",
        slug: "UNIBENENL210",
        title: "A Survey of English Literature from Anglo-Saxon to the Elizabethan Period",
        department: "English / Literature",
        units: 2
    },

    {
        code: "LAS 244",
        slug: "LAS244",
        title: "Method I – Teaching Grammar, Lexis & Oracy Skills",
        department: "Language Education",
        units: 2
    }
];


// ==========================================
// RESOURCE DATA
// ==========================================
// These are currently the dashboard's
// available resource previews.
//
// This can later be connected directly
// to Supabase when the resource database
// is ready.
// ==========================================

const resources = [
    {
        title: "Introduction to Morphology",
        type: "course-note",
        typeName: "COURSE NOTE",
        course: "ENG 201",
        description:
            "Key concepts covering morphemes, word structure and morphological analysis."
    },

    {
        title: "General Phonetics Revision Guide",
        type: "revision-guide",
        typeName: "REVISION GUIDE",
        course: "ENG 203",
        description:
            "A structured revision guide covering important phonetics and phonology concepts."
    },

    {
        title: "Philosophy of Education",
        type: "study-guide",
        typeName: "STUDY GUIDE",
        course: "UNIBENEDU 212",
        description:
            "Study material covering major concepts in philosophy of education."
    },

    {
        title: "Developmental Psychology Notes",
        type: "course-note",
        typeName: "COURSE NOTE",
        course: "UNIBENEDU 211",
        description:
            "Introduction to developmental psychology and major stages of human development."
    },

    {
        title: "Entrepreneurship Revision Guide",
        type: "revision-guide",
        typeName: "REVISION GUIDE",
        course: "ENT 211",
        description:
            "Important concepts related to entrepreneurship, innovation and business development."
    },

    {
        title: "Logic and Human Existence",
        type: "study-guide",
        typeName: "STUDY GUIDE",
        course: "GST 212",
        description:
            "A study guide for philosophical reasoning, logic and questions of human existence."
    }
];


// ==========================================
// ANNOUNCEMENT DATA
// ==========================================
// Temporary dashboard announcement data.
// This can later be connected to Supabase.
// ==========================================

const announcements = [
    {
        id: 1,
        title: "Welcome to the New Academic Session",
        category: "academic",
        date: "September 22, 2026",
        summary:
            "Welcome back, Bookworms. A new academic session has begun. Stay organized, attend your classes, and keep your academic goals in focus."
    },

    {
        id: 2,
        title: "200 Level Course Materials",
        category: "academic",
        date: "September 20, 2026",
        summary:
            "Course materials for first-semester 200-level courses will be added to the Resources section."
    },

    {
        id: 3,
        title: "Keep Track of Your Assignments",
        category: "deadline",
        date: "September 18, 2026",
        summary:
            "Use the Task Manager to record assignments, deadlines, projects and other academic responsibilities."
    },

    {
        id: 4,
        title: "Bookworm Club Marketplace Is Open",
        category: "club",
        date: "September 17, 2026",
        summary:
            "Students can now explore the Marketplace for academic books, notes and other useful student resources."
    },

    {
        id: 5,
        title: "Bookworm Club Community Update",
        category: "club",
        date: "September 15, 2026",
        summary:
            "We are continuing to build Bookworm Club into a useful academic community for students."
    },

    {
        id: 6,
        title: "Academic Events and Opportunities",
        category: "event",
        date: "September 12, 2026",
        summary:
            "Keep an eye out for academic events, workshops, seminars and student opportunities."
    }
];


// ==========================================
// DOM ELEMENTS
// ==========================================

const courseList =
    document.getElementById("courseList");

const taskList =
    document.getElementById("taskList");

const resourceList =
    document.getElementById("resourceList");

const dashboardAnnouncements =
    document.getElementById("dashboardAnnouncements");


// ==========================================
// LOAD TASKS
// ==========================================
// Uses the same localStorage key as tasks.js.
//
// bookwormTasks
//
// This means existing student tasks are
// preserved.
// ==========================================

function loadTasks() {

    try {

        const savedTasks =
            localStorage.getItem("bookwormTasks");

        if (!savedTasks) {
            return [];
        }

        const parsedTasks =
            JSON.parse(savedTasks);

        if (!Array.isArray(parsedTasks)) {
            return [];
        }

        return parsedTasks;

    } catch (error) {

        console.error(
            "BOOKWORM DASHBOARD: Could not load tasks.",
            error
        );

        return [];
    }
}


// ==========================================
// SAFE HTML ESCAPING
// ==========================================
// Prevents user-entered task text from
// being inserted directly as HTML.
// ==========================================

function escapeHTML(value) {

    if (
        value === null ||
        value === undefined
    ) {
        return "";
    }

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


// ==========================================
// COURSE RENDERING
// ==========================================
// The dashboard only previews the first
// four courses.
//
// The statistics still count ALL 10.
// ==========================================

function renderCourses() {

    if (!courseList) {
        return;
    }

    courseList.innerHTML = "";


    const previewCourses =
        courses.slice(0, 4);


    previewCourses.forEach(function (course) {

        const item =
            document.createElement("div");

        item.className =
            "course-item";


        item.innerHTML = `
            <div class="course-code">
                ${escapeHTML(course.code)}
            </div>

            <div class="course-title">
                ${escapeHTML(course.title)}
            </div>
        `;


        courseList.appendChild(item);

    });

}


// ==========================================
// TASK RENDERING
// ==========================================

function renderTasks() {

    if (!taskList) {
        return;
    }


    const tasks =
        loadTasks();


    taskList.innerHTML = "";


    // --------------------------------------
    // NO TASKS
    // --------------------------------------

    if (tasks.length === 0) {

        taskList.innerHTML = `
            <div class="task-item">

                <div class="task-info">

                    <strong>
                        No tasks yet
                    </strong>

                    <span>
                        Add an academic task from Task Manager.
                    </span>

                </div>

            </div>
        `;

        return;
    }


    // --------------------------------------
    // SHOW FIRST FOUR TASKS
    // --------------------------------------

    tasks
        .slice(0, 4)
        .forEach(function (task) {

            const item =
                document.createElement("div");


            item.className =
                "task-item";


            if (task.completed) {

                item.classList.add(
                    "completed"
                );

            }


            const taskTitle =
                escapeHTML(
                    task.title || "Untitled Task"
                );


            const taskCourse =
                escapeHTML(
                    task.course || "Academic Task"
                );


            const taskDue =
                escapeHTML(
                    task.due || "No date"
                );


            item.innerHTML = `
                <div class="task-info">

                    <strong>
                        ${taskTitle}
                    </strong>

                    <span>
                        ${taskCourse}
                        • Due ${taskDue}
                    </span>

                </div>
            `;


            taskList.appendChild(item);

        });

}


// ==========================================
// RESOURCE RENDERING
// ==========================================

function renderResources() {

    if (!resourceList) {
        return;
    }


    resourceList.innerHTML = "";


    resources.forEach(function (resource) {

        const item =
            document.createElement("div");


        item.className =
            "resource-card";


        item.innerHTML = `
            <span class="resource-type">
                ${escapeHTML(resource.typeName)}
            </span>

            <h3>
                ${escapeHTML(resource.title)}
            </h3>

            <p>
                ${escapeHTML(resource.course)}
            </p>
        `;


        resourceList.appendChild(item);

    });

}


// ==========================================
// ANNOUNCEMENT RENDERING
// ==========================================

function renderAnnouncements() {

    if (!dashboardAnnouncements) {
        return;
    }


    dashboardAnnouncements.innerHTML = "";


    const latestAnnouncements =
        announcements.slice(0, 3);


    latestAnnouncements.forEach(
        function (announcement) {

            const item =
                document.createElement("article");


            item.className =
                "dashboard-announcement";


            item.innerHTML = `

                <div class="dashboard-announcement-main">

                    <span
                        class="
                            dashboard-announcement-category
                            ${escapeHTML(
                                announcement.category
                            )}
                        "
                    >
                        ${escapeHTML(
                            getCategoryLabel(
                                announcement.category
                            )
                        )}
                    </span>


                    <h3>
                        ${escapeHTML(
                            announcement.title
                        )}
                    </h3>


                    <p>
                        ${escapeHTML(
                            announcement.summary
                        )}
                    </p>

                </div>


                <div class="dashboard-announcement-side">

                    <span class="dashboard-announcement-date">
                        ${escapeHTML(
                            announcement.date
                        )}
                    </span>

                    <a href="announcements.html">
                        Read →
                    </a>

                </div>

            `;


            dashboardAnnouncements.appendChild(item);

        }
    );

}


// ==========================================
// CATEGORY LABEL
// ==========================================

function getCategoryLabel(category) {

    const labels = {

        academic: "Academic",

        event: "Event",

        deadline: "Deadline",

        club: "Bookworm Club"

    };


    return labels[category] ||
        "Announcement";

}


// ==========================================
// UPDATE DASHBOARD STATISTICS
// ==========================================
// Course/resource/task counts are local
// dashboard data.
//
// Study progress comes from Supabase through
// BookwormProgress.
// ==========================================

async function updateStatistics() {

    const courseCount =
        document.getElementById("courseCount");

    const resourceCount =
        document.getElementById("resourceCount");

    const taskCount =
        document.getElementById("taskCount");

    const dashboardProgress =
        document.getElementById("dashboardProgress");


    const tasks =
        loadTasks();


    // --------------------------------------
    // COURSE COUNT
    // --------------------------------------

    if (courseCount) {

        courseCount.textContent =
            courses.length;

    }


    // --------------------------------------
    // RESOURCE COUNT
    // --------------------------------------

    if (resourceCount) {

        resourceCount.textContent =
            resources.length;

    }


    // --------------------------------------
    // TASK COUNT
    // --------------------------------------

    if (taskCount) {

        taskCount.textContent =
            tasks.length;

    }


    // --------------------------------------
    // STUDY PROGRESS
    // --------------------------------------

    if (!dashboardProgress) {
        return;
    }


    // Safe loading/default state

    dashboardProgress.textContent =
        "0%";


    // --------------------------------------
    // CHECK PROGRESS ENGINE
    // --------------------------------------

    if (!window.BookwormProgress) {

        console.warn(
            "BOOKWORM DASHBOARD: Progress engine is not available."
        );

        return;
    }


    // --------------------------------------
    // LOAD REAL PROGRESS
    // --------------------------------------

    try {

        const progress =
            await BookwormProgress.getOverallProgress(

                courses.map(function (course) {

                    return {

                        code:
                            course.slug,

                        modules: [
                            1,
                            2,
                            3,
                            4
                        ]

                    };

                })

            );


        const percent =
            Number(
                progress?.progressPercent || 0
            );


        dashboardProgress.textContent =
            `${percent}%`;


        console.log(
            "BOOKWORM DASHBOARD: Study progress loaded.",
            progress
        );


    } catch (error) {

        console.error(
            "BOOKWORM DASHBOARD: Could not load study progress.",
            error
        );


        dashboardProgress.textContent =
            "0%";

    }

}


// ==========================================
// DASHBOARD REFRESH
// ==========================================

async function refreshDashboard() {

    renderCourses();

    renderTasks();

    renderResources();

    renderAnnouncements();

    await updateStatistics();

}


// ==========================================
// DASHBOARD INITIALIZATION
// ==========================================

async function initializeDashboard() {

    console.log(
        "BOOKWORM DASHBOARD: Initializing..."
    );


    await refreshDashboard();


    console.log(
        "BOOKWORM DASHBOARD READY."
    );


    console.log(
        "Courses available:",
        courses.length
    );


    console.log(
        "Resources available:",
        resources.length
    );


    console.log(
        "Tasks available:",
        loadTasks().length
    );

}


// ==========================================
// REFRESH WHEN USER RETURNS
// ==========================================

document.addEventListener(
    "visibilitychange",
    function () {

        if (
            document.visibilityState === "visible"
        ) {

            refreshDashboard();

        }

    }
);


// ==========================================
// START DASHBOARD
// ==========================================

if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initializeDashboard
    );

} else {

    initializeDashboard();

}