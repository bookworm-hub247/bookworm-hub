
/* =========================================================
   BOOKWORM CLUB — STUDENT PROGRESS DASHBOARD
   Accurate lesson availability, progress and resume links
   Includes:
   - Continue Learning spotlight
   - Course progress cards
   - Module completion checklist
   - Recent study activity
========================================================= */

"use strict";

/* =========================================================
   COURSE CONFIGURATION
========================================================= */

const BOOKWORM_PROGRESS_COURSES = [
    {
        code: "GST 212",
        slug: "GST212",
        name: "Philosophy, Logic and Human Existence",
        modules: [
            "Introduction to Philosophy",
            "Logic and Critical Thinking",
            "Human Existence",
            "Major Philosophical Questions"
        ],
        publishedModules: [1, 2, 3, 4]
    },
    {
        code: "ENT 211",
        slug: "ENT211",
        name: "Entrepreneurship and Innovation",
        modules: [
    "Meaning and Nature of Entrepreneurship",
    "Innovation, Creativity and Opportunity Recognition",
    "Business Planning and Enterprise Development",
    "Entrepreneurial Skills, Ethics and Sustainability"

        ],
        publishedModules: [1, 2, 3, 4]
    },
    {
        code: "EDU 201",
        slug: "EDU201",
        name: "Curriculum, Curriculum Delivery and General Teaching Methods",
        modules: [
    "Meaning, Nature and Scope of Curriculum",
    "Curriculum Development and Design",
    "Curriculum Delivery and Teaching Methods",
    "Lesson Planning, Classroom Management and Evaluation"
        ],
        publishedModules: [1, 2, 3, 4]
    },
    {
        code: "EDU 211",
        slug: "UNIBENEDU211",
        name: "Developmental Psychology",
        modules: [
            "Introduction to Developmental Psychology",
            "Theories of Human Development",
            "Physical and Cognitive Development",
            "Social and Emotional Development"
        ],
        publishedModules: []
    },
    {
        code: "EDU 212",
        slug: "UNIBENEDU212",
        name: "Philosophy of Education",
        modules: [
            "Introduction to Philosophy of Education",
            "Major Schools of Educational Philosophy",
            "Education and Society",
            "Aims and Values of Education"
        ],
        publishedModules: []
    },
    {
        code: "ENG 201",
        slug: "ENG201",
        name: "An Introduction to Morphology and Syntax",
        modules: [
    "Introduction to Morphology",
    "Morpheme Classification and Word Formation",
    "Introduction to Syntax",
    "Sentence Structure and Syntactic Analysis"
        ],
        publishedModules: [1, 2, 3, 4]
    },
    {
        code: "ENG 203",
        slug: "ENG203",
        name: "Introduction to General Phonetics and Phonology I",
        modules: [
            "Introduction to Phonetics",
            "Speech Organs and Articulation",
            "English Vowels",
            "English Consonants"
        ],
        publishedModules: []
    },
    {
        code: "ENG 205",
        slug: "ENG205",
        name: "Advanced English Composition I",
        modules: [
            "Principles of Effective Writing",
            "Paragraph Development",
            "Essay Structure and Organisation",
            "Academic Writing"
        ],
        publishedModules: []
    },
    {
        code: "ENL 210",
        slug: "UNIBENENL210",
        name: "A Survey of English Literature from Anglo-Saxon to the Elizabethan Period",
        modules: [
            "Introduction to English Literature",
            "Anglo-Saxon Literature",
            "Middle English Literature",
            "Elizabethan Literature"
        ],
        publishedModules: []
    },
    {
        code: "LAS 244",
        slug: "LAS244",
        name: "Method I – Teaching Grammar, Lexis & Oracy Skills",
        modules: [
            "Introduction to Language Teaching",
            "Teaching Grammar",
            "Teaching Lexis",
            "Teaching Oracy Skills"
        ],
        publishedModules: []
    }
];


/* =========================================================
   HELPERS
========================================================= */


function progressEscapeHTML(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


function progressNormalizeCourse(value) {
    return String(value || "")
        .trim()
        .toUpperCase()
        .replace(/\s+/g, "");
}


function progressFormatDate(value) {
    if (!value) return "Recently studied";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return "Recently studied";
    }

    return date.toLocaleDateString("en-NG", {
        day: "numeric",
        month: "short",
        year: "numeric"
    });
}


function progressSetText(id, value) {
    const element = document.getElementById(id);

    if (element) {
        element.textContent = value;
    }
}


function progressGetCourse(slug) {
    return BOOKWORM_PROGRESS_COURSES.find(
        course =>
            progressNormalizeCourse(course.slug) ===
            progressNormalizeCourse(slug)
    );
}


function progressGetPublishedModules(course) {
    if (!Array.isArray(course.publishedModules)) {
        return [];
    }

    return [
        ...new Set(
            course.publishedModules
                .map(Number)
                .filter(number =>
                    Number.isInteger(number) &&
                    number >= 1 &&
                    number <= course.modules.length
                )
        )
    ].sort((a, b) => a - b);
}


function progressGetRowsForCourse(rows, course) {
    const slug = progressNormalizeCourse(course.slug);
    const publishedModules = progressGetPublishedModules(course);

    return rows.filter(
        row =>
            progressNormalizeCourse(row.course_code) === slug &&
            publishedModules.includes(Number(row.module_number))
    );
}


function progressGetModuleRow(rows, course, moduleNumber) {
    return rows.find(
        row =>
            progressNormalizeCourse(row.course_code) ===
                progressNormalizeCourse(course.slug) &&
            Number(row.module_number) === Number(moduleNumber)
    );
}



function progressGetModuleURL(course, moduleNumber) {
    const formattedModule = String(moduleNumber).padStart(2, "0");

    return (
        `course-note.html?course=${encodeURIComponent(course.slug)}` +
        `&module=${encodeURIComponent(formattedModule)}`
    );
}



function progressGetModuleStatus(row) {
    const rawPercent = Number(row?.progress_percent || 0);

    const percent = Number.isFinite(rawPercent)
        ? Math.max(0, Math.min(100, rawPercent))
        : 0;

    if (row?.is_completed === true) {
        return {
            label: "Completed",
            className: "completed",
            percent: 100
        };
    }

    if (percent > 0 || Boolean(row?.last_studied_at)) {
        return {
            label: "In progress",
            className: "in-progress",
            percent
        };
    }

    return {
        label: "Not started",
        className: "not-started",
        percent: 0
    };
}


/* =========================================================
   COURSE SUMMARY
========================================================= */

function progressGetCourseSummary(course, rows) {
    const available = progressGetPublishedModules(course).length;

    const courseRows = progressGetRowsForCourse(rows, course);

    const completed = Math.min(
        available,
        courseRows.filter(
            row => row.is_completed === true
        ).length
    );

    const progressPoints = courseRows.reduce(
        (sum, row) => {
            if (row.is_completed === true) {
                return sum + 100;
            }

            const value = Number(row.progress_percent) || 0;

            return sum + Math.max(0, Math.min(100, value));
        },
        0
    );

    const progressPercent = available
        ? Math.round(
            Math.min(progressPoints, available * 100) / available
        )
        : 0;

    return {
        available,
        completed,
        progressPercent,
        remaining: Math.max(0, available - completed),
        hasActivity: courseRows.some(
            row =>
                Number(row.progress_percent) > 0 ||
                row.is_completed === true
        )
    };
}


/* =========================================================
   OVERALL PROGRESS
========================================================= */

function renderOverallProgress(progressRows) {
    let totalModules = 0;
    let completedModules = 0;
    let progressPoints = 0;

    BOOKWORM_PROGRESS_COURSES.forEach(course => {
        const summary = progressGetCourseSummary(
            course,
            progressRows
        );

        totalModules += summary.available;
        completedModules += summary.completed;

        progressPoints +=
            summary.progressPercent * summary.available;
    });

    const percent = totalModules
        ? Math.round(progressPoints / totalModules)
        : 0;

    const remaining = Math.max(
        0,
        totalModules - completedModules
    );

    progressSetText("overallProgress", `${percent}%`);
    progressSetText("progressRingValue", `${percent}%`);
    progressSetText("completedModules", completedModules);
    progressSetText("totalModules", totalModules);
    progressSetText("remainingModules", remaining);

    const bar = document.getElementById("overallProgressBar");

    if (bar) {
        bar.style.width = `${percent}%`;
    }

    const ring = document.getElementById("progressRing");

    if (ring) {
        ring.style.setProperty("--progress", `${percent}%`);
    }

    const message = document.getElementById("overallProgressText");

    if (!message) return;

    if (totalModules === 0) {
        message.textContent =
            "Published lesson information is not available yet.";
    } else if (percent === 0) {
        message.textContent =
            "Your study journey starts here. Open a course and begin learning.";
    } else if (percent < 50) {
        message.textContent =
            "You're building momentum. Keep moving through your available lessons.";
    } else if (percent < 100) {
        message.textContent =
            "Good progress. Continue studying to complete your available lessons.";
    } else {
        message.textContent =
            "Excellent work. You've completed all currently tracked lessons.";
    }
}


/* =========================================================
   CONTINUE LEARNING SPOTLIGHT
========================================================= */

function renderContinueLearning(progressRows) {
    const panel = document.getElementById("continueLearningPanel");
    const description = document.getElementById(
        "continueLearningDescription"
    );
    const action = document.getElementById("continueLearningAction");

    if (!panel || !description || !action) return;

    const recentRows = progressRows
        .filter(row => row.last_studied_at)
        .sort(
            (a, b) =>
                new Date(b.last_studied_at) -
                new Date(a.last_studied_at)
        );

    let latestRow = null;
    let latestCourse = null;

    for (const row of recentRows) {
        const course = progressGetCourse(row.course_code);
        const moduleNumber = Number(row.module_number);

        if (!course || !Number.isInteger(moduleNumber)) continue;

        if (!progressGetPublishedModules(course).includes(moduleNumber)) {
            continue;
        }

        latestRow = row;
        latestCourse = course;
        break;
    }

    if (!latestRow || !latestCourse) {
        description.textContent =
            "Start a published lesson to begin building your study history.";

        action.href = "course.html";
        action.textContent = "Explore courses →";
        return;
    }

    const moduleNumber = Number(latestRow.module_number);

    const moduleTitle =
        latestCourse.modules[moduleNumber - 1] ||
        `Module ${moduleNumber}`;

    const status = progressGetModuleStatus(latestRow);

    description.textContent =
        `${latestCourse.code} · ${moduleTitle} · ${status.percent}% studied`;

    action.href = progressGetModuleURL(latestCourse, moduleNumber);

    action.textContent = latestRow.is_completed
        ? "Review this lesson →"
        : "Resume this lesson →";
}


/* =========================================================
   COURSE CARDS
========================================================= */

function renderCourseProgress(progressRows) {
    const container = document.getElementById("courseProgressList");

    if (!container) return;

    container.innerHTML = "";

    BOOKWORM_PROGRESS_COURSES.forEach(course => {
        const summary = progressGetCourseSummary(course, progressRows);

        const card = document.createElement("article");
        card.className = "course-progress-card";

        let status;
        let statusClass;
        let actionLabel;
        let actionURL;

        actionURL =
            `course.html?course=${encodeURIComponent(course.slug)}`;

        if (summary.available === 0) {
            status = "Lessons not yet listed as published";
            statusClass = "not-started";
            actionLabel = "View course →";
        } else if (summary.completed === summary.available) {
            status = "All available lessons completed";
            statusClass = "completed";
            actionLabel = "Review course →";
        } else if (summary.hasActivity) {
            status =
                `${summary.completed} of ${summary.available} lessons completed`;

            statusClass = "in-progress";
            actionLabel = "Continue studying →";
        } else {
            status = "Ready to start";
            statusClass = "not-started";
            actionLabel = "Start studying →";
        }

        card.innerHTML = `
            <div class="course-progress-top">
                <div class="course-progress-heading">
                    <span class="course-progress-code">
                        ${progressEscapeHTML(course.code)}
                    </span>

                    <h3 class="course-progress-name">
                        ${progressEscapeHTML(course.name)}
                    </h3>
                </div>

                <strong class="course-progress-percent">
                    ${summary.progressPercent}%
                </strong>
            </div>

            <div class="course-progress-status ${statusClass}">
                <span class="course-status-dot" aria-hidden="true"></span>
                ${progressEscapeHTML(status)}
            </div>

            <div
                class="progress-track"
                role="progressbar"
                aria-label="${progressEscapeHTML(course.code)} study progress"
                aria-valuemin="0"
                aria-valuemax="100"
                aria-valuenow="${summary.progressPercent}"
            >
                <div
                    class="progress-fill"
                    style="width:${summary.progressPercent}%"
                ></div>
            </div>

            <div class="course-progress-bottom">
                <span>${summary.completed} completed</span>
                <span>${summary.available} available</span>
            </div>

            ${
                summary.available === 0
                    ? `
                        <p class="course-availability-note">
                            The catalogue currently has no lessons
                            marked as published for this course.
                        </p>
                    `
                    : ""
            }

            <a
                href="${actionURL}"
                class="course-progress-action"
            >
                ${actionLabel}
            </a>
        `;

        container.appendChild(card);
    });
}


/* =========================================================
   MODULE COMPLETION CHECKLIST
   Automatically inserts itself before Recently Studied.
========================================================= */

function progressEnsureChecklistSection() {
    let container = document.getElementById("moduleChecklistList");

    if (container) return container;

    const recentList = document.getElementById("recentStudyList");

    if (!recentList) return null;

    const recentSection = recentList.closest(".dashboard-panel");

    if (!recentSection || !recentSection.parentElement) {
        return null;
    }

    const section = document.createElement("section");

    section.className = "dashboard-panel module-checklist-panel";

    section.innerHTML = `
        <div class="panel-header">
            <div>
                <p class="eyebrow">YOUR STUDY ROADMAP</p>
                <h2>Module checklist</h2>
                <p class="module-checklist-subtitle">
                    Track published lessons and see what remains.
                </p>
            </div>
        </div>

        <div
            id="moduleChecklistList"
            class="module-checklist-list"
            aria-live="polite"
        >
            <div class="progress-loading">
                Loading your module checklist...
            </div>
        </div>
    `;

    recentSection.parentElement.insertBefore(section, recentSection);

    return document.getElementById("moduleChecklistList");
}




function renderModuleChecklist(progressRows) {
    const container = document.getElementById("moduleChecklistList");

    if (!container) {
        console.warn(
            "Bookworm Progress: moduleChecklistList was not found."
        );
        return;
    }

    const courses = Array.isArray(BOOKWORM_PROGRESS_COURSES)
        ? BOOKWORM_PROGRESS_COURSES
        : [];

    const publishedCourses = courses.filter(course =>
        progressGetPublishedModules(course).length > 0
    );

    if (publishedCourses.length === 0) {
        container.innerHTML = `
            <div class="progress-empty">
                <strong>No published modules yet.</strong>
                <p>Published lessons will appear here when available.</p>
            </div>
        `;
        return;
    }

    container.innerHTML = publishedCourses.map(course => {
        const modules = progressGetPublishedModules(course);

        const completedCount = modules.filter(moduleNumber => {
            const row = progressGetModuleRow(
                progressRows,
                course,
                moduleNumber
            );

            return row?.is_completed === true;
        }).length;

        const moduleHTML = modules.map(moduleNumber => {
            const row = progressGetModuleRow(
                progressRows,
                course,
                moduleNumber
            );

            const status = progressGetModuleStatus(row);
            const moduleLabel = String(moduleNumber).padStart(2, "0");

            const moduleTitle =
                course.modules[moduleNumber - 1] ||
                `Module ${moduleLabel}`;

            const moduleURL = progressGetModuleURL(
                course,
                moduleNumber
            );

            return `
                <a
                    class="module-checklist-item module-checklist-link ${status.className}"
                    href="${progressEscapeHTML(moduleURL)}"
                    aria-label="${progressEscapeHTML(
                        `${course.code}, ${moduleTitle}, ${status.label}, ${status.percent}% complete`
                    )}"
                >
                    <span
                        class="module-checklist-indicator ${status.className}"
                        aria-hidden="true"
                    >
                        ${status.className === "completed" ? "✓" : moduleLabel}
                    </span>

                    <span class="module-checklist-details">
                        <strong>
                            ${progressEscapeHTML(moduleTitle)}
                        </strong>

                        <span class="module-checklist-course-code">
                            ${progressEscapeHTML(course.code)}
                        </span>

                        <span
                            class="module-checklist-progress-track"
                            role="progressbar"
                            aria-label="${progressEscapeHTML(moduleTitle)} progress"
                            aria-valuemin="0"
                            aria-valuemax="100"
                            aria-valuenow="${status.percent}"
                        >
                            <span
                                class="module-checklist-progress-fill ${status.className}"
                                style="width: ${status.percent}%"
                            ></span>
                        </span>
                    </span>

                    <span class="module-checklist-status ${status.className}">
                        ${status.label}
                        <span class="module-checklist-percent">
                            ${status.percent}%
                        </span>
                    </span>

                    <span class="module-checklist-open" aria-hidden="true">
                        →
                    </span>
                </a>
            `;
        }).join("");

        return `
            <section class="module-checklist-course">
                <div class="module-checklist-course-header">
                    <div>
                        <p class="eyebrow">
                            ${progressEscapeHTML(course.code)}
                        </p>

                        <h3>
                            ${progressEscapeHTML(course.name)}
                        </h3>
                    </div>

                    <span class="module-checklist-count">
                        ${completedCount}/${modules.length} complete
                    </span>
                </div>

                <div class="module-checklist-items">
                    ${moduleHTML}
                </div>
            </section>
        `;
    }).join("");
}



/* =========================================================
   RECENT STUDY — RESUME LESSONS
========================================================= */

function renderRecentStudy(progressRows) {
    const container = document.getElementById("recentStudyList");

    if (!container) return;

    const recentRows = progressRows
        .filter(row => row.last_studied_at)
        .sort(
            (a, b) =>
                new Date(b.last_studied_at) -
                new Date(a.last_studied_at)
        );

    container.innerHTML = "";

    let renderedCount = 0;

    for (const row of recentRows) {
        if (renderedCount >= 6) break;

        const course = progressGetCourse(row.course_code);

        if (!course) continue;

        const moduleNumber = Number(row.module_number);

        if (!progressGetPublishedModules(course).includes(moduleNumber)) {
            continue;
        }

        const moduleTitle =
            course.modules[moduleNumber - 1] ||
            `Module ${moduleNumber}`;

        const status = progressGetModuleStatus(row);

        const item = document.createElement("a");

        item.className = "recent-study-item";
        item.href = progressGetModuleURL(course, moduleNumber);

        item.setAttribute(
            "aria-label",
            `Resume ${course.code}, module ${moduleNumber}: ${moduleTitle}`
        );

        item.innerHTML = `
            <div class="recent-study-number">
                ${String(moduleNumber).padStart(2, "0")}
            </div>

            <div class="recent-study-content">
                <strong>
                    ${progressEscapeHTML(moduleTitle)}
                </strong>

                <span>
                    ${progressEscapeHTML(course.code)}
                    <span aria-hidden="true"> · </span>
                    ${progressFormatDate(row.last_studied_at)}
                </span>
            </div>

            <span class="recent-study-progress">
                ${status.percent}%
            </span>
        `;

        container.appendChild(item);
        renderedCount++;
    }

    if (renderedCount === 0) {
        container.innerHTML = `
            <div class="progress-empty">
                <strong>Your study history will appear here.</strong>

                <p>
                    Open a published lesson and begin studying.
                    Your recent activity will appear here.
                </p>

                <a
                    href="course.html"
                    class="course-progress-action"
                >
                    Explore courses →
                </a>
            </div>
        `;
    }
}


/* =========================================================
   INITIALIZE DASHBOARD
========================================================= */

async function initializeProgressPage() {
    const container = document.getElementById("courseProgressList");

    if (!window.BookwormProgress) {
        if (container) {
            container.innerHTML = `
                <div class="progress-error">
                    The progress system is unavailable.
                    Please refresh the page.
                </div>
            `;
        }

        return;
    }

    try {
        const progressRows =
            await window.BookwormProgress.getAllProgress();

        if (!Array.isArray(progressRows)) {
            throw new Error("The progress system returned invalid data.");
        }

        renderOverallProgress(progressRows);
        renderContinueLearning(progressRows);
        renderCourseProgress(progressRows);
        renderModuleChecklist(progressRows);
        renderRecentStudy(progressRows);

    } catch (error) {
        console.error("BOOKWORM PROGRESS PAGE:", error);

        if (container) {
            container.innerHTML = `
                <div class="progress-error">
                    We couldn't load your study progress.
                    Check your connection and try again.
                </div>
            `;
        }
    }
}


document.addEventListener(
    "DOMContentLoaded",
    initializeProgressPage
);
