/* ==========================================
   BOOKWORM CLUB — SERVICE WORKER
   Reliable PWA + Offline Support
========================================== */

const CACHE_NAME =
    "bookworm-club-v7";

const RUNTIME_CACHE =
    "bookworm-runtime-v7";


/* ==========================================
   EXTERNAL STATIC FILES
========================================== */

const EXTERNAL_STATIC_FILES = [

    "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"

];


/* ==========================================
   CORE BOOKWORM FILES
========================================== */

const CORE_FILES = [

    "./",

    "./index.html",

    "./dashboard.html",

    "./courses.html",

    "./course.html",

    "./course-note.html",

    "./tasks.html",

    "./resources.html",

    "./announcements.html",

    "./profile.html",

    "./past-questions.html",

    "./marketplace.html",

    "./my-listings.html",

    "./feedback.html",

    "./offline.html",

    "./manifest.json",


    /* =========================
       CSS
    ========================= */

    "./css/style.css",

    "./css/dashboard.css",

    "./css/courses.css",

    "./css/course-note.css",

    "./js/premium-access.js",

    "./js/premium-reader-guard.js",

    "./css/tasks.css",

    "./css/profile.css",

    "./css/announcements.css",

    "./css/marketplace.css",

    "./css/my-listings.css",

    "./css/past-questions.css",
    "./css/premium.css",
    


    /* =========================
       CORE JAVASCRIPT
    ========================= */

    "./js/auth.js",

    "./js/auth-guard.js",

    "./js/app.js",

    "./js/dashboard.js",

    "./js/courses.js",

    "./js/course.js",

    "./js/course-note.js",

    "./js/tasks.js",

    "./js/profile.js",

    "./js/announcements.js",

    "./js/marketplace.js",

    "./js/my-listings.js",

    "./js/past-questions.js"

];


/* ==========================================
   INSTALL
========================================== */

self.addEventListener(
    "install",
    (event) => {

        console.log(
            "Bookworm Club: Installing offline-ready service worker..."
        );

        event.waitUntil(

            caches
                .open(CACHE_NAME)

                .then(
                    async (cache) => {

                        /*
                         * Cache files individually.
                         *
                         * This means one missing file will
                         * not destroy the entire installation.
                         */

                        await Promise.allSettled(

                            [
                                ...CORE_FILES,
                                ...EXTERNAL_STATIC_FILES
                            ]

                            .map(
                                async (file) => {

                                    try {

                                        await cache.add(
                                            file
                                        );

                                        console.log(
                                            "Bookworm SW: Cached",
                                            file
                                        );

                                    } catch (error) {

                                        console.warn(
                                            "Bookworm SW: Could not cache:",
                                            file,
                                            error
                                        );

                                    }

                                }
                            )

                        );

                    }
                )

        );

    }
);


/* ==========================================
   ACTIVATE
========================================== */

self.addEventListener(
    "activate",
    (event) => {

        console.log(
            "Bookworm Club: Offline-ready service worker activated."
        );

        event.waitUntil(

            caches
                .keys()

                .then(
                    (cacheNames) => {

                        return Promise.all(

                            cacheNames

                                .filter(
                                    (name) =>
                                        name !==
                                            CACHE_NAME &&
                                        name !==
                                            RUNTIME_CACHE
                                )

                                .map(
                                    (name) =>
                                        caches.delete(
                                            name
                                        )
                                )

                        );

                    }
                )

                .then(
                    () =>
                        self.clients.claim()
                )

        );

    }
);


/* ==========================================
   HELPER:
   SAME ORIGIN
========================================== */

function isSameOrigin(request) {

    return (
        new URL(request.url).origin ===
        self.location.origin
    );

}


/* ==========================================
   HELPER:
   SUPABASE REQUEST
========================================== */

function isSupabaseRequest(request) {

    return request.url.includes(
        "supabase.co"
    );

}


/* ==========================================
   HELPER:
   STATIC ASSET
========================================== */

function isStaticAsset(request) {

    const destination =
        request.destination;

    return [

        "script",
        "style",
        "image",
        "font",
        "manifest"

    ].includes(destination);

}


/* ==========================================
   FETCH HANDLER
========================================== */

self.addEventListener(
    "fetch",
    (event) => {

        const request =
            event.request;


        /* ==============================
           ONLY GET REQUESTS
        ============================== */

        if (
            request.method !==
            "GET"
        ) {

            return;

        }


        /* ==============================
           SUPABASE API
        ============================== */

        /*
         * Never cache Supabase API,
         * authentication, database or
         * storage requests.
         *
         * Those must remain live server
         * requests.
         */

        if (
            isSupabaseRequest(request)
        ) {

            return;

        }


        /* ==============================
           SUPABASE SDK
        ============================== */

        if (

            request.url ===
            "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"

        ) {

            event.respondWith(

                caches
                    .match(request)

                    .then(
                        (cached) => {

                            if (cached) {

                                return cached;

                            }

                            return fetch(
                                request
                            );

                        }
                    )

                    .then(
                        (response) => {

                            if (
                                response &&
                                response.ok
                            ) {

                                const clone =
                                    response.clone();

                                caches
                                    .open(
                                        CACHE_NAME
                                    )

                                    .then(
                                        (cache) =>
                                            cache.put(
                                                request,
                                                clone
                                            )
                                    );

                            }

                            return response;

                        }
                    )

            );

            return;

        }


        /* ==============================
           OTHER EXTERNAL REQUESTS
        ============================== */

        if (
            !isSameOrigin(request)
        ) {

            return;

        }


        /* ==========================================
           PAGE NAVIGATION
           NETWORK FIRST
           CACHE FALLBACK
        ========================================== */

        if (
            request.mode ===
            "navigate"
        ) {

            event.respondWith(

                fetch(request)

                    .then(
                        (networkResponse) => {

                            if (

                                networkResponse &&
                                networkResponse.ok

                            ) {

                                const clone =
                                    networkResponse.clone();

                                caches
                                    .open(
                                        RUNTIME_CACHE
                                    )

                                    .then(
                                        (cache) =>
                                            cache.put(
                                                request,
                                                clone
                                            )
                                    );

                            }

                            return networkResponse;

                        }
                    )

                    .catch(
                        async () => {

                            /*
                             * Internet unavailable.
                             *
                             * Try the exact requested
                             * page from cache.
                             */

                            const cached =
                                await caches.match(
                                    request
                                );

                            if (cached) {

                                return cached;

                            }


                            /*
                             * If the page has never
                             * been cached, show the
                             * Bookworm offline page.
                             */

                            const fallback =
                                await caches.match(
                                    "./offline.html"
                                );

                            if (fallback) {

                                return fallback;

                            }


                            return new Response(

                                "Bookworm Club is offline.",

                                {
                                    status: 503,

                                    headers: {
                                        "Content-Type":
                                            "text/plain; charset=utf-8"
                                    }
                                }

                            );

                        }
                    )

            );

            return;

        }


        /* ==========================================
           STATIC FILES
           CACHE FIRST
           NETWORK FALLBACK
        ========================================== */

        if (
            isStaticAsset(request)
        ) {

            event.respondWith(

                caches
                    .match(request)

                    .then(
                        (cached) => {

                            if (cached) {

                                return cached;

                            }

                            return fetch(
                                request
                            )

                            .then(
                                (response) => {

                                    if (

                                        response &&
                                        response.ok

                                    ) {

                                        const clone =
                                            response.clone();

                                        caches
                                            .open(
                                                RUNTIME_CACHE
                                            )

                                            .then(
                                                (cache) =>
                                                    cache.put(
                                                        request,
                                                        clone
                                                    )
                                            );

                                    }

                                    return response;

                                }
                            );

                        }
                    )

                    .catch(
                        () => undefined
                    )

            );

            return;

        }


        /* ==========================================
           OTHER SAME-ORIGIN GET REQUESTS
           NETWORK FIRST
           CACHE FALLBACK
        ========================================== */

        event.respondWith(

            fetch(request)

                .then(
                    (response) => {

                        if (

                            response &&
                            response.ok

                        ) {

                            const clone =
                                response.clone();

                            caches
                                .open(
                                    RUNTIME_CACHE
                                )

                                .then(
                                    (cache) =>
                                        cache.put(
                                            request,
                                            clone
                                        )
                                );

                        }

                        return response;

                    }
                )

                .catch(
                    () =>
                        caches.match(
                            request
                        )
                )

        );

    }
);


/* ==========================================
   SERVICE WORKER UPDATE COMMAND
========================================== */

self.addEventListener(
    "message",
    (event) => {

        if (

            event.data &&
            event.data.type ===
                "SKIP_WAITING"

        ) {

            self.skipWaiting();

        }

    }
);